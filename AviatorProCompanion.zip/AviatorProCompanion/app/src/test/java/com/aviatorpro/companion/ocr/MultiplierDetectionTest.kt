package com.aviatorpro.companion.ocr

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Test
import java.time.ZoneOffset

class MultiplierDetectionTest {

    @Test
    fun detectsTargetMultipliersAccurately() {
        val samples = listOf("1.25x", "2.00x", "5.67x", "10.50x", "100.00x")
        val stateMachine = RoundStateMachine(ZoneOffset.UTC)

        samples.forEachIndexed { index, raw ->
            val baseMs = 1_764_180_000_000L + (index * 10_000L)
            // Simulate waiting/countdown before round
            assertNull(
                stateMachine.onFrameParsed(
                    MultiplierParser.parseFrame(
                        listOf(
                            OcrLineObservation("NEXT ROUND IN 4s", 0.95f, 400, 48)
                        )
                    ),
                    nowEpochMs = baseMs
                )
            )
            // Crash frame with target multiplier
            val parsed = MultiplierParser.parseFrame(
                listOf(
                    OcrLineObservation("FLEW AWAY!", 0.92f, 340, 44),
                    OcrLineObservation(raw, 0.94f, 410, 120)
                )
            )
            val record = stateMachine.onFrameParsed(parsed, nowEpochMs = baseMs + 2_000L)
            assertNotNull("Expected $raw to be recorded", record)
            assertEquals(raw, record!!.formattedMultiplier)
            assertEquals(0.94f, record.ocrConfidence, 0.001f)
        }
    }

    @Test
    fun ignoresCountdownNumbersAndClimbingIncompleteRounds() {
        val stateMachine = RoundStateMachine(ZoneOffset.UTC)

        // Countdown frames must never be recorded
        assertNull(
            stateMachine.onFrameParsed(
                MultiplierParser.parseFrame(
                    listOf(
                        OcrLineObservation("STARTING IN", 0.92f, 300, 40),
                        OcrLineObservation("5.0s", 0.95f, 360, 80)
                    )
                ),
                nowEpochMs = 1_000L
            )
        )

        // Climbing multiplier ticks must never be recorded while increasing
        val climbingTicks = listOf("1.14x", "1.48x", "2.35x", "4.10x")
        climbingTicks.forEachIndexed { idx, tick ->
            val parsed = MultiplierParser.parseFrame(
                listOf(OcrLineObservation(tick, 0.95f, 400, 110))
            )
            val result = stateMachine.onFrameParsed(parsed, nowEpochMs = 2_000L + idx * 450L)
            assertNull("Climbing tick $tick should not be recorded prematurely", result)
        }

        // Only once FLEW AWAY appears should the final multiplier be recorded
        val finalFrame = MultiplierParser.parseFrame(
            listOf(
                OcrLineObservation("FLEW AWAY!", 0.91f, 340, 44),
                OcrLineObservation("5.67x", 0.96f, 400, 110)
            )
        )
        val committed = stateMachine.onFrameParsed(finalFrame, nowEpochMs = 4_200L)
        assertNotNull(committed)
        assertEquals("5.67x", committed!!.formattedMultiplier)
    }

    @Test
    fun suppressesDuplicateEmissionsOnStaticCrashScreen() {
        val stateMachine = RoundStateMachine(ZoneOffset.UTC)
        val crashFrame = MultiplierParser.parseFrame(
            listOf(
                OcrLineObservation("FLEW AWAY!", 0.93f, 340, 44),
                OcrLineObservation("10.50x", 0.95f, 410, 120)
            )
        )

        val first = stateMachine.onFrameParsed(crashFrame, nowEpochMs = 10_000L)
        val duplicate1 = stateMachine.onFrameParsed(crashFrame, nowEpochMs = 10_450L)
        val duplicate2 = stateMachine.onFrameParsed(crashFrame, nowEpochMs = 10_900L)

        assertNotNull(first)
        assertNull(duplicate1)
        assertNull(duplicate2)

        // After a new waiting phase, a genuinely new round with the same value gets a fresh unique roundId
        stateMachine.onFrameParsed(
            MultiplierParser.parseFrame(listOf(OcrLineObservation("WAITING FOR NEXT ROUND", 0.90f, 380, 48))),
            nowEpochMs = 13_000L
        )
        val nextRound = stateMachine.onFrameParsed(crashFrame, nowEpochMs = 16_000L)
        assertNotNull(nextRound)
        assertNotEquals(first!!.roundId, nextRound!!.roundId)
    }
}
