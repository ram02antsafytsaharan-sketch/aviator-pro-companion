package com.aviatorpro.companion.data.remote

import com.aviatorpro.companion.data.local.ApiConfiguration
import com.aviatorpro.companion.data.local.RoundRecordEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.IOException
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import java.time.Instant
import java.util.concurrent.TimeUnit

@Serializable
data class Base44RoundPayload(
    @SerialName("round_id")
    val roundId: String,
    @SerialName("multiplier")
    val multiplier: Double,
    @SerialName("multiplier_text")
    val multiplierText: String,
    @SerialName("detection_date")
    val detectionDate: String,
    @SerialName("detection_time")
    val detectionTime: String,
    @SerialName("detected_at_iso")
    val detectedAtIso: String,
    @SerialName("ocr_confidence")
    val ocrConfidence: Float,
    @SerialName("device_id")
    val deviceId: String,
    @SerialName("source")
    val source: String = "aviator_pro_companion_android"
)

@Serializable
data class Base44HealthCheckPayload(
    @SerialName("event")
    val event: String = "companion_health_check",
    @SerialName("device_id")
    val deviceId: String,
    @SerialName("timestamp_iso")
    val timestampIso: String,
    @SerialName("source")
    val source: String = "aviator_pro_companion_android"
)

sealed interface ApiResult {
    data class Success(
        val httpCode: Int,
        val serverMessage: String
    ) : ApiResult

    data class Failure(
        val httpCode: Int?,
        val errorMessage: String,
        val isRetryable: Boolean
    ) : ApiResult
}

class Base44ApiClient {

    private val json = Json {
        ignoreUnknownKeys = true
        encodeDefaults = true
    }

    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(12, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .writeTimeout(15, TimeUnit.SECONDS)
        .retryOnConnectionFailure(false)
        .build()

    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()

    suspend fun sendRound(
        config: ApiConfiguration,
        record: RoundRecordEntity
    ): ApiResult = withContext(Dispatchers.IO) {
        val urlError = ApiConfiguration.validateEndpointUrl(config.endpointUrl)
        if (urlError != null) {
            return@withContext ApiResult.Failure(
                httpCode = null,
                errorMessage = urlError,
                isRetryable = false
            )
        }
        if (config.deviceKey.isBlank()) {
            return@withContext ApiResult.Failure(
                httpCode = null,
                errorMessage = "Device key is not configured.",
                isRetryable = false
            )
        }

        val payload = Base44RoundPayload(
            roundId = record.roundId,
            multiplier = record.multiplier,
            multiplierText = record.formattedMultiplier,
            detectionDate = record.detectionDate,
            detectionTime = record.detectionTime,
            detectedAtIso = record.detectedAtIso,
            ocrConfidence = record.ocrConfidence,
            deviceId = config.deviceId
        )

        executePost(
            url = config.endpointUrl,
            deviceKey = config.deviceKey,
            bodyJson = json.encodeToString(payload)
        )
    }

    suspend fun testConnection(config: ApiConfiguration): ApiResult = withContext(Dispatchers.IO) {
        val urlError = ApiConfiguration.validateEndpointUrl(config.endpointUrl)
        if (urlError != null) {
            return@withContext ApiResult.Failure(
                httpCode = null,
                errorMessage = urlError,
                isRetryable = false
            )
        }
        if (config.deviceKey.isBlank()) {
            return@withContext ApiResult.Failure(
                httpCode = null,
                errorMessage = "Device key is required to verify server connection.",
                isRetryable = false
            )
        }

        val pingPayload = Base44HealthCheckPayload(
            deviceId = config.deviceId,
            timestampIso = Instant.now().toString()
        )

        executePost(
            url = config.endpointUrl,
            deviceKey = config.deviceKey,
            bodyJson = json.encodeToString(pingPayload)
        )
    }

    private fun executePost(
        url: String,
        deviceKey: String,
        bodyJson: String
    ): ApiResult {
        val request = Request.Builder()
            .url(url)
            .post(bodyJson.toRequestBody(jsonMediaType))
            .header("Accept", "application/json")
            .header("Content-Type", "application/json")
            .header("X-Device-Key", deviceKey)
            .header("Authorization", "Bearer $deviceKey")
            .build()

        return try {
            client.newCall(request).execute().use { response ->
                val rawBody = response.body?.string().orEmpty().trim()
                val snippet = rawBody.take(180)
                if (response.isSuccessful) {
                    ApiResult.Success(
                        httpCode = response.code,
                        serverMessage = if (snippet.isNotEmpty()) {
                            "HTTP ${response.code}: $snippet"
                        } else {
                            "HTTP ${response.code} OK"
                        }
                    )
                } else {
                    val retryable = response.code == 408 || response.code == 429 || response.code >= 500
                    val detail = if (snippet.isNotEmpty()) snippet else response.message
                    ApiResult.Failure(
                        httpCode = response.code,
                        errorMessage = "HTTP ${response.code}: $detail",
                        isRetryable = retryable
                    )
                }
            }
        } catch (_: UnknownHostException) {
            ApiResult.Failure(
                httpCode = null,
                errorMessage = "DNS lookup failed. Check internet connection or endpoint host.",
                isRetryable = true
            )
        } catch (_: SocketTimeoutException) {
            ApiResult.Failure(
                httpCode = null,
                errorMessage = "Request timed out waiting for Base44 server response.",
                isRetryable = true
            )
        } catch (e: IOException) {
            ApiResult.Failure(
                httpCode = null,
                errorMessage = "Network error: ${e.localizedMessage ?: e.javaClass.simpleName}",
                isRetryable = true
            )
        } catch (e: Exception) {
            ApiResult.Failure(
                httpCode = null,
                errorMessage = "Request error: ${e.localizedMessage ?: e.javaClass.simpleName}",
                isRetryable = false
            )
        }
    }
}
