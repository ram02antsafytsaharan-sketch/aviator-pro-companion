package com.aviatorpro.companion.data.sync

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.aviatorpro.companion.AviatorCompanionApp

class RetrySyncWorker(
    appContext: Context,
    workerParams: WorkerParameters
) : CoroutineWorker(appContext, workerParams) {

    override suspend fun doWork(): Result {
        val app = applicationContext as AviatorCompanionApp
        app.repository.flushReadyQueue()
        return Result.success()
    }
}
