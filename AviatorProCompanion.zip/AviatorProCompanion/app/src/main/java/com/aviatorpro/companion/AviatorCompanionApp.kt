package com.aviatorpro.companion

import android.app.Application
import com.aviatorpro.companion.data.local.AppDatabase
import com.aviatorpro.companion.data.local.SecureConfigStore
import com.aviatorpro.companion.data.remote.Base44ApiClient
import com.aviatorpro.companion.data.repository.CompanionRepository

class AviatorCompanionApp : Application() {

    val database: AppDatabase by lazy { AppDatabase.getInstance(this) }
    val configStore: SecureConfigStore by lazy { SecureConfigStore(this) }
    val apiClient: Base44ApiClient by lazy { Base44ApiClient() }
    val repository: CompanionRepository by lazy {
        CompanionRepository(
            context = this,
            dao = database.roundRecordDao(),
            configStore = configStore,
            apiClient = apiClient
        )
    }
}
