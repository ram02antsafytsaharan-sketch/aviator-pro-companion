package com.aviatorpro.companion.ocr

import android.graphics.Bitmap
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.Text
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.TextRecognizer
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

class ScreenOcrProcessor {

    private val recognizer: TextRecognizer =
        TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)

    suspend fun recognizeLines(bitmap: Bitmap): List<OcrLineObservation> {
        val image = InputImage.fromBitmap(bitmap, 0)
        val visionText = awaitTextRecognition(image)
        val observations = mutableListOf<OcrLineObservation>()

        for (block in visionText.textBlocks) {
            for (line in block.lines) {
                val box = line.boundingBox
                val confidence = computeLineConfidence(line)
                observations += OcrLineObservation(
                    text = line.text,
                    confidence = confidence,
                    topPx = box?.top ?: 0,
                    heightPx = box?.height() ?: 0
                )
            }
        }
        return observations
    }

    private fun computeLineConfidence(line: Text.Line): Float {
        val elementConfidences = line.elements
            .map { it.confidence }
            .filter { !it.isNaN() && it in 0f..1f }

        if (elementConfidences.isNotEmpty()) {
            return elementConfidences.average().toFloat()
        }
        val lineConf = line.confidence
        return if (!lineConf.isNaN() && lineConf in 0f..1f) lineConf else 0f
    }

    private suspend fun awaitTextRecognition(image: InputImage): Text =
        suspendCancellableCoroutine { continuation ->
            recognizer.process(image)
                .addOnSuccessListener { result ->
                    if (continuation.isActive) {
                        continuation.resume(result)
                    }
                }
                .addOnFailureListener { exception ->
                    if (continuation.isActive) {
                        continuation.resumeWithException(exception)
                    }
                }
        }

    fun close() {
        recognizer.close()
    }
}
