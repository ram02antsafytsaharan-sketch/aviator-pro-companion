package com.aviatorpro.companion.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.aviatorpro.companion.AviatorCompanionApp
import com.aviatorpro.companion.data.local.ApiConfiguration
import com.aviatorpro.companion.data.local.RoundRecordEntity
import com.aviatorpro.companion.data.remote.ApiResult
import com.aviatorpro.companion.service.ConnectionStatus
import com.aviatorpro.companion.service.MonitoringStateHolder
import com.aviatorpro.companion.service.MonitoringStatus
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class CompanionUiState(
    val endpointInput: String = "",
    val deviceKeyInput: String = "",
    val endpointValidationError: String? = null,
    val configSavedMessage: String? = null,
    val isTestingConnection: Boolean = false,
    val monitoringStatus: MonitoringStatus = MonitoringStatus.Idle,
    val connectionStatus: ConnectionStatus = ConnectionStatus.Unverified,
    val rounds: List<RoundRecordEntity> = emptyList(),
    val totalRoundsCount: Int = 0,
    val pendingRoundsCount: Int = 0,
    val uiNotice: String? = null
)

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val app = application as AviatorCompanionApp
    private val repository = app.repository

    private val _formState = MutableStateFlow(loadInitialFormState())

    val uiState: StateFlow<CompanionUiState> = combine(
        _formState,
        MonitoringStateHolder.monitoringStatus,
        MonitoringStateHolder.connectionStatus,
        repository.recentRounds,
        repository.totalCount,
        repository.pendingCount
    ) { values ->
        @Suppress("UNCHECKED_CAST")
        val form = values[0] as FormState
        val monitoring = values[1] as MonitoringStatus
        val connection = values[2] as ConnectionStatus
        val rounds = values[3] as List<RoundRecordEntity>
        val total = values[4] as Int
        val pending = values[5] as Int

        CompanionUiState(
            endpointInput = form.endpointInput,
            deviceKeyInput = form.deviceKeyInput,
            endpointValidationError = form.endpointValidationError,
            configSavedMessage = form.configSavedMessage,
            isTestingConnection = form.isTestingConnection,
            monitoringStatus = monitoring,
            connectionStatus = connection,
            rounds = rounds,
            totalRoundsCount = total,
            pendingRoundsCount = pending,
            uiNotice = form.uiNotice
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000L),
        initialValue = CompanionUiState(
            endpointInput = _formState.value.endpointInput,
            deviceKeyInput = _formState.value.deviceKeyInput
        )
    )

    fun onEndpointChanged(value: String) {
        _formState.update {
            it.copy(
                endpointInput = value,
                endpointValidationError = null,
                configSavedMessage = null,
                uiNotice = null
            )
        }
    }

    fun onDeviceKeyChanged(value: String) {
        _formState.update {
            it.copy(
                deviceKeyInput = value,
                configSavedMessage = null,
                uiNotice = null
            )
        }
    }

    fun saveConfiguration(): Boolean {
        val current = _formState.value
        val urlError = ApiConfiguration.validateEndpointUrl(current.endpointInput)
        if (urlError != null) {
            _formState.update {
                it.copy(endpointValidationError = urlError, configSavedMessage = null)
            }
            return false
        }
        if (current.deviceKeyInput.isBlank()) {
            _formState.update {
                it.copy(
                    endpointValidationError = null,
                    configSavedMessage = null,
                    uiNotice = "Enter your Base44 device key before saving."
                )
            }
            return false
        }

        val saved = repository.saveConfig(current.endpointInput, current.deviceKeyInput)
        _formState.update {
            it.copy(
                endpointInput = saved.endpointUrl,
                deviceKeyInput = saved.deviceKey,
                endpointValidationError = null,
                configSavedMessage = "Configuration saved securely. Tap Test Connection to verify.",
                uiNotice = null
            )
        }
        return true
    }

    fun testServerConnection() {
        if (!saveConfiguration()) return

        viewModelScope.launch {
            _formState.update { it.copy(isTestingConnection = true, uiNotice = null) }
            val result = repository.verifyServerConnection()
            val notice = when (result) {
                is ApiResult.Success -> "Server verified (${result.serverMessage})."
                is ApiResult.Failure -> "Connection failed: ${result.errorMessage}"
            }
            _formState.update {
                it.copy(
                    isTestingConnection = false,
                    configSavedMessage = null,
                    uiNotice = notice
                )
            }
        }
    }

    fun retryPendingRounds() {
        viewModelScope.launch {
            _formState.update { it.copy(uiNotice = "Retrying queued rounds...") }
            repository.retryAllPendingNow()
            _formState.update { it.copy(uiNotice = null) }
        }
    }

    fun clearSyncedRounds() {
        viewModelScope.launch {
            repository.clearSyncedHistory()
        }
    }

    fun setUiNotice(message: String?) {
        _formState.update { it.copy(uiNotice = message) }
    }

    fun canStartMonitoring(): Boolean {
        val saved = repository.getConfig()
        val form = _formState.value
        if (form.endpointInput.trim() != saved.endpointUrl || form.deviceKeyInput.trim() != saved.deviceKey) {
            if (!saveConfiguration()) return false
        }
        val latest = repository.getConfig()
        if (!latest.isConfigured) {
            _formState.update {
                it.copy(
                    endpointValidationError = ApiConfiguration.validateEndpointUrl(form.endpointInput),
                    uiNotice = "Configure a valid HTTPS Base44 endpoint and device key first."
                )
            }
            return false
        }
        return true
    }

    private fun loadInitialFormState(): FormState {
        val config = repository.getConfig()
        return FormState(
            endpointInput = config.endpointUrl,
            deviceKeyInput = config.deviceKey
        )
    }

    private data class FormState(
        val endpointInput: String = "",
        val deviceKeyInput: String = "",
        val endpointValidationError: String? = null,
        val configSavedMessage: String? = null,
        val isTestingConnection: Boolean = false,
        val uiNotice: String? = null
    )
}
