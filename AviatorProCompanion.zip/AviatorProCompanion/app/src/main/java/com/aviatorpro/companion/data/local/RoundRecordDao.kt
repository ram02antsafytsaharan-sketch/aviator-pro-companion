package com.aviatorpro.companion.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface RoundRecordDao {

    @Query("SELECT * FROM round_records ORDER BY detectedAtEpochMs DESC LIMIT 200")
    fun observeRecentRounds(): Flow<List<RoundRecordEntity>>

    @Query("SELECT COUNT(*) FROM round_records")
    fun observeTotalCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM round_records WHERE syncStatus != 'SYNCED'")
    fun observePendingCount(): Flow<Int>

    @Query(
        "SELECT * FROM round_records " +
            "WHERE syncStatus IN ('PENDING', 'FAILED') AND nextRetryAtEpochMs <= :nowEpochMs " +
            "ORDER BY detectedAtEpochMs ASC LIMIT 25"
    )
    suspend fun getRoundsReadyForSync(nowEpochMs: Long): List<RoundRecordEntity>

    @Query("SELECT * FROM round_records WHERE syncStatus IN ('PENDING', 'FAILED') ORDER BY detectedAtEpochMs ASC")
    suspend fun getAllUnsyncedRounds(): List<RoundRecordEntity>

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertIgnoreDuplicate(record: RoundRecordEntity): Long

    @Query(
        "UPDATE round_records SET syncStatus = :status, lastHttpCode = :httpCode, " +
            "lastErrorMessage = :errorMessage WHERE roundId = :roundId"
    )
    suspend fun updateSyncStatus(
        roundId: String,
        status: String,
        httpCode: Int?,
        errorMessage: String?
    )

    @Query(
        "UPDATE round_records SET syncStatus = :status, retryCount = :retryCount, " +
            "lastHttpCode = :httpCode, lastErrorMessage = :errorMessage, " +
            "nextRetryAtEpochMs = :nextRetryAtEpochMs WHERE roundId = :roundId"
    )
    suspend fun updateRetrySchedule(
        roundId: String,
        status: String,
        retryCount: Int,
        httpCode: Int?,
        errorMessage: String?,
        nextRetryAtEpochMs: Long
    )

    @Query("DELETE FROM round_records WHERE syncStatus = 'SYNCED'")
    suspend fun clearSyncedRounds()
}
