package com.aviatorpro.companion.ocr

import com.aviatorpro.companion.data.local.RoundRecordEntity
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.UUID

class RoundStateMachine(
    private val zoneId: ZoneId = ZoneId.systemDefault()
) {

    private enum class Phase {
        IDLE,
        WAITING,
        CLIMBING,
        SETTLED
    }

    private var phase: Phase = Phase.IDLE
    private var lastClimbingValue: Double? = null
    private var stableCandidateValue: Double? = null
    private var stableConsecutiveFrames: Int = 0
    private var stableFirstSeenEpochMs: Long = 0L

    private var lastCommittedValue: Double? = null
    private var lastCommittedEpochMs: Long = 0L
    private var roundTransitionObservedSinceCommit: Boolean = true

    fun reset() {
        phase = Phase.IDLE
        lastClimbingValue = null
        stableCandidateValue = null
        stableConsecutiveFrames = 0
        stableFirstSeenEpochMs = 0L
        lastCommittedValue = null
        lastCommittedEpochMs = 0L
        roundTransitionObservedSinceCommit = true
    }

    fun onFrameParsed(
        frame: ParsedScreenFrame,
        nowEpochMs: Long = System.currentTimeMillis()
    ): RoundRecordEntity? {
        // Countdown / betting window active without a crash banner: never record anything
        if (frame.hasCountdownBanner && !frame.hasCrashBanner) {
            phase = Phase.WAITING
            lastClimbingValue = null
            stableCandidateValue = null
            stableConsecutiveFrames = 0
            roundTransitionObservedSinceCommit = true
            return null
        }

        val candidate = frame.primaryCandidate ?: return null

        // Case 1: Explicit crash / round-ended banner visible on screen
        if (frame.hasCrashBanner) {
            return commitIfNotDuplicate(
                candidate = candidate,
                nowEpochMs = nowEpochMs
            )
        }

        // Case 2: No crash banner yet — track whether multiplier is still climbing
        val prevStable = stableCandidateValue
        if (prevStable != null && MultiplierParser.roughlyEqual(prevStable, candidate.value)) {
            stableConsecutiveFrames += 1
        } else {
            // If value increased from previous value, the multiplier is actively climbing (incomplete round)
            if (prevStable != null && candidate.value > prevStable + 0.005) {
                phase = Phase.CLIMBING
                lastClimbingValue = candidate.value
                roundTransitionObservedSinceCommit = true
            } else if (phase == Phase.IDLE || phase == Phase.WAITING) {
                phase = Phase.CLIMBING
                lastClimbingValue = candidate.value
                roundTransitionObservedSinceCommit = true
            }
            stableCandidateValue = candidate.value
            stableConsecutiveFrames = 1
            stableFirstSeenEpochMs = nowEpochMs
            return null
        }

        // Only commit without an explicit crash banner if the exact same multiplier has remained
        // completely frozen for >= 3 frames AND >= 1100ms after a round transition / climb.
        val stableDurationMs = nowEpochMs - stableFirstSeenEpochMs
        val wasClimbingOrWaiting = phase == Phase.CLIMBING || phase == Phase.WAITING
        if (wasClimbingOrWaiting &&
            stableConsecutiveFrames >= MIN_STABLE_FRAMES &&
            stableDurationMs >= MIN_STABLE_DURATION_MS
        ) {
            return commitIfNotDuplicate(
                candidate = candidate,
                nowEpochMs = nowEpochMs
            )
        }

        return null
    }

    private fun commitIfNotDuplicate(
        candidate: MultiplierCandidate,
        nowEpochMs: Long
    ): RoundRecordEntity? {
        val lastValue = lastCommittedValue
        val elapsedSinceCommit = nowEpochMs - lastCommittedEpochMs

        // Suppress duplicate emissions while the crash screen or static history remains visible
        if (lastValue != null &&
            MultiplierParser.roughlyEqual(lastValue, candidate.value) &&
            (!roundTransitionObservedSinceCommit || elapsedSinceCommit < MIN_SAME_VALUE_COOLDOWN_MS)
        ) {
            phase = Phase.SETTLED
            return null
        }

        // Also guard against re-emitting if we are still in SETTLED without a new round transition
        if (phase == Phase.SETTLED && !roundTransitionObservedSinceCommit) {
            return null
        }

        phase = Phase.SETTLED
        lastCommittedValue = candidate.value
        lastCommittedEpochMs = nowEpochMs
        roundTransitionObservedSinceCommit = false
        lastClimbingValue = null
        stableCandidateValue = candidate.value
        stableConsecutiveFrames = 0

        val instant = Instant.ofEpochMilli(nowEpochMs)
        val zoned = instant.atZone(zoneId)
        val shortUuid = UUID.randomUUID().toString().substring(0, 8)

        return RoundRecordEntity(
            roundId = "APC-$nowEpochMs-$shortUuid",
            multiplier = candidate.value,
            formattedMultiplier = candidate.formattedText,
            detectionDate = DATE_FORMATTER.format(zoned),
            detectionTime = TIME_FORMATTER.format(zoned),
            detectedAtIso = instant.toString(),
            detectedAtEpochMs = nowEpochMs,
            ocrConfidence = candidate.confidence
        )
    }

    companion object {
        private const val MIN_STABLE_FRAMES = 3
        private const val MIN_STABLE_DURATION_MS = 1_100L
        private const val MIN_SAME_VALUE_COOLDOWN_MS = 4_500L

        private val DATE_FORMATTER: DateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd")
        private val TIME_FORMATTER: DateTimeFormatter = DateTimeFormatter.ofPattern("HH:mm:ss")
    }
}
