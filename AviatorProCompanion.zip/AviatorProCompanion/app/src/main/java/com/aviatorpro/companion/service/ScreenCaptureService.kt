package com.aviatorpro.companion.service

import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.util.DisplayMetrics
import android.view.WindowManager
import androidx.core.app.NotificationCompat
import androidx.core.content.IntentCompat
import com.aviatorpro.companion.AviatorCompanionApp
import com.aviatorpro.companion.MainActivity
import com.aviatorpro.companion.R
import com.aviatorpro.companion.ocr.MultiplierParser
import com.aviatorpro.companion.ocr.RoundStateMachine
import com.aviatorpro.companion.ocr.ScreenOcrProcessor
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.roundToInt

class ScreenCaptureService : Service() {

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var retryLoopJob: Job? = null

    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var captureThread: HandlerThread? = null
    private var captureHandler: Handler? = null

    private val ocrProcessor by lazy { ScreenOcrProcessor() }
    private val roundStateMachine by lazy { RoundStateMachine() }
    private val isProcessingFrame = AtomicBoolean(false)
    private var lastFrameAnalyzedAtMs = 0L

    private val projectionCallback = object : MediaProjection.Callback() {
        override fun onStop() {
            Handler(Looper.getMainLooper()).post {
                stopMonitoringInternal(reason = "Screen sharing was stopped.")
            }
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopMonitoringInternal(reason = null)
                return START_NOT_STICKY
            }
            ACTION_START -> {
                val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED)
                val resultData = IntentCompat.getParcelableExtra(
                    intent,
                    EXTRA_RESULT_DATA,
                    Intent::class.java
                )
                if (resultCode != Activity.RESULT_OK || resultData == null) {
                    MonitoringStateHolder.setMonitoringStatus(
                        MonitoringStatus.Error("Screen capture permission was not granted.")
                    )
                    stopSelf()
                    return START_NOT_STICKY
                }
                startMonitoringInternal(resultCode, resultData)
                return START_NOT_STICKY
            }
            else -> {
                stopSelf()
                return START_NOT_STICKY
            }
        }
    }

    private fun startMonitoringInternal(resultCode: Int, resultData: Intent) {
        tearDownProjectionResources()
        roundStateMachine.reset()

        createNotificationChannel()
        val initialNotification = buildNotification(
            contentText = "Monitoring screen for completed multipliers..."
        )
        startForegroundCompat(initialNotification)

        val projectionManager =
            getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val projection = try {
            projectionManager.getMediaProjection(resultCode, resultData)
        } catch (e: Exception) {
            MonitoringStateHolder.setMonitoringStatus(
                MonitoringStatus.Error("Unable to start MediaProjection: ${e.localizedMessage ?: "Permission invalid"}")
            )
            stopSelf()
            return
        }

        if (projection == null) {
            MonitoringStateHolder.setMonitoringStatus(
                MonitoringStatus.Error("MediaProjection session returned null.")
            )
            stopSelf()
            return
        }

        mediaProjection = projection
        projection.registerCallback(projectionCallback, Handler(Looper.getMainLooper()))

        val (captureWidth, captureHeight, densityDpi) = resolveCaptureDimensions()

        val thread = HandlerThread("AviatorOcrCaptureThread").apply { start() }
        captureThread = thread
        val handler = Handler(thread.looper)
        captureHandler = handler

        val reader = ImageReader.newInstance(
            captureWidth,
            captureHeight,
            PixelFormat.RGBA_8888,
            2
        )
        imageReader = reader

        reader.setOnImageAvailableListener({ r ->
            processNextImage(r)
        }, handler)

        virtualDisplay = projection.createVirtualDisplay(
            VIRTUAL_DISPLAY_NAME,
            captureWidth,
            captureHeight,
            densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader.surface,
            null,
            handler
        )

        MonitoringStateHolder.setMonitoringStatus(
            MonitoringStatus.Active(startedAtEpochMs = System.currentTimeMillis())
        )
        startQueueFlushLoop()
    }

    private fun processNextImage(reader: ImageReader) {
        val image: Image = try {
            reader.acquireLatestImage()
        } catch (_: Exception) {
            null
        } ?: return

        val now = System.currentTimeMillis()
        if (now - lastFrameAnalyzedAtMs < FRAME_SAMPLE_INTERVAL_MS ||
            !isProcessingFrame.compareAndSet(false, true)
        ) {
            image.close()
            return
        }

        lastFrameAnalyzedAtMs = now
        val bitmap = try {
            imageToBitmap(image)
        } catch (_: Exception) {
            null
        } finally {
            image.close()
        }

        if (bitmap == null) {
            isProcessingFrame.set(false)
            return
        }

        serviceScope.launch {
            try {
                val lines = ocrProcessor.recognizeLines(bitmap)
                val parsed = MultiplierParser.parseFrame(lines)
                MonitoringStateHolder.recordFrameAnalyzed(parsed.rawSummary)

                val completedRound = roundStateMachine.onFrameParsed(parsed)
                if (completedRound != null) {
                    MonitoringStateHolder.incrementSessionRounds()
                    val activeState = MonitoringStateHolder.monitoringStatus.value as? MonitoringStatus.Active
                    val count = activeState?.roundsDetectedThisSession ?: 1
                    updateNotification(
                        "Last: ${completedRound.formattedMultiplier} · $count round(s) recorded"
                    )
                    val app = applicationContext as AviatorCompanionApp
                    app.repository.recordAndSendRound(completedRound)
                }
            } catch (_: Exception) {
                // Keep monitoring loop resilient if a single frame fails OCR
            } finally {
                if (!bitmap.isRecycled) {
                    bitmap.recycle()
                }
                isProcessingFrame.set(false)
            }
        }
    }

    private fun imageToBitmap(image: Image): Bitmap {
        val plane = image.planes[0]
        val buffer = plane.buffer
        val pixelStride = plane.pixelStride
        val rowStride = plane.rowStride
        val rowPadding = rowStride - pixelStride * image.width

        val rawBitmap = Bitmap.createBitmap(
            image.width + rowPadding / pixelStride,
            image.height,
            Bitmap.Config.ARGB_8888
        )
        rawBitmap.copyPixelsFromBuffer(buffer)

        if (rawBitmap.width == image.width && rawBitmap.height == image.height) {
            return rawBitmap
        }
        val cropped = Bitmap.createBitmap(rawBitmap, 0, 0, image.width, image.height)
        rawBitmap.recycle()
        return cropped
    }

    private fun resolveCaptureDimensions(): Triple<Int, Int, Int> {
        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val densityDpi = resources.displayMetrics.densityDpi

        val (screenW, screenH) = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val bounds = wm.maximumWindowMetrics.bounds
            bounds.width() to bounds.height()
        } else {
            val metrics = DisplayMetrics()
            @Suppress("DEPRECATION")
            wm.defaultDisplay.getRealMetrics(metrics)
            metrics.widthPixels to metrics.heightPixels
        }

        // Scale down gently if wider than 720px so Moto G 5G 2024 OCR stays fast and low-memory
        val targetWidth = minOf(screenW, MAX_CAPTURE_WIDTH_PX).coerceAtLeast(360)
        val scale = targetWidth.toFloat() / screenW.toFloat()
        val targetHeight = (screenH * scale).roundToInt().coerceAtLeast(360)
        return Triple(targetWidth, targetHeight, densityDpi)
    }

    private fun startQueueFlushLoop() {
        retryLoopJob?.cancel()
        retryLoopJob = serviceScope.launch {
            val app = applicationContext as AviatorCompanionApp
            while (isActive) {
                app.repository.flushReadyQueue()
                delay(QUEUE_FLUSH_INTERVAL_MS)
            }
        }
    }

    private fun stopMonitoringInternal(reason: String?) {
        tearDownProjectionResources()
        if (reason != null) {
            MonitoringStateHolder.setMonitoringStatus(MonitoringStatus.Error(reason))
        } else {
            MonitoringStateHolder.setMonitoringStatus(MonitoringStatus.Idle)
        }
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun tearDownProjectionResources() {
        retryLoopJob?.cancel()
        retryLoopJob = null

        try {
            virtualDisplay?.release()
        } catch (_: Exception) {
        }
        virtualDisplay = null

        try {
            imageReader?.setOnImageAvailableListener(null, null)
            imageReader?.close()
        } catch (_: Exception) {
        }
        imageReader = null

        try {
            mediaProjection?.unregisterCallback(projectionCallback)
            mediaProjection?.stop()
        } catch (_: Exception) {
        }
        mediaProjection = null

        captureThread?.quitSafely()
        captureThread = null
        captureHandler = null
        isProcessingFrame.set(false)
    }

    private fun startForegroundCompat(notification: Notification) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun createNotificationChannel() {
        val manager = getSystemService(NotificationManager::class.java) ?: return
        val channel = NotificationChannel(
            CHANNEL_ID,
            getString(R.string.notification_channel_name),
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = getString(R.string.notification_channel_description)
            setShowBadge(false)
        }
        manager.createNotificationChannel(channel)
    }

    private fun updateNotification(contentText: String) {
        val manager = getSystemService(NotificationManager::class.java) ?: return
        manager.notify(NOTIFICATION_ID, buildNotification(contentText))
    }

    private fun buildNotification(contentText: String): Notification {
        val openAppIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val openAppPendingIntent = PendingIntent.getActivity(
            this,
            100,
            openAppIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val stopIntent = Intent(this, ScreenCaptureService::class.java).apply {
            action = ACTION_STOP
        }
        val stopPendingIntent = PendingIntent.getService(
            this,
            101,
            stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification_radar)
            .setContentTitle(getString(R.string.app_name))
            .setContentText(contentText)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_IMMEDIATE)
            .setContentIntent(openAppPendingIntent)
            .addAction(
                0,
                getString(R.string.notification_stop_action),
                stopPendingIntent
            )
            .build()
    }

    override fun onDestroy() {
        tearDownProjectionResources()
        ocrProcessor.close()
        serviceScope.cancel()
        if (MonitoringStateHolder.monitoringStatus.value is MonitoringStatus.Active) {
            MonitoringStateHolder.setMonitoringStatus(MonitoringStatus.Idle)
        }
        super.onDestroy()
    }

    companion object {
        const val ACTION_START = "com.aviatorpro.companion.action.START_MONITORING"
        const val ACTION_STOP = "com.aviatorpro.companion.action.STOP_MONITORING"
        const val EXTRA_RESULT_CODE = "extra_result_code"
        const val EXTRA_RESULT_DATA = "extra_result_data"

        private const val CHANNEL_ID = "aviator_pro_monitoring"
        private const val NOTIFICATION_ID = 4401
        private const val VIRTUAL_DISPLAY_NAME = "AviatorProOcrCapture"
        private const val FRAME_SAMPLE_INTERVAL_MS = 450L
        private const val QUEUE_FLUSH_INTERVAL_MS = 12_000L
        private const val MAX_CAPTURE_WIDTH_PX = 720

        fun buildStartIntent(
            context: Context,
            resultCode: Int,
            resultData: Intent
        ): Intent = Intent(context, ScreenCaptureService::class.java).apply {
            action = ACTION_START
            putExtra(EXTRA_RESULT_CODE, resultCode)
            putExtra(EXTRA_RESULT_DATA, resultData)
        }

        fun buildStopIntent(context: Context): Intent =
            Intent(context, ScreenCaptureService::class.java).apply {
                action = ACTION_STOP
            }
    }
}
