package com.aviatorpro.companion.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

object SyncStatus {
    const val PENDING = "PENDING"
    const val SYNCING = "SYNCING"
    const val SYNCED = "SYNCED"
    const val FAILED = "FAILED"
}

@Entity(tableName = "round_records")
data class RoundRecordEntity(
    @PrimaryKey
    val roundId: String,
    val multiplier: Double,
    val formattedMultiplier: String,
    val detectionDate: String,
    val detectionTime: String,
    val detectedAtIso: String,
    val detectedAtEpochMs: Long,
    val ocrConfidence: Float,
    val syncStatus: String = SyncStatus.PENDING,
    val retryCount: Int = 0,
    val lastHttpCode: Int? = null,
    val lastErrorMessage: String? = null,
    val nextRetryAtEpochMs: Long = 0L
)
