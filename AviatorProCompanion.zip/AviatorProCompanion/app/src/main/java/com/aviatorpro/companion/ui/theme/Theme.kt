package com.aviatorpro.companion.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

object AviatorColors {
    val NavyBackground = Color(0xFF070D19)
    val NavySurface = Color(0xFF0F1A2E)
    val NavySurfaceElevated = Color(0xFF15233D)
    val NavyBorder = Color(0xFF1F3457)
    val CyanAccent = Color(0xFF00E5FF)
    val CyanMuted = Color(0xFF0B3A4D)
    val WhiteText = Color(0xFFF8FAFC)
    val SlateText = Color(0xFF94A3B8)
    val SuccessGreen = Color(0xFF10B981)
    val WarningAmber = Color(0xFFF59E0B)
    val ErrorRed = Color(0xFFEF4444)
}

private val DarkColorScheme = darkColorScheme(
    primary = AviatorColors.CyanAccent,
    onPrimary = AviatorColors.NavyBackground,
    secondary = AviatorColors.CyanMuted,
    onSecondary = AviatorColors.WhiteText,
    background = AviatorColors.NavyBackground,
    onBackground = AviatorColors.WhiteText,
    surface = AviatorColors.NavySurface,
    onSurface = AviatorColors.WhiteText,
    surfaceVariant = AviatorColors.NavySurfaceElevated,
    onSurfaceVariant = AviatorColors.SlateText,
    outline = AviatorColors.NavyBorder,
    error = AviatorColors.ErrorRed,
    onError = AviatorColors.WhiteText
)

private val AppTypography = Typography(
    titleLarge = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Bold,
        fontSize = 20.sp,
        lineHeight = 26.sp,
        letterSpacing = 0.5.sp
    ),
    titleMedium = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.SemiBold,
        fontSize = 16.sp,
        lineHeight = 22.sp
    ),
    bodyMedium = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Normal,
        fontSize = 14.sp,
        lineHeight = 20.sp
    ),
    labelMedium = TextStyle(
        fontFamily = FontFamily.Monospace,
        fontWeight = FontWeight.Medium,
        fontSize = 12.sp,
        lineHeight = 16.sp
    )
)

@Composable
fun AviatorProCompanionTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        typography = AppTypography,
        content = content
    )
}
