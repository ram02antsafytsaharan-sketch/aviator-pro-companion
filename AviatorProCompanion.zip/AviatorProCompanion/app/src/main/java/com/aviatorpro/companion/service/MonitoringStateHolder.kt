package com.aviatorpro.companion.service

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

sealed interface MonitoringStatus {
    data object Idle : MonitoringStatus
    data object Starting : MonitoringStatus
    data class Active(
        val startedAtEpochMs: Long,
        val framesAnalyzed: Long = 0L,
        val roundsDetectedThisSession: Int = 0,
        val lastCandidateText: String? = null
    ) : MonitoringStatus
    data class Error(val message: String) : MonitoringStatus
}

sealed interface ConnectionStatus {
    data object Unverified : ConnectionStatus
    data object Checking : ConnectionStatus
    data class Connected(
        val httpCode: Int,
        val serverMessage: String,
        val verifiedAtEpochMs: Long
    ) : ConnectionStatus
    data class Error(
        val httpCode: Int?,
        val message: String,
        val isRetrying: Boolean = false
    ) : ConnectionStatus
}

object MonitoringStateHolder {

    private val _monitoringStatus = MutableStateFlow<MonitoringStatus>(MonitoringStatus.Idle)
    val monitoringStatus: StateFlow<MonitoringStatus> = _monitoringStatus.asStateFlow()

    private val _connectionStatus = MutableStateFlow<ConnectionStatus>(ConnectionStatus.Unverified)
    val connectionStatus: StateFlow<ConnectionStatus> = _connectionStatus.asStateFlow()

    fun setMonitoringStatus(status: MonitoringStatus) {
        _monitoringStatus.value = status
    }

    fun recordFrameAnalyzed(candidateText: String?) {
        _monitoringStatus.update { current ->
            if (current is MonitoringStatus.Active) {
                current.copy(
                    framesAnalyzed = current.framesAnalyzed + 1L,
                    lastCandidateText = candidateText ?: current.lastCandidateText
                )
            } else {
                current
            }
        }
    }

    fun incrementSessionRounds() {
        _monitoringStatus.update { current ->
            if (current is MonitoringStatus.Active) {
                current.copy(roundsDetectedThisSession = current.roundsDetectedThisSession + 1)
            } else {
                current
            }
        }
    }

    fun setConnectionStatus(status: ConnectionStatus) {
        _connectionStatus.value = status
    }
}
