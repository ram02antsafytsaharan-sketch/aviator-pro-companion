package com.aviatorpro.companion.data.local

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import java.net.URI
import java.util.UUID

data class ApiConfiguration(
    val endpointUrl: String = "",
    val deviceKey: String = "",
    val deviceId: String = ""
) {
    val isConfigured: Boolean
        get() = validateEndpointUrl(endpointUrl).isNullOrEmpty() && deviceKey.isNotBlank()

    companion object {
        fun validateEndpointUrl(rawUrl: String): String? {
            val trimmed = rawUrl.trim()
            if (trimmed.isEmpty()) {
                return "API endpoint URL is required."
            }
            val uri = try {
                URI(trimmed)
            } catch (_: Exception) {
                return "Invalid URL format."
            }
            if (!uri.scheme.equals("https", ignoreCase = true)) {
                return "Production endpoint must use HTTPS."
            }
            if (uri.host.isNullOrBlank()) {
                return "Endpoint URL must include a valid host."
            }
            return null
        }
    }
}

class SecureConfigStore(context: Context) {

    private val prefs: SharedPreferences = createPreferences(context.applicationContext)

    fun loadConfig(): ApiConfiguration {
        val deviceId = prefs.getString(KEY_DEVICE_ID, null) ?: UUID.randomUUID().toString().also {
            prefs.edit().putString(KEY_DEVICE_ID, it).apply()
        }
        return ApiConfiguration(
            endpointUrl = prefs.getString(KEY_ENDPOINT_URL, "")?.trim().orEmpty(),
            deviceKey = prefs.getString(KEY_DEVICE_KEY, "")?.trim().orEmpty(),
            deviceId = deviceId
        )
    }

    fun saveConfig(endpointUrl: String, deviceKey: String): ApiConfiguration {
        val current = loadConfig()
        val cleanUrl = endpointUrl.trim()
        val cleanKey = deviceKey.trim()
        prefs.edit()
            .putString(KEY_ENDPOINT_URL, cleanUrl)
            .putString(KEY_DEVICE_KEY, cleanKey)
            .apply()
        return current.copy(endpointUrl = cleanUrl, deviceKey = cleanKey)
    }

    private fun createPreferences(context: Context): SharedPreferences {
        return try {
            val masterKey = MasterKey.Builder(context)
                .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
                .build()
            EncryptedSharedPreferences.create(
                context,
                PREFS_FILE_NAME,
                masterKey,
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            )
        } catch (_: Exception) {
            context.getSharedPreferences(FALLBACK_PREFS_NAME, Context.MODE_PRIVATE)
        }
    }

    companion object {
        private const val PREFS_FILE_NAME = "aviator_companion_secure_prefs"
        private const val FALLBACK_PREFS_NAME = "aviator_companion_private_prefs"
        private const val KEY_ENDPOINT_URL = "api_endpoint_url"
        private const val KEY_DEVICE_KEY = "device_key"
        private const val KEY_DEVICE_ID = "device_install_id"
    }
}
