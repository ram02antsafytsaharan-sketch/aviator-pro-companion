package com.aviatorpro.companion.data.repository

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import androidx.work.BackoffPolicy
import androidx.work.Constraints
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import com.aviatorpro.companion.data.local.ApiConfiguration
import com.aviatorpro.companion.data.local.RoundRecordDao
import com.aviatorpro.companion.data.local.RoundRecordEntity
import com.aviatorpro.companion.data.local.SecureConfigStore
import com.aviatorpro.companion.data.local.SyncStatus
import com.aviatorpro.companion.data.remote.ApiResult
import com.aviatorpro.companion.data.remote.Base44ApiClient
import com.aviatorpro.companion.data.sync.RetrySyncWorker
import com.aviatorpro.companion.service.ConnectionStatus
import com.aviatorpro.companion.service.MonitoringStateHolder
import kotlinx.coroutines.flow.Flow
import java.util.concurrent.TimeUnit
import kotlin.math.min
import kotlin.math.pow

class CompanionRepository(
    private val context: Context,
    private val dao: RoundRecordDao,
    private val configStore: SecureConfigStore,
    private val apiClient: Base44ApiClient
) {

    val recentRounds: Flow<List<RoundRecordEntity>> = dao.observeRecentRounds()
    val totalCount: Flow<Int> = dao.observeTotalCount()
    val pendingCount: Flow<Int> = dao.observePendingCount()

    fun getConfig(): ApiConfiguration = configStore.loadConfig()

    fun saveConfig(endpointUrl: String, deviceKey: String): ApiConfiguration {
        val updated = configStore.saveConfig(endpointUrl, deviceKey)
        MonitoringStateHolder.setConnectionStatus(ConnectionStatus.Unverified)
        return updated
    }

    suspend fun verifyServerConnection(): ApiResult {
        val config = configStore.loadConfig()
        MonitoringStateHolder.setConnectionStatus(ConnectionStatus.Checking)

        if (!isNetworkAvailable()) {
            val offlineResult = ApiResult.Failure(
                httpCode = null,
                errorMessage = "Device is offline. Enable Wi-Fi or mobile data.",
                isRetryable = true
            )
            MonitoringStateHolder.setConnectionStatus(
                ConnectionStatus.Error(httpCode = null, message = offlineResult.errorMessage, isRetrying = false)
            )
            return offlineResult
        }

        val result = apiClient.testConnection(config)
        when (result) {
            is ApiResult.Success -> {
                MonitoringStateHolder.setConnectionStatus(
                    ConnectionStatus.Connected(
                        httpCode = result.httpCode,
                        serverMessage = result.serverMessage,
                        verifiedAtEpochMs = System.currentTimeMillis()
                    )
                )
            }
            is ApiResult.Failure -> {
                MonitoringStateHolder.setConnectionStatus(
                    ConnectionStatus.Error(
                        httpCode = result.httpCode,
                        message = result.errorMessage,
                        isRetrying = false
                    )
                )
            }
        }
        return result
    }

    suspend fun recordAndSendRound(record: RoundRecordEntity): Boolean {
        val insertedRowId = dao.insertIgnoreDuplicate(record)
        if (insertedRowId == -1L) {
            return false
        }
        syncSingleRound(record)
        return true
    }

    suspend fun flushReadyQueue() {
        val readyRounds = dao.getRoundsReadyForSync(System.currentTimeMillis())
        if (readyRounds.isEmpty()) return

        for (record in readyRounds) {
            syncSingleRound(record)
        }
    }

    suspend fun retryAllPendingNow() {
        val allUnsynced = dao.getAllUnsyncedRounds()
        for (record in allUnsynced) {
            syncSingleRound(record)
        }
    }

    suspend fun clearSyncedHistory() {
        dao.clearSyncedRounds()
    }

    private suspend fun syncSingleRound(record: RoundRecordEntity) {
        val config = configStore.loadConfig()
        if (!config.isConfigured) {
            val message = ApiConfiguration.validateEndpointUrl(config.endpointUrl)
                ?: "Device key is not configured."
            dao.updateSyncStatus(
                roundId = record.roundId,
                status = SyncStatus.FAILED,
                httpCode = null,
                errorMessage = message
            )
            MonitoringStateHolder.setConnectionStatus(
                ConnectionStatus.Error(httpCode = null, message = message, isRetrying = false)
            )
            return
        }

        if (!isNetworkAvailable()) {
            scheduleRetry(
                record = record,
                httpCode = null,
                errorMessage = "No internet connection. Queued for automatic retry.",
                isRetryable = true
            )
            return
        }

        dao.updateSyncStatus(
            roundId = record.roundId,
            status = SyncStatus.SYNCING,
            httpCode = record.lastHttpCode,
            errorMessage = null
        )

        when (val result = apiClient.sendRound(config, record)) {
            is ApiResult.Success -> {
                dao.updateSyncStatus(
                    roundId = record.roundId,
                    status = SyncStatus.SYNCED,
                    httpCode = result.httpCode,
                    errorMessage = null
                )
                MonitoringStateHolder.setConnectionStatus(
                    ConnectionStatus.Connected(
                        httpCode = result.httpCode,
                        serverMessage = result.serverMessage,
                        verifiedAtEpochMs = System.currentTimeMillis()
                    )
                )
            }
            is ApiResult.Failure -> {
                scheduleRetry(
                    record = record,
                    httpCode = result.httpCode,
                    errorMessage = result.errorMessage,
                    isRetryable = result.isRetryable
                )
            }
        }
    }

    private suspend fun scheduleRetry(
        record: RoundRecordEntity,
        httpCode: Int?,
        errorMessage: String,
        isRetryable: Boolean
    ) {
        val nextRetryCount = record.retryCount + 1
        val canRetry = isRetryable && nextRetryCount <= MAX_RETRY_ATTEMPTS
        if (canRetry) {
            val delaySeconds = min(
                MAX_BACKOFF_SECONDS,
                (BASE_BACKOFF_SECONDS * 2.0.pow((nextRetryCount - 1).toDouble())).toLong()
            )
            val nextRetryAt = System.currentTimeMillis() + (delaySeconds * 1000L)
            dao.updateRetrySchedule(
                roundId = record.roundId,
                status = SyncStatus.PENDING,
                retryCount = nextRetryCount,
                httpCode = httpCode,
                errorMessage = "$errorMessage (Retry #$nextRetryCount in ${delaySeconds}s)",
                nextRetryAtEpochMs = nextRetryAt
            )
            MonitoringStateHolder.setConnectionStatus(
                ConnectionStatus.Error(
                    httpCode = httpCode,
                    message = "$errorMessage — retrying automatically",
                    isRetrying = true
                )
            )
            enqueueBackgroundRetryWorker(delaySeconds)
        } else {
            dao.updateRetrySchedule(
                roundId = record.roundId,
                status = SyncStatus.FAILED,
                retryCount = nextRetryCount,
                httpCode = httpCode,
                errorMessage = errorMessage,
                nextRetryAtEpochMs = Long.MAX_VALUE
            )
            MonitoringStateHolder.setConnectionStatus(
                ConnectionStatus.Error(
                    httpCode = httpCode,
                    message = errorMessage,
                    isRetrying = false
                )
            )
        }
    }

    private fun enqueueBackgroundRetryWorker(delaySeconds: Long) {
        val constraints = Constraints.Builder()
            .setRequiredNetworkType(NetworkType.CONNECTED)
            .build()

        val request = OneTimeWorkRequestBuilder<RetrySyncWorker>()
            .setConstraints(constraints)
            .setInitialDelay(delaySeconds, TimeUnit.SECONDS)
            .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 15, TimeUnit.SECONDS)
            .build()

        WorkManager.getInstance(context).enqueueUniqueWork(
            RETRY_WORK_NAME,
            ExistingWorkPolicy.REPLACE,
            request
        )
    }

    private fun isNetworkAvailable(): Boolean {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
            ?: return false
        val network = cm.activeNetwork ?: return false
        val capabilities = cm.getNetworkCapabilities(network) ?: return false
        return capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
            capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
    }

    companion object {
        private const val BASE_BACKOFF_SECONDS = 5L
        private const val MAX_BACKOFF_SECONDS = 120L
        private const val MAX_RETRY_ATTEMPTS = 8
        private const val RETRY_WORK_NAME = "aviator_pro_retry_sync"
    }
}
