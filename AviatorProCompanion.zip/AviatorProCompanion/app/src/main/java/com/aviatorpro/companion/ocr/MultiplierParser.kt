package com.aviatorpro.companion.ocr

import java.util.Locale
import kotlin.math.abs

data class OcrLineObservation(
    val text: String,
    val confidence: Float,
    val topPx: Int,
    val heightPx: Int
)

data class MultiplierCandidate(
    val value: Double,
    val formattedText: String,
    val confidence: Float,
    val heightPx: Int,
    val lineText: String
)

data class ParsedScreenFrame(
    val primaryCandidate: MultiplierCandidate?,
    val hasCrashBanner: Boolean,
    val hasCountdownBanner: Boolean,
    val rawSummary: String?
)

object MultiplierParser {

    const val MIN_OCR_CONFIDENCE = 0.70f
    private const val MIN_MULTIPLIER = 1.00
    private const val MAX_MULTIPLIER = 100_000.00

    // Matches multipliers with explicit decimal + two fractional digits + 'x' suffix:
    // e.g. 1.25x, 2.00x, 5.67x, 10.50x, 100.00x
    private val MULTIPLIER_REGEX = Regex("""(?<![\d$€£¥₹%])(\d{1,5})[.,](\d{2})\s*[xX×](?![\w%])""")

    private val CRASH_KEYWORDS = listOf(
        "FLEW AWAY",
        "FLEW",
        "CRASHED",
        "BUSTED",
        "ROUND OVER"
    )

    private val COUNTDOWN_KEYWORDS = listOf(
        "NEXT ROUND",
        "WAITING FOR",
        "STARTING IN",
        "PLACE YOUR BET",
        "BETTING",
        "WAIT FOR NEXT"
    )

    fun parseFrame(lines: List<OcrLineObservation>): ParsedScreenFrame {
        if (lines.isEmpty()) {
            return ParsedScreenFrame(
                primaryCandidate = null,
                hasCrashBanner = false,
                hasCountdownBanner = false,
                rawSummary = null
            )
        }

        val combinedUpper = lines.joinToString(" ") { it.text }.uppercase(Locale.US)
        val hasCrashBanner = CRASH_KEYWORDS.any { combinedUpper.contains(it) }
        val hasCountdownBanner = COUNTDOWN_KEYWORDS.any { combinedUpper.contains(it) }

        val candidates = mutableListOf<MultiplierCandidate>()

        for (line in lines) {
            if (line.confidence < MIN_OCR_CONFIDENCE) continue
            val trimmed = line.text.trim()
            if (trimmed.isEmpty()) continue

            // Reject obvious countdown seconds lines (e.g., "4.5s", "STARTING IN 3s")
            if (trimmed.contains(Regex("""\b\d+(\.\d+)?\s*(s|sec|secs)\b""", RegexOption.IGNORE_CASE))) {
                continue
            }

            for (match in MULTIPLIER_REGEX.findAll(trimmed)) {
                val wholePart = match.groupValues[1]
                val fracPart = match.groupValues[2]
                val numeric = "$wholePart.$fracPart".toDoubleOrNull() ?: continue
                if (numeric < MIN_MULTIPLIER || numeric > MAX_MULTIPLIER) continue

                val formatted = String.format(Locale.US, "%.2fx", numeric)
                candidates += MultiplierCandidate(
                    value = numeric,
                    formattedText = formatted,
                    confidence = line.confidence.coerceIn(0f, 1f),
                    heightPx = line.heightPx,
                    lineText = trimmed
                )
            }
        }

        // Prefer the largest-rendered multiplier (main center readout over small history strip chips)
        val primary = candidates.maxWithOrNull(
            compareBy<MultiplierCandidate> { it.heightPx }
                .thenBy { it.confidence }
        )

        return ParsedScreenFrame(
            primaryCandidate = primary,
            hasCrashBanner = hasCrashBanner,
            hasCountdownBanner = hasCountdownBanner,
            rawSummary = primary?.formattedText ?: if (hasCountdownBanner) "Countdown" else null
        )
    }

    fun roughlyEqual(a: Double, b: Double): Boolean = abs(a - b) < 0.005
}
