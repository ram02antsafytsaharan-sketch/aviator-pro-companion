package com.aviatorpro.companion.analytics

import com.aviatorpro.companion.data.local.RoundRecordEntity
import com.aviatorpro.companion.ocr.MultiplierParser
import com.aviatorpro.companion.ocr.OcrLineObservation
import com.aviatorpro.companion.ocr.RoundStateMachine
import com.aviatorpro.companion.service.LiveRoundPhase
import com.aviatorpro.companion.service.RoundLiveTelemetry
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.ZoneId
import java.time.ZoneOffset

class RoundTimingAndAnalyticsTest {

    @Test
    fun roundStateMachineTracksWaitingStartIncreasingCrashAndNextRound() {
        val stateMachine = RoundStateMachine(ZoneOffset.UTC)

        // 1. Waiting / countdown period starts at t = 10_000 ms
        val waitFrame1 = MultiplierParser.parseFrame(
            listOf(OcrLineObservation("WAITING FOR NEXT ROUND", 0.94f, 380, 48))
        )
        assertNull(stateMachine.onFrameParsed(waitFrame1, nowEpochMs = 10_000L))
        assertEquals(LiveRoundPhase.WAITING, stateMachine.liveTelemetry.phase)
        assertEquals(10_000L, stateMachine.liveTelemetry.waitingStartedAtEpochMs)

        // 2. Round 1 starts at t = 15_200 ms (wait = 5.20s)
        val startFrame = MultiplierParser.parseFrame(
            listOf(OcrLineObservation("1.08x", 0.95f, 400, 120))
        )
        assertNull(stateMachine.onFrameParsed(startFrame, nowEpochMs = 15_200L))
        assertEquals(LiveRoundPhase.FLYING, stateMachine.liveTelemetry.phase)
        assertEquals(15_200L, stateMachine.liveTelemetry.roundStartedAtEpochMs)
        assertEquals(5.20, stateMachine.liveTelemetry.lastCompletedWaitingSeconds ?: -1.0, 0.001)
        assertFalse(stateMachine.liveTelemetry.isMultiplierIncreasing)

        // 3. Multiplier increases cleanly during flight
        val climbFrame1 = MultiplierParser.parseFrame(
            listOf(OcrLineObservation("1.65x", 0.95f, 400, 120))
        )
        assertNull(stateMachine.onFrameParsed(climbFrame1, nowEpochMs = 16_400L))
        assertTrue(stateMachine.liveTelemetry.isMultiplierIncreasing)

        val climbFrame2 = MultiplierParser.parseFrame(
            listOf(OcrLineObservation("2.80x", 0.96f, 400, 120))
        )
        assertNull(stateMachine.onFrameParsed(climbFrame2, nowEpochMs = 18_100L))
        assertTrue(stateMachine.liveTelemetry.isMultiplierIncreasing)

        // 4. Round 1 crashes at t = 19_400 ms (duration = 4.20s)
        val crashFrame1 = MultiplierParser.parseFrame(
            listOf(
                OcrLineObservation("FLEW AWAY!", 0.93f, 340, 44),
                OcrLineObservation("3.45x", 0.96f, 400, 120)
            )
        )
        val round1 = stateMachine.onFrameParsed(crashFrame1, nowEpochMs = 19_400L)
        assertNotNull(round1)
        assertEquals(3.45, round1!!.multiplier, 0.001)
        assertEquals(15_200L, round1.roundStartedAtEpochMs)
        assertEquals("1970-01-01T00:00:15.200Z", round1.roundStartedAtIso)
        assertEquals(4.20, round1.roundDurationSeconds ?: -1.0, 0.001)
        assertEquals(5.20, round1.waitingTimeBeforeStartSeconds ?: -1.0, 0.001)
        assertEquals(LiveRoundPhase.CRASHED, stateMachine.liveTelemetry.phase)
        assertEquals(19_400L, stateMachine.liveTelemetry.lastCrashAtEpochMs)

        // 5. Next waiting period starts at t = 20_000 ms
        assertNull(stateMachine.onFrameParsed(waitFrame1, nowEpochMs = 20_000L))
        assertEquals(LiveRoundPhase.WAITING, stateMachine.liveTelemetry.phase)
        assertEquals(20_000L, stateMachine.liveTelemetry.waitingStartedAtEpochMs)

        // 6. Next round starts at t = 24_500 ms (wait = 4.50s) and crashes at t = 28_000 ms (duration = 3.50s)
        assertNull(
            stateMachine.onFrameParsed(
                MultiplierParser.parseFrame(listOf(OcrLineObservation("1.02x", 0.94f, 400, 120))),
                nowEpochMs = 24_500L
            )
        )
        val round2 = stateMachine.onFrameParsed(
            MultiplierParser.parseFrame(
                listOf(
                    OcrLineObservation("FLEW AWAY!", 0.92f, 340, 44),
                    OcrLineObservation("1.95x", 0.95f, 400, 120)
                )
            ),
            nowEpochMs = 28_000L
        )
        assertNotNull(round2)
        assertEquals(3.50, round2!!.roundDurationSeconds ?: -1.0, 0.001)
        assertEquals(4.50, round2.waitingTimeBeforeStartSeconds ?: -1.0, 0.001)
    }

    @Test
    fun missingStartAndWaitingFramesDoNotInventTimings() {
        val stateMachine = RoundStateMachine(ZoneOffset.UTC)
        val crashOnly = MultiplierParser.parseFrame(
            listOf(
                OcrLineObservation("FLEW AWAY!", 0.91f, 340, 44),
                OcrLineObservation("2.50x", 0.95f, 410, 120)
            )
        )

        val record = stateMachine.onFrameParsed(crashOnly, nowEpochMs = 50_000L)
        assertNotNull(record)
        assertNull(record!!.roundStartedAtEpochMs)
        assertNull(record.roundStartedAtIso)
        assertNull(record.roundDurationSeconds)
        assertNull(record.waitingTimeBeforeStartSeconds)
    }

    @Test
    fun preventsDuplicateStartEventsAndNeverReusesPreviousCrashTime() {
        val machine = RoundStateMachine(ZoneOffset.UTC)

        // Round 1 crashes at 1.05x at t = 21_500ms (no waiting observed)
        val round1 = machine.onFrameParsed(
            MultiplierParser.parseFrame(
                listOf(
                    OcrLineObservation("FLEW AWAY!", 0.93f, 340, 44),
                    OcrLineObservation("1.05x", 0.95f, 400, 120)
                )
            ),
            nowEpochMs = 21_500L
        )
        assertNotNull(round1)

        // Static crash frame lingers without FLEW AWAY text
        assertNull(
            machine.onFrameParsed(
                MultiplierParser.parseFrame(listOf(OcrLineObservation("1.05x", 0.95f, 400, 120))),
                nowEpochMs = 22_000L
            )
        )
        assertEquals(LiveRoundPhase.CRASHED, machine.liveTelemetry.phase)
        assertNull(machine.liveTelemetry.roundStartedAtEpochMs)

        // Waiting screen missed; Round 2 begins near 1.08x at t = 27_000ms and climbs to 1.32x at t = 27_450ms
        assertNull(
            machine.onFrameParsed(
                MultiplierParser.parseFrame(listOf(OcrLineObservation("1.08x", 0.95f, 400, 120))),
                nowEpochMs = 27_000L
            )
        )
        assertNull(
            machine.onFrameParsed(
                MultiplierParser.parseFrame(listOf(OcrLineObservation("1.32x", 0.95f, 400, 120))),
                nowEpochMs = 27_450L
            )
        )

        // Start timestamp must be 27_000ms (actual start), NEVER 21_500ms (previous crash)!
        assertEquals(LiveRoundPhase.FLYING, machine.liveTelemetry.phase)
        assertEquals(27_000L, machine.liveTelemetry.roundStartedAtEpochMs)
        assertEquals(27_450L, machine.liveTelemetry.animationStartedAtEpochMs)
        assertTrue(machine.liveTelemetry.roundStartedAtEpochMs!! > round1!!.detectedAtEpochMs)

        // Subsequent climbing frames must NOT overwrite roundStartedAtEpochMs or animationStartedAtEpochMs
        assertNull(
            machine.onFrameParsed(
                MultiplierParser.parseFrame(listOf(OcrLineObservation("2.10x", 0.96f, 400, 120))),
                nowEpochMs = 28_500L
            )
        )
        assertEquals(27_000L, machine.liveTelemetry.roundStartedAtEpochMs)
        assertEquals(27_450L, machine.liveTelemetry.animationStartedAtEpochMs)

        val round2 = machine.onFrameParsed(
            MultiplierParser.parseFrame(
                listOf(
                    OcrLineObservation("FLEW AWAY!", 0.94f, 340, 44),
                    OcrLineObservation("2.65x", 0.96f, 400, 120)
                )
            ),
            nowEpochMs = 30_000L
        )
        assertNotNull(round2)
        assertEquals(27_000L, round2!!.roundStartedAtEpochMs)
        assertEquals(3.0, round2.roundDurationSeconds ?: -1.0, 0.001)
    }

    @Test
    fun joiningMidRoundLeavesStartTimestampMissingInsteadOfFabricating() {
        val machine = RoundStateMachine(ZoneOffset.UTC)

        // Monitoring starts mid-flight at 3.40x -> 4.25x -> crash 5.10x
        assertNull(
            machine.onFrameParsed(
                MultiplierParser.parseFrame(listOf(OcrLineObservation("3.40x", 0.95f, 400, 120))),
                nowEpochMs = 10_000L
            )
        )
        assertNull(
            machine.onFrameParsed(
                MultiplierParser.parseFrame(listOf(OcrLineObservation("4.25x", 0.95f, 400, 120))),
                nowEpochMs = 10_500L
            )
        )
        assertEquals(LiveRoundPhase.FLYING, machine.liveTelemetry.phase)
        assertNull(machine.liveTelemetry.roundStartedAtEpochMs)

        val crashed = machine.onFrameParsed(
            MultiplierParser.parseFrame(
                listOf(
                    OcrLineObservation("FLEW AWAY!", 0.93f, 340, 44),
                    OcrLineObservation("5.10x", 0.96f, 400, 120)
                )
            ),
            nowEpochMs = 11_500L
        )
        assertNotNull(crashed)
        assertNull(crashed!!.roundStartedAtEpochMs)
        assertNull(crashed.roundStartedAtIso)
        assertNull(crashed.roundDurationSeconds)
    }

    @Test
    fun countdownNeverTriggersRoundStartAndLocalDisplayPreservesUtcStorage() {
        // UTC-05:00 local timezone
        val nyZone = ZoneId.of("America/New_York")
        val machine = RoundStateMachine(nyZone)

        // Multiple countdown frames must stay WAITING and not trigger start
        val wait1 = MultiplierParser.parseFrame(
            listOf(
                OcrLineObservation("STARTING IN", 0.95f, 340, 40),
                OcrLineObservation("5.0s", 0.94f, 390, 60)
            )
        )
        val wait2 = MultiplierParser.parseFrame(
            listOf(
                OcrLineObservation("NEXT ROUND IN 3s", 0.95f, 340, 40)
            )
        )
        // 2026-11-27T15:00:00Z = 10:00:00 America/New_York (EST, UTC-5)
        val waitStartMs = java.time.Instant.parse("2026-11-27T15:00:00Z").toEpochMilli()
        assertNull(machine.onFrameParsed(wait1, nowEpochMs = waitStartMs))
        assertNull(machine.onFrameParsed(wait2, nowEpochMs = waitStartMs + 2_000L))
        assertEquals(LiveRoundPhase.WAITING, machine.liveTelemetry.phase)
        assertEquals(waitStartMs, machine.liveTelemetry.waitingStartedAtEpochMs)
        assertNull(machine.liveTelemetry.roundStartedAtEpochMs)

        // Round starts at 15:00:05Z (wait = 5.0s)
        val roundStartMs = waitStartMs + 5_000L
        assertNull(
            machine.onFrameParsed(
                MultiplierParser.parseFrame(listOf(OcrLineObservation("1.03x", 0.95f, 400, 120))),
                nowEpochMs = roundStartMs
            )
        )
        // Crash at 15:00:11Z (10:00:11 EST, duration = 6.0s)
        val crashMs = waitStartMs + 11_000L
        val record = machine.onFrameParsed(
            MultiplierParser.parseFrame(
                listOf(
                    OcrLineObservation("FLEW AWAY!", 0.94f, 340, 44),
                    OcrLineObservation("2.20x", 0.96f, 400, 120)
                )
            ),
            nowEpochMs = crashMs
        )
        assertNotNull(record)
        assertEquals("2026-11-27T15:00:05Z", record!!.roundStartedAtIso)
        assertEquals("2026-11-27T15:00:11Z", record.detectedAtIso)
        assertEquals("2026-11-27", record.detectionDate)
        assertEquals("10:00:11", record.detectionTime)
        assertEquals(6.0, record.roundDurationSeconds ?: -1.0, 0.001)
    }

    @Test
    fun computesTargetFrequenciesStreaksAndRecentWindows() {
        // 10 rounds chronological:
        // [1.05, 1.15, 1.30, 1.80, 2.50, 1.10, 4.20, 6.00, 12.50, 1.40]
        val multipliers = listOf(1.05, 1.15, 1.30, 1.80, 2.50, 1.10, 4.20, 6.00, 12.50, 1.40)
        val records = multipliers.mapIndexed { index, value ->
            makeRound(
                index = index,
                multiplier = value,
                durationSec = 2.0 + index,
                waitSec = 4.0 + (index % 3)
            )
        }

        val summary = RoundAnalyticsEngine.analyze(records)

        assertEquals(10, summary.totalRounds)
        assertEquals(3.20, summary.averageMultiplier ?: 0.0, 0.001)
        assertEquals(12.50, summary.highestMultiplier ?: 0.0, 0.001)
        assertEquals(1.05, summary.lowestMultiplier ?: 0.0, 0.001)

        val byTarget = summary.targetStats.associateBy { it.label }

        // 1.20x: misses are 1.05, 1.15 (streak 2), 1.10 (streak 1) -> 7/10 = 70%
        val stat120 = byTarget.getValue("1.20x")
        assertEquals(7, stat120.hitCount)
        assertEquals(70.0, stat120.hitPercentage, 0.01)
        assertEquals(2, stat120.longestSequenceBelow)
        assertEquals(0, stat120.currentSequenceBelow)

        // 2.00x: hits are 2.50, 4.20, 6.00, 12.50 -> 4/10 = 40%; max streak below = 4 (first 4); current = 1 (1.40)
        val stat200 = byTarget.getValue("2.00x")
        assertEquals(4, stat200.hitCount)
        assertEquals(40.0, stat200.hitPercentage, 0.01)
        assertEquals(4, stat200.longestSequenceBelow)
        assertEquals(1, stat200.currentSequenceBelow)

        // 10.00x: hit is 12.50 -> 1/10 = 10%; max streak below = 8; current = 1
        val stat1000 = byTarget.getValue("10.00x")
        assertEquals(1, stat1000.hitCount)
        assertEquals(10.0, stat1000.hitPercentage, 0.01)
        assertEquals(8, stat1000.longestSequenceBelow)
        assertEquals(1, stat1000.currentSequenceBelow)

        assertEquals(10, summary.window20.actualCount)
        assertEquals(10, summary.window50.actualCount)
        assertEquals(10, summary.window100.actualCount)
    }

    @Test
    fun computesWindows20_50_100AndTimingEstimates() {
        val rounds = (1..110).map { i ->
            makeRound(
                index = i,
                multiplier = if (i > 90) 3.00 else 1.50,
                durationSec = 4.0 + (i % 5),
                waitSec = 5.0 + (i % 4)
            )
        }

        val liveTelemetry = RoundLiveTelemetry(
            phase = LiveRoundPhase.WAITING,
            waitingStartedAtEpochMs = 1_000_000L
        )

        val summary = RoundAnalyticsEngine.analyze(
            rounds = rounds,
            liveTelemetry = liveTelemetry,
            nowEpochMs = 1_002_000L // 2.0s elapsed waiting
        )

        assertEquals(20, summary.window20.actualCount)
        assertEquals(3.00, summary.window20.averageMultiplier ?: 0.0, 0.001)
        assertEquals(100.0, summary.window20.aboveTwoXPercentage ?: 0.0, 0.01)

        assertEquals(50, summary.window50.actualCount)
        assertEquals(100, summary.window100.actualCount)

        assertEquals(110, summary.timing.observedDurationCount)
        assertEquals(4.0, summary.timing.shortestRoundDurationSeconds ?: 0.0, 0.001)
        assertEquals(8.0, summary.timing.longestRoundDurationSeconds ?: 0.0, 0.001)

        assertEquals(110, summary.timing.observedWaitingCount)
        assertEquals(5.0, summary.timing.shortestWaitingTimeSeconds ?: 0.0, 0.001)
        assertEquals(8.0, summary.timing.longestWaitingTimeSeconds ?: 0.0, 0.001)

        assertEquals(DataConfidenceLevel.HIGH, summary.estimate.dataConfidence)
        assertNotNull(summary.estimate.estimatedRemainingLowSec)
        assertNotNull(summary.estimate.estimatedRemainingHighSec)
        assertTrue(summary.estimate.disclaimer.contains("do not predict", ignoreCase = true))
    }

    private fun makeRound(
        index: Int,
        multiplier: Double,
        durationSec: Double?,
        waitSec: Double?
    ): RoundRecordEntity {
        val epochMs = 1_764_180_000_000L + (index * 15_000L)
        return RoundRecordEntity(
            roundId = "APC-TEST-$index",
            multiplier = multiplier,
            formattedMultiplier = String.format(java.util.Locale.US, "%.2fx", multiplier),
            detectionDate = "2026-11-27",
            detectionTime = "08:00:00",
            detectedAtIso = java.time.Instant.ofEpochMilli(epochMs).toString(),
            detectedAtEpochMs = epochMs,
            ocrConfidence = 0.95f,
            roundDurationSeconds = durationSec,
            waitingTimeBeforeStartSeconds = waitSec
        )
    }
}
