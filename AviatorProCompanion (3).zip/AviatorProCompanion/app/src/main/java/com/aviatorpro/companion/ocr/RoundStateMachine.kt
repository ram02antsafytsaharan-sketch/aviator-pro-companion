package com.aviatorpro.companion.ocr

import com.aviatorpro.companion.data.local.RoundRecordEntity
import com.aviatorpro.companion.service.LiveRoundPhase
import com.aviatorpro.companion.service.RoundLiveTelemetry
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.UUID

class RoundStateMachine(
    private val zoneId: ZoneId = ZoneId.systemDefault()
) {

    private enum class Phase {
        IDLE,
        WAITING,
        CLIMBING,
        SETTLED
    }

    private var phase: Phase = Phase.IDLE
    private var lastClimbingValue: Double? = null
    private var stableCandidateValue: Double? = null
    private var stableConsecutiveFrames: Int = 0
    private var stableFirstSeenEpochMs: Long = 0L

    private var lastCommittedValue: Double? = null
    private var lastCommittedEpochMs: Long = 0L
    private var roundTransitionObservedSinceCommit: Boolean = true

    // Real-time timing state (only populated from genuinely observed OCR transitions)
    private var waitingStartedAtEpochMs: Long? = null
    private var waitingStartedAtIso: String? = null
    private var activeRoundStartedAtEpochMs: Long? = null
    private var activeRoundStartedAtIso: String? = null
    private var animationStartedAtEpochMs: Long? = null
    private var animationStartedAtIso: String? = null
    private var pendingWaitingTimeBeforeStartSec: Double? = null
    private var isMultiplierIncreasing: Boolean = false

    private var lastCompletedWaitingSec: Double? = null
    private var lastCompletedMultiplier: String? = null
    private var lastCrashAtEpochMs: Long? = null
    private var lastCrashAtIso: String? = null
    private var lastRoundDurationSec: Double? = null
    private var currentMultiplierText: String? = null

    val liveTelemetry: RoundLiveTelemetry
        get() = RoundLiveTelemetry(
            phase = when (phase) {
                Phase.IDLE -> LiveRoundPhase.IDLE
                Phase.WAITING -> LiveRoundPhase.WAITING
                Phase.CLIMBING -> LiveRoundPhase.FLYING
                Phase.SETTLED -> LiveRoundPhase.CRASHED
            },
            currentMultiplierText = currentMultiplierText,
            isMultiplierIncreasing = isMultiplierIncreasing,
            roundStartedAtEpochMs = activeRoundStartedAtEpochMs,
            roundStartedAtIso = activeRoundStartedAtIso,
            animationStartedAtEpochMs = animationStartedAtEpochMs,
            animationStartedAtIso = animationStartedAtIso,
            waitingStartedAtEpochMs = waitingStartedAtEpochMs,
            waitingStartedAtIso = waitingStartedAtIso,
            lastCompletedWaitingSeconds = lastCompletedWaitingSec,
            lastCompletedMultiplier = lastCompletedMultiplier,
            lastCrashAtEpochMs = lastCrashAtEpochMs,
            lastCrashAtIso = lastCrashAtIso,
            lastRoundDurationSeconds = lastRoundDurationSec
        )

    fun reset() {
        phase = Phase.IDLE
        lastClimbingValue = null
        stableCandidateValue = null
        stableConsecutiveFrames = 0
        stableFirstSeenEpochMs = 0L
        lastCommittedValue = null
        lastCommittedEpochMs = 0L
        roundTransitionObservedSinceCommit = true
        waitingStartedAtEpochMs = null
        waitingStartedAtIso = null
        activeRoundStartedAtEpochMs = null
        activeRoundStartedAtIso = null
        animationStartedAtEpochMs = null
        animationStartedAtIso = null
        pendingWaitingTimeBeforeStartSec = null
        isMultiplierIncreasing = false
        lastCompletedWaitingSec = null
        lastCompletedMultiplier = null
        lastCrashAtEpochMs = null
        lastCrashAtIso = null
        lastRoundDurationSec = null
        currentMultiplierText = null
    }

    fun onFrameParsed(
        frame: ParsedScreenFrame,
        nowEpochMs: Long? = null
    ): RoundRecordEntity? {
        val currentInstant = if (nowEpochMs != null) {
            Instant.ofEpochMilli(nowEpochMs)
        } else {
            Instant.now()
        }
        val effectiveEpochMs = nowEpochMs ?: currentInstant.toEpochMilli()

        // Countdown / betting window active without a crash banner:
        // Never confuse countdown with round start or record a completed round.
        if (frame.hasCountdownBanner && !frame.hasCrashBanner) {
            if (phase != Phase.WAITING) {
                waitingStartedAtEpochMs = effectiveEpochMs
                waitingStartedAtIso = currentInstant.toString()
            }
            phase = Phase.WAITING
            lastClimbingValue = null
            stableCandidateValue = null
            stableConsecutiveFrames = 0
            stableFirstSeenEpochMs = 0L
            activeRoundStartedAtEpochMs = null
            activeRoundStartedAtIso = null
            animationStartedAtEpochMs = null
            animationStartedAtIso = null
            pendingWaitingTimeBeforeStartSec = null
            isMultiplierIncreasing = false
            currentMultiplierText = null
            roundTransitionObservedSinceCommit = true
            return null
        }

        val candidate = frame.primaryCandidate ?: return null

        // Case 1: Explicit crash / round-ended banner visible on screen
        if (frame.hasCrashBanner) {
            currentMultiplierText = candidate.formattedText
            return commitIfNotDuplicate(
                candidate = candidate,
                detectionInstant = currentInstant,
                nowEpochMs = effectiveEpochMs
            )
        }

        // Case 2: Non-crash multiplier frame
        currentMultiplierText = candidate.formattedText

        when (phase) {
            Phase.WAITING -> {
                // Waiting banner disappeared and first active round multiplier appeared.
                // Guard against emitting a start event equal to or earlier than the last crash.
                if (lastCommittedEpochMs == 0L || effectiveEpochMs > lastCommittedEpochMs) {
                    startObservedRoundFromWaiting(
                        candidate = candidate,
                        startedInstant = currentInstant,
                        startedEpochMs = effectiveEpochMs
                    )
                }
                return null
            }

            Phase.IDLE -> {
                val prevStable = stableCandidateValue
                if (prevStable != null && MultiplierParser.roughlyEqual(prevStable, candidate.value)) {
                    stableConsecutiveFrames += 1
                    return null
                }

                val valueIncreased = prevStable != null && candidate.value > prevStable + 0.005
                if (valueIncreased && stableFirstSeenEpochMs > 0L) {
                    // Observed multiplier climbing without having seen a waiting banner first.
                    // Only treat stableFirstSeenEpochMs as actual start if it began near 1.00x.
                    enterClimbingMidSession(
                        initialValue = prevStable!!,
                        initialEpochMs = stableFirstSeenEpochMs,
                        currentValue = candidate.value,
                        climbInstant = currentInstant,
                        climbEpochMs = effectiveEpochMs
                    )
                }
                stableCandidateValue = candidate.value
                stableConsecutiveFrames = 1
                stableFirstSeenEpochMs = effectiveEpochMs
                return null
            }

            Phase.SETTLED -> {
                // Ignore lingering static crash screen values if waiting banner was missed
                val lastCommitted = lastCommittedValue
                if (lastCommitted != null &&
                    MultiplierParser.roughlyEqual(candidate.value, lastCommitted) &&
                    !roundTransitionObservedSinceCommit &&
                    stableCandidateValue == null
                ) {
                    return null
                }

                val prevStable = stableCandidateValue
                if (prevStable != null && MultiplierParser.roughlyEqual(prevStable, candidate.value)) {
                    stableConsecutiveFrames += 1
                    return null
                }

                val valueIncreased = prevStable != null &&
                    candidate.value > prevStable + 0.005 &&
                    stableFirstSeenEpochMs > lastCommittedEpochMs

                if (valueIncreased) {
                    enterClimbingMidSession(
                        initialValue = prevStable!!,
                        initialEpochMs = stableFirstSeenEpochMs,
                        currentValue = candidate.value,
                        climbInstant = currentInstant,
                        climbEpochMs = effectiveEpochMs
                    )
                }

                stableCandidateValue = candidate.value
                stableConsecutiveFrames = 1
                stableFirstSeenEpochMs = effectiveEpochMs
                return null
            }

            Phase.CLIMBING -> {
                val prevStable = stableCandidateValue
                if (prevStable != null && MultiplierParser.roughlyEqual(prevStable, candidate.value)) {
                    stableConsecutiveFrames += 1
                    val stableDurationMs = effectiveEpochMs - stableFirstSeenEpochMs
                    if (stableConsecutiveFrames >= MIN_STABLE_FRAMES &&
                        stableDurationMs >= MIN_STABLE_DURATION_MS
                    ) {
                        return commitIfNotDuplicate(
                            candidate = candidate,
                            detectionInstant = currentInstant,
                            nowEpochMs = effectiveEpochMs
                        )
                    }
                    return null
                }

                val valueIncreased = prevStable != null && candidate.value > prevStable + 0.005
                if (valueIncreased) {
                    lastClimbingValue = candidate.value
                    if (!isMultiplierIncreasing) {
                        isMultiplierIncreasing = true
                        if (animationStartedAtEpochMs == null) {
                            animationStartedAtEpochMs = effectiveEpochMs
                            animationStartedAtIso = currentInstant.toString()
                        }
                    }
                    roundTransitionObservedSinceCommit = true
                }

                // Do NOT overwrite activeRoundStartedAtEpochMs once set for this round
                stableCandidateValue = candidate.value
                stableConsecutiveFrames = 1
                stableFirstSeenEpochMs = effectiveEpochMs
                return null
            }
        }
    }

    private fun startObservedRoundFromWaiting(
        candidate: MultiplierCandidate,
        startedInstant: Instant,
        startedEpochMs: Long
    ) {
        // Prevent duplicate start event for an already-active round
        if (activeRoundStartedAtEpochMs != null) return

        val waitStart = waitingStartedAtEpochMs
        if (waitStart != null && startedEpochMs >= waitStart) {
            val waitSeconds = (startedEpochMs - waitStart) / 1000.0
            pendingWaitingTimeBeforeStartSec = waitSeconds
            lastCompletedWaitingSec = waitSeconds
        } else {
            pendingWaitingTimeBeforeStartSec = null
        }

        waitingStartedAtEpochMs = null
        waitingStartedAtIso = null
        activeRoundStartedAtEpochMs = startedEpochMs
        activeRoundStartedAtIso = startedInstant.toString()
        animationStartedAtEpochMs = null
        animationStartedAtIso = null
        isMultiplierIncreasing = false
        phase = Phase.CLIMBING
        lastClimbingValue = candidate.value
        stableCandidateValue = candidate.value
        stableConsecutiveFrames = 1
        stableFirstSeenEpochMs = startedEpochMs
        roundTransitionObservedSinceCommit = true
    }

    private fun enterClimbingMidSession(
        initialValue: Double,
        initialEpochMs: Long,
        currentValue: Double,
        climbInstant: Instant,
        climbEpochMs: Long
    ) {
        phase = Phase.CLIMBING
        lastClimbingValue = currentValue
        isMultiplierIncreasing = true
        roundTransitionObservedSinceCommit = true
        if (animationStartedAtEpochMs == null) {
            animationStartedAtEpochMs = climbEpochMs
            animationStartedAtIso = climbInstant.toString()
        }

        // Only lock in an observed start timestamp if we actually observed near 1.00x
        // strictly after the previous round's crash timestamp.
        if (activeRoundStartedAtEpochMs == null &&
            initialValue <= MAX_CONFIRMED_LOW_START_MULTIPLIER &&
            initialEpochMs > lastCommittedEpochMs
        ) {
            activeRoundStartedAtEpochMs = initialEpochMs
            activeRoundStartedAtIso = Instant.ofEpochMilli(initialEpochMs).toString()
        }
    }

    private fun commitIfNotDuplicate(
        candidate: MultiplierCandidate,
        detectionInstant: Instant,
        nowEpochMs: Long
    ): RoundRecordEntity? {
        val lastValue = lastCommittedValue
        val elapsedSinceCommit = nowEpochMs - lastCommittedEpochMs

        // Suppress duplicate emissions while the crash screen or static history remains visible
        if (lastValue != null &&
            MultiplierParser.roughlyEqual(lastValue, candidate.value) &&
            (!roundTransitionObservedSinceCommit || elapsedSinceCommit < MIN_SAME_VALUE_COOLDOWN_MS)
        ) {
            phase = Phase.SETTLED
            return null
        }

        // Guard against re-emitting if still in SETTLED without a new round transition
        if (phase == Phase.SETTLED && !roundTransitionObservedSinceCommit) {
            return null
        }

        // Never allow previous round's crash time (or earlier) to become this round's start time
        val observedStartEpoch = activeRoundStartedAtEpochMs?.takeIf { startMs ->
            startMs <= nowEpochMs && (lastCommittedEpochMs == 0L || startMs > lastCommittedEpochMs)
        }
        val observedStartIso = if (observedStartEpoch != null) activeRoundStartedAtIso else null

        val observedDurationSec = if (observedStartEpoch != null) {
            (nowEpochMs - observedStartEpoch) / 1000.0
        } else {
            null
        }
        val observedWaitingSec = if (observedStartEpoch != null) {
            pendingWaitingTimeBeforeStartSec
        } else {
            null
        }

        phase = Phase.SETTLED
        lastCommittedValue = candidate.value
        lastCommittedEpochMs = nowEpochMs
        roundTransitionObservedSinceCommit = false
        lastClimbingValue = null
        // Clear candidate tracking so settled crash screen timestamps can never leak into next round
        stableCandidateValue = null
        stableConsecutiveFrames = 0
        stableFirstSeenEpochMs = 0L

        lastCompletedMultiplier = candidate.formattedText
        lastCrashAtEpochMs = nowEpochMs
        lastCrashAtIso = detectionInstant.toString()
        lastRoundDurationSec = observedDurationSec

        activeRoundStartedAtEpochMs = null
        activeRoundStartedAtIso = null
        animationStartedAtEpochMs = null
        animationStartedAtIso = null
        pendingWaitingTimeBeforeStartSec = null
        waitingStartedAtEpochMs = null
        waitingStartedAtIso = null
        isMultiplierIncreasing = false

        val zoned = detectionInstant.atZone(zoneId)
        val shortUuid = UUID.randomUUID().toString().substring(0, 8)

        return RoundRecordEntity(
            roundId = "APC-$nowEpochMs-$shortUuid",
            multiplier = candidate.value,
            formattedMultiplier = candidate.formattedText,
            detectionDate = DATE_FORMATTER.format(zoned),
            detectionTime = TIME_FORMATTER.format(zoned),
            detectedAtIso = detectionInstant.toString(),
            detectedAtEpochMs = nowEpochMs,
            ocrConfidence = candidate.confidence,
            roundStartedAtIso = observedStartIso,
            roundStartedAtEpochMs = observedStartEpoch,
            roundDurationSeconds = observedDurationSec,
            waitingTimeBeforeStartSeconds = observedWaitingSec
        )
    }

    companion object {
        private const val MIN_STABLE_FRAMES = 3
        private const val MIN_STABLE_DURATION_MS = 1_100L
        private const val MIN_SAME_VALUE_COOLDOWN_MS = 4_500L
        private const val MAX_CONFIRMED_LOW_START_MULTIPLIER = 1.25

        private val DATE_FORMATTER: DateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd")
        private val TIME_FORMATTER: DateTimeFormatter = DateTimeFormatter.ofPattern("HH:mm:ss")
    }
}
