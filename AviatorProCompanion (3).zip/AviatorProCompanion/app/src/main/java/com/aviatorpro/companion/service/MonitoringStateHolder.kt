package com.aviatorpro.companion.service

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

sealed interface MonitoringStatus {
    data object Idle : MonitoringStatus
    data object Starting : MonitoringStatus
    data class Active(
        val startedAtEpochMs: Long,
        val framesAnalyzed: Long = 0L,
        val roundsDetectedThisSession: Int = 0,
        val lastCandidateText: String? = null
    ) : MonitoringStatus
    data class Error(val message: String) : MonitoringStatus
}

sealed interface ConnectionStatus {
    data object Unverified : ConnectionStatus
    data object Checking : ConnectionStatus
    data class Connected(
        val httpCode: Int,
        val serverMessage: String,
        val verifiedAtEpochMs: Long
    ) : ConnectionStatus
    data class Error(
        val httpCode: Int?,
        val message: String,
        val isRetrying: Boolean = false
    ) : ConnectionStatus
}

enum class LiveRoundPhase {
    IDLE,
    WAITING,
    FLYING,
    CRASHED
}

data class RoundLiveTelemetry(
    val phase: LiveRoundPhase = LiveRoundPhase.IDLE,
    val currentMultiplierText: String? = null,
    val isMultiplierIncreasing: Boolean = false,
    val roundStartedAtEpochMs: Long? = null,
    val roundStartedAtIso: String? = null,
    val animationStartedAtEpochMs: Long? = null,
    val animationStartedAtIso: String? = null,
    val waitingStartedAtEpochMs: Long? = null,
    val waitingStartedAtIso: String? = null,
    val lastCompletedWaitingSeconds: Double? = null,
    val lastCompletedMultiplier: String? = null,
    val lastCrashAtEpochMs: Long? = null,
    val lastCrashAtIso: String? = null,
    val lastRoundDurationSeconds: Double? = null
)

object MonitoringStateHolder {

    private val _monitoringStatus = MutableStateFlow<MonitoringStatus>(MonitoringStatus.Idle)
    val monitoringStatus: StateFlow<MonitoringStatus> = _monitoringStatus.asStateFlow()

    private val _connectionStatus = MutableStateFlow<ConnectionStatus>(ConnectionStatus.Unverified)
    val connectionStatus: StateFlow<ConnectionStatus> = _connectionStatus.asStateFlow()

    private val _roundTelemetry = MutableStateFlow(RoundLiveTelemetry())
    val roundTelemetry: StateFlow<RoundLiveTelemetry> = _roundTelemetry.asStateFlow()

    fun setMonitoringStatus(status: MonitoringStatus) {
        _monitoringStatus.value = status
        if (status is MonitoringStatus.Idle || status is MonitoringStatus.Error) {
            _roundTelemetry.update {
                it.copy(
                    phase = LiveRoundPhase.IDLE,
                    currentMultiplierText = null,
                    isMultiplierIncreasing = false,
                    roundStartedAtEpochMs = null,
                    roundStartedAtIso = null,
                    animationStartedAtEpochMs = null,
                    animationStartedAtIso = null,
                    waitingStartedAtEpochMs = null,
                    waitingStartedAtIso = null
                )
            }
        }
    }

    fun recordFrameAnalyzed(candidateText: String?) {
        _monitoringStatus.update { current ->
            if (current is MonitoringStatus.Active) {
                current.copy(
                    framesAnalyzed = current.framesAnalyzed + 1L,
                    lastCandidateText = candidateText ?: current.lastCandidateText
                )
            } else {
                current
            }
        }
    }

    fun incrementSessionRounds() {
        _monitoringStatus.update { current ->
            if (current is MonitoringStatus.Active) {
                current.copy(roundsDetectedThisSession = current.roundsDetectedThisSession + 1)
            } else {
                current
            }
        }
    }

    fun updateRoundTelemetry(telemetry: RoundLiveTelemetry) {
        _roundTelemetry.value = telemetry
    }

    fun setConnectionStatus(status: ConnectionStatus) {
        _connectionStatus.value = status
    }
}
