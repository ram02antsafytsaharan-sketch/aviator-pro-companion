package com.aviatorpro.companion.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(
    entities = [RoundRecordEntity::class],
    version = 2,
    exportSchema = true
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun roundRecordDao(): RoundRecordDao

    companion object {
        @Volatile
        private var instance: AppDatabase? = null

        val MIGRATION_1_2: Migration = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE round_records ADD COLUMN roundStartedAtIso TEXT")
                db.execSQL("ALTER TABLE round_records ADD COLUMN roundStartedAtEpochMs INTEGER")
                db.execSQL("ALTER TABLE round_records ADD COLUMN roundDurationSeconds REAL")
                db.execSQL("ALTER TABLE round_records ADD COLUMN waitingTimeBeforeStartSeconds REAL")
            }
        }

        fun getInstance(context: Context): AppDatabase {
            return instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "aviator_pro_companion.db"
                )
                    .addMigrations(MIGRATION_1_2)
                    .build()
                    .also { instance = it }
            }
        }
    }
}
