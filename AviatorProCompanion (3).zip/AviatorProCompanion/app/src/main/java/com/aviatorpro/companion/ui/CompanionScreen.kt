package com.aviatorpro.companion.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Monitor
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aviatorpro.companion.analytics.DataConfidenceLevel
import com.aviatorpro.companion.analytics.MultiplierTargetStat
import com.aviatorpro.companion.analytics.RiskLevel
import com.aviatorpro.companion.analytics.RoundAnalyticsSummary
import com.aviatorpro.companion.analytics.WindowSummary
import com.aviatorpro.companion.data.local.RoundRecordEntity
import com.aviatorpro.companion.data.local.SyncStatus
import com.aviatorpro.companion.service.ConnectionStatus
import com.aviatorpro.companion.service.LiveRoundPhase
import com.aviatorpro.companion.service.MonitoringStatus
import com.aviatorpro.companion.service.RoundLiveTelemetry
import com.aviatorpro.companion.ui.theme.AviatorColors
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale

private enum class DashboardTab {
    MONITOR,
    ANALYSIS
}

private val LOCAL_TIME_FORMATTER: DateTimeFormatter = DateTimeFormatter.ofPattern("HH:mm:ss")
private val LOCAL_DATE_TIME_FORMATTER: DateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CompanionScreen(
    uiState: CompanionUiState,
    onIngestEndpointChanged: (String) -> Unit,
    onHandshakeEndpointChanged: (String) -> Unit,
    onDeviceNameChanged: (String) -> Unit,
    onDeviceKeyChanged: (String) -> Unit,
    onSaveConfig: () -> Unit,
    onTestConnection: () -> Unit,
    onStartMonitoring: () -> Unit,
    onStopMonitoring: () -> Unit,
    onRetryPending: () -> Unit,
    onClearSynced: () -> Unit
) {
    var showDeviceKey by rememberSaveable { mutableStateOf(false) }
    var selectedTab by rememberSaveable { mutableStateOf(DashboardTab.MONITOR) }
    val isMonitoringActive = uiState.monitoringStatus is MonitoringStatus.Active ||
        uiState.monitoringStatus is MonitoringStatus.Starting

    var liveNowEpochMs by remember { mutableLongStateOf(System.currentTimeMillis()) }
    val telemetry = uiState.liveTelemetry
    val needsLiveTicker = isMonitoringActive && (
        telemetry.phase == LiveRoundPhase.WAITING ||
            telemetry.phase == LiveRoundPhase.FLYING ||
            telemetry.phase == LiveRoundPhase.CRASHED
        )

    LaunchedEffect(
        needsLiveTicker,
        telemetry.phase,
        telemetry.waitingStartedAtEpochMs,
        telemetry.roundStartedAtEpochMs,
        telemetry.lastCrashAtEpochMs
    ) {
        liveNowEpochMs = System.currentTimeMillis()
        while (isActive && needsLiveTicker) {
            delay(250L)
            liveNowEpochMs = System.currentTimeMillis()
        }
    }

    Scaffold(
        containerColor = AviatorColors.NavyBackground,
        topBar = {
            TopAppBar(
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = AviatorColors.NavyBackground,
                    titleContentColor = AviatorColors.WhiteText
                ),
                title = {
                    Column {
                        Text(
                            text = "AVIATOR PRO COMPANION",
                            style = MaterialTheme.typography.titleMedium,
                            color = AviatorColors.WhiteText,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = "Android 15 · ML Kit OCR & Live Analytics",
                            style = MaterialTheme.typography.bodySmall,
                            color = AviatorColors.CyanAccent
                        )
                    }
                },
                actions = {
                    ConnectionStatusBadge(
                        status = uiState.connectionStatus,
                        modifier = Modifier.padding(end = 12.dp)
                    )
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .imePadding()
        ) {
            DashboardTabSwitcher(
                selectedTab = selectedTab,
                totalRoundsCount = uiState.totalRoundsCount,
                onSelectTab = { selectedTab = it },
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
            )

            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                if (selectedTab == DashboardTab.MONITOR) {
                    item {
                        MonitoringControlCard(
                            monitoringStatus = uiState.monitoringStatus,
                            isMonitoringActive = isMonitoringActive,
                            onStartMonitoring = onStartMonitoring,
                            onStopMonitoring = onStopMonitoring
                        )
                    }

                    item {
                        LiveRoundStatusCard(
                            telemetry = uiState.liveTelemetry,
                            analytics = uiState.analytics,
                            latestRound = uiState.rounds.firstOrNull(),
                            nowEpochMs = liveNowEpochMs,
                            isCompactSummary = true,
                            onOpenAnalysis = { selectedTab = DashboardTab.ANALYSIS }
                        )
                    }

                    item {
                        ApiConfigurationCard(
                            ingestEndpointInput = uiState.ingestEndpointInput,
                            handshakeEndpointInput = uiState.handshakeEndpointInput,
                            deviceNameInput = uiState.deviceNameInput,
                            deviceKeyInput = uiState.deviceKeyInput,
                            ingestError = uiState.ingestValidationError,
                            handshakeError = uiState.handshakeValidationError,
                            savedMessage = uiState.configSavedMessage,
                            uiNotice = uiState.uiNotice,
                            connectionStatus = uiState.connectionStatus,
                            isTesting = uiState.isTestingConnection,
                            showDeviceKey = showDeviceKey,
                            onToggleDeviceKey = { showDeviceKey = !showDeviceKey },
                            onIngestEndpointChanged = onIngestEndpointChanged,
                            onHandshakeEndpointChanged = onHandshakeEndpointChanged,
                            onDeviceNameChanged = onDeviceNameChanged,
                            onDeviceKeyChanged = onDeviceKeyChanged,
                            onSaveConfig = onSaveConfig,
                            onTestConnection = onTestConnection
                        )
                    }

                    item {
                        DetectedResultsHeader(
                            totalCount = uiState.totalRoundsCount,
                            pendingCount = uiState.pendingRoundsCount,
                            hasSyncedItems = uiState.rounds.any { it.syncStatus == SyncStatus.SYNCED },
                            onRetryPending = onRetryPending,
                            onClearSynced = onClearSynced
                        )
                    }

                    if (uiState.rounds.isEmpty()) {
                        item {
                            EmptyRoundsCard()
                        }
                    } else {
                        items(
                            items = uiState.rounds,
                            key = { it.roundId }
                        ) { record ->
                            RoundRecordCard(record = record)
                        }
                    }
                } else {
                    item {
                        LiveRoundStatusCard(
                            telemetry = uiState.liveTelemetry,
                            analytics = uiState.analytics,
                            latestRound = uiState.rounds.firstOrNull(),
                            nowEpochMs = liveNowEpochMs,
                            isCompactSummary = false,
                            onOpenAnalysis = null
                        )
                    }

                    item {
                        RoundDurationAnalysisCard(analytics = uiState.analytics)
                    }

                    item {
                        HistoricalMultiplierStatisticsCard(analytics = uiState.analytics)
                    }

                    item {
                        NextRoundEstimatesCard(
                            telemetry = uiState.liveTelemetry,
                            analytics = uiState.analytics,
                            nowEpochMs = liveNowEpochMs
                        )
                    }
                }

                item {
                    Spacer(modifier = Modifier.height(16.dp))
                }
            }
        }
    }
}

@Composable
private fun DashboardTabSwitcher(
    selectedTab: DashboardTab,
    totalRoundsCount: Int,
    onSelectTab: (DashboardTab) -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(10.dp),
        color = AviatorColors.NavySurface,
        border = BorderStroke(1.dp, AviatorColors.NavyBorder)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(4.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            TabSwitchButton(
                label = "Monitor & Feed",
                icon = Icons.Default.Monitor,
                selected = selectedTab == DashboardTab.MONITOR,
                onClick = { onSelectTab(DashboardTab.MONITOR) },
                modifier = Modifier.weight(1f)
            )
            TabSwitchButton(
                label = if (totalRoundsCount > 0) "Live Analysis ($totalRoundsCount)" else "Live Analysis",
                icon = Icons.Default.Analytics,
                selected = selectedTab == DashboardTab.ANALYSIS,
                onClick = { onSelectTab(DashboardTab.ANALYSIS) },
                modifier = Modifier.weight(1f)
            )
        }
    }
}

@Composable
private fun TabSwitchButton(
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val bgColor = if (selected) AviatorColors.CyanAccent else Color.Transparent
    val fgColor = if (selected) AviatorColors.NavyBackground else AviatorColors.SlateText

    Surface(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(8.dp),
        color = bgColor
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 10.dp, horizontal = 8.dp),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = fgColor,
                modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = label,
                fontSize = 13.sp,
                fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                color = fgColor,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun LiveRoundStatusCard(
    telemetry: RoundLiveTelemetry,
    analytics: RoundAnalyticsSummary,
    latestRound: RoundRecordEntity?,
    nowEpochMs: Long,
    isCompactSummary: Boolean,
    onOpenAnalysis: (() -> Unit)?
) {
    val (statusLabel, statusColor) = when (telemetry.phase) {
        LiveRoundPhase.IDLE -> "Idle" to AviatorColors.SlateText
        LiveRoundPhase.WAITING -> "Waiting for Next Round" to AviatorColors.WarningAmber
        LiveRoundPhase.FLYING -> {
            if (telemetry.isMultiplierIncreasing) {
                "Round Active · Increasing" to AviatorColors.CyanAccent
            } else {
                "Round Started" to AviatorColors.CyanAccent
            }
        }
        LiveRoundPhase.CRASHED -> "Crashed · Settled" to AviatorColors.ErrorRed
    }

    val liveWaitSeconds = when (telemetry.phase) {
        LiveRoundPhase.WAITING -> telemetry.waitingStartedAtEpochMs?.let {
            ((nowEpochMs - it).coerceAtLeast(0L)) / 1000.0
        }
        LiveRoundPhase.CRASHED -> telemetry.lastCrashAtEpochMs?.let {
            ((nowEpochMs - it).coerceAtLeast(0L)) / 1000.0
        }
        else -> null
    }

    val currentFlightElapsedSec = if (telemetry.phase == LiveRoundPhase.FLYING) {
        telemetry.roundStartedAtEpochMs?.let {
            ((nowEpochMs - it).coerceAtLeast(0L)) / 1000.0
        }
    } else {
        null
    }

    val lastMultiplierDisplay = telemetry.lastCompletedMultiplier
        ?: latestRound?.formattedMultiplier
        ?: "--"

    val lastCrashTimeDisplay = telemetry.lastCrashAtEpochMs?.let(::formatLocalTime)
        ?: latestRound?.let { formatLocalTimeFromIsoOrFallback(it.detectedAtIso, it.detectionTime) }
        ?: "--"

    val actualStartTimeDisplay = when {
        telemetry.phase == LiveRoundPhase.FLYING ->
            telemetry.roundStartedAtEpochMs?.let(::formatLocalTime) ?: "Missing (joined mid-round)"
        latestRound != null ->
            formatOptionalStartTime(latestRound.roundStartedAtIso, latestRound.roundStartedAtEpochMs)
        else -> "--"
    }

    val waitWindowLow = analytics.timing.waitingWindowLowSeconds
    val waitWindowHigh = analytics.timing.waitingWindowHighSeconds
    val nextWindowText = if (waitWindowLow != null && waitWindowHigh != null) {
        if (liveWaitSeconds != null) {
            val remLow = (waitWindowLow - liveWaitSeconds).coerceAtLeast(0.0)
            val remHigh = (waitWindowHigh - liveWaitSeconds).coerceAtLeast(0.0)
            "${formatSeconds(remLow)} – ${formatSeconds(remHigh)} left"
        } else {
            "Est. ${formatSeconds(waitWindowLow)} – ${formatSeconds(waitWindowHigh)} wait"
        }
    } else {
        "Need wait samples"
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = AviatorColors.NavySurface),
        border = BorderStroke(
            width = 1.dp,
            color = if (telemetry.phase == LiveRoundPhase.FLYING) {
                AviatorColors.CyanAccent.copy(alpha = 0.7f)
            } else {
                AviatorColors.NavyBorder
            }
        )
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "CURRENT ROUND STATUS",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = AviatorColors.SlateText,
                        letterSpacing = 0.6.sp
                    )
                    Text(
                        text = statusLabel,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = statusColor
                    )
                }

                if (telemetry.phase == LiveRoundPhase.FLYING && telemetry.currentMultiplierText != null) {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = AviatorColors.CyanMuted,
                        border = BorderStroke(1.dp, AviatorColors.CyanAccent.copy(alpha = 0.5f))
                    ) {
                        Text(
                            text = telemetry.currentMultiplierText,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            color = AviatorColors.CyanAccent
                        )
                    }
                } else if (isCompactSummary && onOpenAnalysis != null) {
                    TextButton(onClick = onOpenAnalysis) {
                        Text(
                            text = "Full Analysis",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = AviatorColors.CyanAccent
                        )
                    }
                }
            }

            HorizontalDivider(color = AviatorColors.NavyBorder.copy(alpha = 0.7f))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                MetricTile(
                    label = "LAST MULTIPLIER",
                    value = lastMultiplierDisplay,
                    accent = AviatorColors.CyanAccent,
                    modifier = Modifier.weight(1f)
                )
                MetricTile(
                    label = "LAST CRASH TIME",
                    value = lastCrashTimeDisplay,
                    accent = AviatorColors.WhiteText,
                    modifier = Modifier.weight(1f)
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                val waitLabel = when (telemetry.phase) {
                    LiveRoundPhase.FLYING -> "FLIGHT / PRE-WAIT"
                    else -> "CURRENT WAITING TIME"
                }
                val waitValue = when {
                    telemetry.phase == LiveRoundPhase.FLYING -> {
                        val flightStr = formatSecondsOrDash(currentFlightElapsedSec)
                        val preWaitStr = formatSecondsOrDash(telemetry.lastCompletedWaitingSeconds)
                        "$flightStr / $preWaitStr"
                    }
                    liveWaitSeconds != null -> formatSeconds(liveWaitSeconds)
                    telemetry.lastCompletedWaitingSeconds != null ->
                        "Last ${formatSeconds(telemetry.lastCompletedWaitingSeconds)}"
                    else -> "--"
                }

                MetricTile(
                    label = waitLabel,
                    value = waitValue,
                    accent = if (liveWaitSeconds != null) AviatorColors.WarningAmber else AviatorColors.WhiteText,
                    modifier = Modifier.weight(1f)
                )
                MetricTile(
                    label = "NEXT ROUND WINDOW",
                    value = nextWindowText,
                    accent = AviatorColors.WhiteText,
                    modifier = Modifier.weight(1f)
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                MetricTile(
                    label = if (telemetry.phase == LiveRoundPhase.FLYING) "ROUND START TIME" else "LAST START TIME",
                    value = actualStartTimeDisplay,
                    accent = if (actualStartTimeDisplay.startsWith("Missing")) AviatorColors.SlateText else AviatorColors.CyanAccent,
                    modifier = Modifier.weight(1f)
                )
                MetricTile(
                    label = "LAST DURATION",
                    value = formatSecondsOrMissing(telemetry.lastRoundDurationSeconds ?: latestRound?.roundDurationSeconds),
                    accent = AviatorColors.WhiteText,
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}

@Composable
private fun MetricTile(
    label: String,
    value: String,
    accent: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(10.dp),
        color = AviatorColors.NavySurfaceElevated,
        border = BorderStroke(1.dp, AviatorColors.NavyBorder.copy(alpha = 0.7f))
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Text(
                text = label,
                fontSize = 10.sp,
                fontWeight = FontWeight.SemiBold,
                color = AviatorColors.SlateText,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = value,
                fontSize = 15.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                color = accent,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun RoundDurationAnalysisCard(analytics: RoundAnalyticsSummary) {
    val timing = analytics.timing

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = AviatorColors.NavySurface),
        border = BorderStroke(1.dp, AviatorColors.NavyBorder)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "ROUND DURATION ANALYSIS",
                    style = MaterialTheme.typography.titleMedium,
                    color = AviatorColors.WhiteText,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "${timing.observedDurationCount} timed · ${timing.observedWaitingCount} waits",
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    color = AviatorColors.CyanAccent
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                MetricTile(
                    label = "AVG ROUND DURATION",
                    value = formatSecondsOrDash(timing.averageRoundDurationSeconds),
                    accent = AviatorColors.CyanAccent,
                    modifier = Modifier.weight(1f)
                )
                MetricTile(
                    label = "AVG WAITING TIME",
                    value = formatSecondsOrDash(timing.averageWaitingTimeSeconds),
                    accent = AviatorColors.WarningAmber,
                    modifier = Modifier.weight(1f)
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                MetricTile(
                    label = "DURATION MIN / MAX",
                    value = formatRangeOrDash(
                        timing.shortestRoundDurationSeconds,
                        timing.longestRoundDurationSeconds
                    ),
                    accent = AviatorColors.WhiteText,
                    modifier = Modifier.weight(1f)
                )
                MetricTile(
                    label = "WAITING MIN / MAX",
                    value = formatRangeOrDash(
                        timing.shortestWaitingTimeSeconds,
                        timing.longestWaitingTimeSeconds
                    ),
                    accent = AviatorColors.WhiteText,
                    modifier = Modifier.weight(1f)
                )
            }

            Text(
                text = "Only rounds where OCR observed the start or countdown transition contribute to duration and waiting intervals. Missing frames remain unrecorded.",
                fontSize = 11.sp,
                color = AviatorColors.SlateText
            )
        }
    }
}

@Composable
private fun HistoricalMultiplierStatisticsCard(analytics: RoundAnalyticsSummary) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = AviatorColors.NavySurface),
        border = BorderStroke(1.dp, AviatorColors.NavyBorder)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "HISTORICAL MULTIPLIER STATISTICS",
                    style = MaterialTheme.typography.titleMedium,
                    color = AviatorColors.WhiteText,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "${analytics.totalRounds} rounds",
                    fontSize = 12.sp,
                    fontFamily = FontFamily.Monospace,
                    color = AviatorColors.CyanAccent
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                MetricTile(
                    label = "AVERAGE",
                    value = formatMultiplierOrDash(analytics.averageMultiplier),
                    accent = AviatorColors.CyanAccent,
                    modifier = Modifier.weight(1f)
                )
                MetricTile(
                    label = "HIGHEST",
                    value = formatMultiplierOrDash(analytics.highestMultiplier),
                    accent = AviatorColors.SuccessGreen,
                    modifier = Modifier.weight(1f)
                )
                MetricTile(
                    label = "LOWEST",
                    value = formatMultiplierOrDash(analytics.lowestMultiplier),
                    accent = AviatorColors.WarningAmber,
                    modifier = Modifier.weight(1f)
                )
            }

            HorizontalDivider(color = AviatorColors.NavyBorder.copy(alpha = 0.7f))

            Text(
                text = "TARGET HIT RATES & STREAKS BELOW TARGET",
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold,
                color = AviatorColors.SlateText
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("Target", fontSize = 11.sp, color = AviatorColors.SlateText, modifier = Modifier.weight(1.0f))
                Text("Hits", fontSize = 11.sp, color = AviatorColors.SlateText, textAlign = TextAlign.End, modifier = Modifier.weight(0.9f))
                Text("Rate", fontSize = 11.sp, color = AviatorColors.SlateText, textAlign = TextAlign.End, modifier = Modifier.weight(0.9f))
                Text("Now <", fontSize = 11.sp, color = AviatorColors.SlateText, textAlign = TextAlign.End, modifier = Modifier.weight(0.8f))
                Text("Max <", fontSize = 11.sp, color = AviatorColors.SlateText, textAlign = TextAlign.End, modifier = Modifier.weight(0.8f))
            }

            analytics.targetStats.forEach { stat ->
                TargetStatRow(stat = stat, hasData = analytics.totalRounds > 0)
            }

            HorizontalDivider(color = AviatorColors.NavyBorder.copy(alpha = 0.7f))

            Text(
                text = "RECENT GENUINE ROUND WINDOWS",
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold,
                color = AviatorColors.SlateText
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                WindowSummaryTile(window = analytics.window20, modifier = Modifier.weight(1f))
                WindowSummaryTile(window = analytics.window50, modifier = Modifier.weight(1f))
                WindowSummaryTile(window = analytics.window100, modifier = Modifier.weight(1f))
            }
        }
    }
}

@Composable
private fun TargetStatRow(
    stat: MultiplierTargetStat,
    hasData: Boolean
) {
    val progress = if (hasData) (stat.hitPercentage / 100.0).toFloat().coerceIn(0f, 1f) else 0f

    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = stat.label,
                fontSize = 13.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                color = AviatorColors.WhiteText,
                modifier = Modifier.weight(1.0f)
            )
            Text(
                text = if (hasData) "${stat.hitCount}" else "--",
                fontSize = 12.sp,
                fontFamily = FontFamily.Monospace,
                color = AviatorColors.SlateText,
                textAlign = TextAlign.End,
                modifier = Modifier.weight(0.9f)
            )
            Text(
                text = if (hasData) String.format(Locale.US, "%.1f%%", stat.hitPercentage) else "--",
                fontSize = 12.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.SemiBold,
                color = AviatorColors.CyanAccent,
                textAlign = TextAlign.End,
                modifier = Modifier.weight(0.9f)
            )
            Text(
                text = if (hasData) "${stat.currentSequenceBelow}" else "--",
                fontSize = 12.sp,
                fontFamily = FontFamily.Monospace,
                color = if (stat.currentSequenceBelow > 0) AviatorColors.WarningAmber else AviatorColors.SlateText,
                textAlign = TextAlign.End,
                modifier = Modifier.weight(0.8f)
            )
            Text(
                text = if (hasData) "${stat.longestSequenceBelow}" else "--",
                fontSize = 12.sp,
                fontFamily = FontFamily.Monospace,
                color = AviatorColors.WhiteText,
                textAlign = TextAlign.End,
                modifier = Modifier.weight(0.8f)
            )
        }
        LinearProgressIndicator(
            progress = { progress },
            modifier = Modifier
                .fillMaxWidth()
                .height(4.dp)
                .clip(RoundedCornerShape(2.dp)),
            color = AviatorColors.CyanAccent,
            trackColor = AviatorColors.NavySurfaceElevated
        )
    }
}

@Composable
private fun WindowSummaryTile(
    window: WindowSummary,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(10.dp),
        color = AviatorColors.NavySurfaceElevated,
        border = BorderStroke(1.dp, AviatorColors.NavyBorder.copy(alpha = 0.7f))
    ) {
        Column(
            modifier = Modifier.padding(10.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Text(
                text = "Last ${window.requestedSize}",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = AviatorColors.CyanAccent
            )
            Text(
                text = "${window.actualCount} rounds",
                fontSize = 10.sp,
                color = AviatorColors.SlateText
            )
            Text(
                text = "Avg ${formatMultiplierOrDash(window.averageMultiplier)}",
                fontSize = 12.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.SemiBold,
                color = AviatorColors.WhiteText
            )
            Text(
                text = "Max ${formatMultiplierOrDash(window.highestMultiplier)}",
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace,
                color = AviatorColors.SuccessGreen
            )
            Text(
                text = window.aboveTwoXPercentage?.let {
                    String.format(Locale.US, ">=2x %.0f%%", it)
                } ?: ">=2x --",
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace,
                color = AviatorColors.SlateText
            )
        }
    }
}

@Composable
private fun NextRoundEstimatesCard(
    telemetry: RoundLiveTelemetry,
    analytics: RoundAnalyticsSummary,
    nowEpochMs: Long
) {
    val estimate = analytics.estimate

    val liveWaitSeconds = when (telemetry.phase) {
        LiveRoundPhase.WAITING -> telemetry.waitingStartedAtEpochMs?.let {
            ((nowEpochMs - it).coerceAtLeast(0L)) / 1000.0
        }
        LiveRoundPhase.CRASHED -> telemetry.lastCrashAtEpochMs?.let {
            ((nowEpochMs - it).coerceAtLeast(0L)) / 1000.0
        }
        else -> null
    }

    val startWindowDisplay = if (
        estimate.estimatedWaitTotalLowSec != null &&
        estimate.estimatedWaitTotalHighSec != null
    ) {
        val totalWindow = formatRangeOrDash(estimate.estimatedWaitTotalLowSec, estimate.estimatedWaitTotalHighSec)
        if (liveWaitSeconds != null) {
            val remLow = (estimate.estimatedWaitTotalLowSec - liveWaitSeconds).coerceAtLeast(0.0)
            val remHigh = (estimate.estimatedWaitTotalHighSec - liveWaitSeconds).coerceAtLeast(0.0)
            "$totalWindow (${formatSeconds(remLow)}–${formatSeconds(remHigh)} left)"
        } else {
            totalWindow
        }
    } else {
        "Insufficient wait intervals"
    }

    val durationWindowDisplay = formatRangeOrDash(
        estimate.estimatedDurationLowSec,
        estimate.estimatedDurationHighSec
    )

    val (riskLabel, riskColor) = when (estimate.riskLevel) {
        RiskLevel.INSUFFICIENT_DATA -> "Insufficient Data" to AviatorColors.SlateText
        RiskLevel.ELEVATED -> "Elevated Volatility" to AviatorColors.ErrorRed
        RiskLevel.MODERATE -> "Moderate Variance" to AviatorColors.WarningAmber
        RiskLevel.LOW_VARIANCE -> "Lower Recent Sub-2x" to AviatorColors.SuccessGreen
    }

    val (confidenceLabel, confidenceColor) = when (estimate.dataConfidence) {
        DataConfidenceLevel.NONE -> "None (0 rounds)" to AviatorColors.SlateText
        DataConfidenceLevel.LOW -> "Low (<20 rounds)" to AviatorColors.WarningAmber
        DataConfidenceLevel.MODERATE -> "Moderate (20-49)" to AviatorColors.WarningAmber
        DataConfidenceLevel.GOOD -> "Good (50-99)" to AviatorColors.CyanAccent
        DataConfidenceLevel.HIGH -> "High (100+ rounds)" to AviatorColors.SuccessGreen
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = AviatorColors.NavySurface),
        border = BorderStroke(1.dp, AviatorColors.NavyBorder)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                text = "NEXT-ROUND ESTIMATES & INDICATORS",
                style = MaterialTheme.typography.titleMedium,
                color = AviatorColors.WhiteText,
                fontWeight = FontWeight.Bold
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                MetricTile(
                    label = "EST. START WINDOW",
                    value = startWindowDisplay,
                    accent = AviatorColors.CyanAccent,
                    modifier = Modifier.weight(1f)
                )
                MetricTile(
                    label = "EST. DURATION RANGE",
                    value = durationWindowDisplay,
                    accent = AviatorColors.WhiteText,
                    modifier = Modifier.weight(1f)
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                MetricTile(
                    label = "RISK INDICATOR",
                    value = riskLabel,
                    accent = riskColor,
                    modifier = Modifier.weight(1f)
                )
                MetricTile(
                    label = "SAMPLE QUALITY",
                    value = confidenceLabel,
                    accent = confidenceColor,
                    modifier = Modifier.weight(1f)
                )
            }

            Text(
                text = estimate.riskSummary,
                fontSize = 12.sp,
                color = AviatorColors.WhiteText
            )
            Text(
                text = "Sample scope: ${estimate.dataQualitySummary} (independent of ML Kit OCR confidence).",
                fontSize = 11.sp,
                color = AviatorColors.SlateText
            )

            HorizontalDivider(color = AviatorColors.NavyBorder.copy(alpha = 0.7f))

            Text(
                text = "HISTORICAL PROBABILITY OF REACHING TARGET (PAST OBSERVATIONS ONLY)",
                fontSize = 10.sp,
                fontWeight = FontWeight.SemiBold,
                color = AviatorColors.SlateText
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                analytics.targetStats.forEach { stat ->
                    Surface(
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(8.dp),
                        color = AviatorColors.NavySurfaceElevated,
                        border = BorderStroke(1.dp, AviatorColors.NavyBorder.copy(alpha = 0.6f))
                    ) {
                        Column(
                            modifier = Modifier.padding(vertical = 8.dp, horizontal = 4.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(2.dp)
                        ) {
                            Text(
                                text = stat.label,
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace,
                                color = AviatorColors.SlateText
                            )
                            Text(
                                text = if (analytics.totalRounds > 0) {
                                    String.format(Locale.US, "%.0f%%", stat.hitPercentage)
                                } else {
                                    "--"
                                },
                                fontSize = 12.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                color = AviatorColors.CyanAccent
                            )
                        }
                    }
                }
            }

            Surface(
                shape = RoundedCornerShape(10.dp),
                color = AviatorColors.NavySurfaceElevated,
                border = BorderStroke(1.dp, AviatorColors.WarningAmber.copy(alpha = 0.45f))
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalAlignment = Alignment.Top
                ) {
                    Icon(
                        imageVector = Icons.Default.Info,
                        contentDescription = null,
                        tint = AviatorColors.WarningAmber,
                        modifier = Modifier.size(18.dp)
                    )
                    Text(
                        text = estimate.disclaimer,
                        fontSize = 11.sp,
                        lineHeight = 16.sp,
                        color = AviatorColors.WhiteText
                    )
                }
            }
        }
    }
}

private fun formatSeconds(seconds: Double): String =
    String.format(Locale.US, "%.2fs", seconds)

private fun formatSecondsOrDash(seconds: Double?): String =
    seconds?.let(::formatSeconds) ?: "--"

private fun formatSecondsOrMissing(seconds: Double?): String =
    seconds?.let(::formatSeconds) ?: "Missing"

private fun formatRangeOrDash(low: Double?, high: Double?): String {
    if (low == null || high == null) return "--"
    return "${formatSeconds(low)}–${formatSeconds(high)}"
}

private fun formatMultiplierOrDash(value: Double?): String =
    value?.let { String.format(Locale.US, "%.2fx", it) } ?: "--"

private fun formatLocalTime(epochMs: Long): String {
    val zoned = Instant.ofEpochMilli(epochMs).atZone(ZoneId.systemDefault())
    return LOCAL_TIME_FORMATTER.format(zoned)
}

private fun formatLocalDateTime(epochMs: Long): String {
    val zoned = Instant.ofEpochMilli(epochMs).atZone(ZoneId.systemDefault())
    return LOCAL_DATE_TIME_FORMATTER.format(zoned)
}

private fun formatLocalTimeFromIsoOrFallback(iso: String, fallbackTime: String): String {
    return try {
        val zoned = Instant.parse(iso).atZone(ZoneId.systemDefault())
        LOCAL_TIME_FORMATTER.format(zoned)
    } catch (_: Exception) {
        fallbackTime.ifBlank { "--" }
    }
}

private fun formatLocalDateTimeFromIsoOrFallback(iso: String, fallbackDate: String, fallbackTime: String): String {
    return try {
        val zoned = Instant.parse(iso).atZone(ZoneId.systemDefault())
        LOCAL_DATE_TIME_FORMATTER.format(zoned)
    } catch (_: Exception) {
        "$fallbackDate $fallbackTime".trim().ifBlank { "Missing" }
    }
}

private fun formatOptionalStartTime(iso: String?, epochMs: Long?): String {
    if (!iso.isNullOrBlank()) {
        try {
            val zoned = Instant.parse(iso).atZone(ZoneId.systemDefault())
            return LOCAL_TIME_FORMATTER.format(zoned)
        } catch (_: Exception) {
        }
    }
    if (epochMs != null) {
        return formatLocalTime(epochMs)
    }
    return "Missing"
}

private fun formatOptionalStartDateTime(iso: String?, epochMs: Long?): String {
    if (!iso.isNullOrBlank()) {
        try {
            val zoned = Instant.parse(iso).atZone(ZoneId.systemDefault())
            return LOCAL_DATE_TIME_FORMATTER.format(zoned)
        } catch (_: Exception) {
        }
    }
    if (epochMs != null) {
        return formatLocalDateTime(epochMs)
    }
    return "Missing (not observed)"
}

@Composable
private fun ConnectionStatusBadge(
    status: ConnectionStatus,
    modifier: Modifier = Modifier
) {
    val (label, dotColor, borderColor) = when (status) {
        is ConnectionStatus.Unverified -> Triple("Unverified", AviatorColors.SlateText, AviatorColors.NavyBorder)
        is ConnectionStatus.Checking -> Triple("Checking...", AviatorColors.CyanAccent, AviatorColors.CyanAccent)
        is ConnectionStatus.Connected -> Triple("HTTP ${status.httpCode}", AviatorColors.SuccessGreen, AviatorColors.SuccessGreen)
        is ConnectionStatus.Error -> Triple(
            if (status.isRetrying) "Retrying" else "Error",
            if (status.isRetrying) AviatorColors.WarningAmber else AviatorColors.ErrorRed,
            if (status.isRetrying) AviatorColors.WarningAmber else AviatorColors.ErrorRed
        )
    }

    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(8.dp),
        color = AviatorColors.NavySurface,
        border = BorderStroke(1.dp, borderColor.copy(alpha = 0.6f))
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(8.dp)
                    .clip(CircleShape)
                    .background(dotColor)
            )
            Text(
                text = label,
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold,
                color = AviatorColors.WhiteText
            )
        }
    }
}

@Composable
private fun MonitoringControlCard(
    monitoringStatus: MonitoringStatus,
    isMonitoringActive: Boolean,
    onStartMonitoring: () -> Unit,
    onStopMonitoring: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = AviatorColors.NavySurface),
        border = BorderStroke(
            width = 1.dp,
            color = if (isMonitoringActive) AviatorColors.CyanAccent.copy(alpha = 0.7f) else AviatorColors.NavyBorder
        )
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Screen Monitoring",
                    style = MaterialTheme.typography.titleMedium,
                    color = AviatorColors.WhiteText
                )
                Text(
                    text = when (monitoringStatus) {
                        is MonitoringStatus.Idle -> "Idle"
                        is MonitoringStatus.Starting -> "Starting..."
                        is MonitoringStatus.Active -> "Active"
                        is MonitoringStatus.Error -> "Stopped"
                    },
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = when (monitoringStatus) {
                        is MonitoringStatus.Active -> AviatorColors.CyanAccent
                        is MonitoringStatus.Error -> AviatorColors.ErrorRed
                        else -> AviatorColors.SlateText
                    }
                )
            }

            when (monitoringStatus) {
                is MonitoringStatus.Active -> {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        StatItem(
                            label = "Frames Scanned",
                            value = monitoringStatus.framesAnalyzed.toString()
                        )
                        StatItem(
                            label = "Session Rounds",
                            value = monitoringStatus.roundsDetectedThisSession.toString()
                        )
                        StatItem(
                            label = "Last OCR Read",
                            value = monitoringStatus.lastCandidateText ?: "--"
                        )
                    }
                }
                is MonitoringStatus.Error -> {
                    Text(
                        text = monitoringStatus.message,
                        color = AviatorColors.ErrorRed,
                        fontSize = 13.sp
                    )
                }
                else -> {
                    Text(
                        text = "Uses MediaProjection after your explicit approval to recognize completed multipliers via on-device ML Kit OCR.",
                        color = AviatorColors.SlateText,
                        fontSize = 13.sp
                    )
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = onStartMonitoring,
                    enabled = !isMonitoringActive,
                    modifier = Modifier
                        .weight(1f)
                        .height(52.dp),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = AviatorColors.CyanAccent,
                        contentColor = AviatorColors.NavyBackground,
                        disabledContainerColor = AviatorColors.CyanMuted.copy(alpha = 0.4f),
                        disabledContentColor = AviatorColors.SlateText
                    )
                ) {
                    Icon(
                        imageVector = Icons.Default.PlayArrow,
                        contentDescription = null,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Start Monitoring",
                        fontWeight = FontWeight.Bold,
                        maxLines = 1
                    )
                }

                OutlinedButton(
                    onClick = onStopMonitoring,
                    enabled = isMonitoringActive,
                    modifier = Modifier
                        .weight(1f)
                        .height(52.dp),
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(
                        1.dp,
                        if (isMonitoringActive) AviatorColors.ErrorRed else AviatorColors.NavyBorder
                    ),
                    colors = ButtonDefaults.outlinedButtonColors(
                        contentColor = AviatorColors.WhiteText,
                        disabledContentColor = AviatorColors.SlateText
                    )
                ) {
                    Icon(
                        imageVector = Icons.Default.Stop,
                        contentDescription = null,
                        modifier = Modifier.size(20.dp),
                        tint = if (isMonitoringActive) AviatorColors.ErrorRed else AviatorColors.SlateText
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Stop Monitoring",
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1
                    )
                }
            }
        }
    }
}

@Composable
private fun StatItem(label: String, value: String) {
    Column {
        Text(
            text = label,
            fontSize = 11.sp,
            color = AviatorColors.SlateText
        )
        Text(
            text = value,
            fontSize = 15.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.SemiBold,
            color = AviatorColors.WhiteText
        )
    }
}

@Composable
private fun ApiConfigurationCard(
    ingestEndpointInput: String,
    handshakeEndpointInput: String,
    deviceNameInput: String,
    deviceKeyInput: String,
    ingestError: String?,
    handshakeError: String?,
    savedMessage: String?,
    uiNotice: String?,
    connectionStatus: ConnectionStatus,
    isTesting: Boolean,
    showDeviceKey: Boolean,
    onToggleDeviceKey: () -> Unit,
    onIngestEndpointChanged: (String) -> Unit,
    onHandshakeEndpointChanged: (String) -> Unit,
    onDeviceNameChanged: (String) -> Unit,
    onDeviceKeyChanged: (String) -> Unit,
    onSaveConfig: () -> Unit,
    onTestConnection: () -> Unit
) {
    val fieldColors = OutlinedTextFieldDefaults.colors(
        focusedBorderColor = AviatorColors.CyanAccent,
        unfocusedBorderColor = AviatorColors.NavyBorder,
        focusedTextColor = AviatorColors.WhiteText,
        unfocusedTextColor = AviatorColors.WhiteText,
        focusedLabelColor = AviatorColors.CyanAccent,
        unfocusedLabelColor = AviatorColors.SlateText,
        cursorColor = AviatorColors.CyanAccent,
        errorBorderColor = AviatorColors.ErrorRed
    )

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = AviatorColors.NavySurface),
        border = BorderStroke(1.dp, AviatorColors.NavyBorder)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                text = "Base44 Production API",
                style = MaterialTheme.typography.titleMedium,
                color = AviatorColors.WhiteText
            )

            OutlinedTextField(
                value = ingestEndpointInput,
                onValueChange = onIngestEndpointChanged,
                label = { Text("Ingest Endpoint (Completed Rounds)") },
                placeholder = { Text("https://sociable-aviator-stats-flow.base44.app/api/ingest") },
                singleLine = true,
                isError = ingestError != null,
                supportingText = ingestError?.let { err -> { Text(err, color = AviatorColors.ErrorRed) } },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri),
                colors = fieldColors,
                modifier = Modifier.fillMaxWidth()
            )

            OutlinedTextField(
                value = handshakeEndpointInput,
                onValueChange = onHandshakeEndpointChanged,
                label = { Text("Handshake Endpoint (Test Connection)") },
                placeholder = { Text("https://sociable-aviator-stats-flow.base44.app/api/handshake") },
                singleLine = true,
                isError = handshakeError != null,
                supportingText = handshakeError?.let { err -> { Text(err, color = AviatorColors.ErrorRed) } },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri),
                colors = fieldColors,
                modifier = Modifier.fillMaxWidth()
            )

            OutlinedTextField(
                value = deviceNameInput,
                onValueChange = onDeviceNameChanged,
                label = { Text("Device Name") },
                placeholder = { Text("Moto G 5G 2024") },
                singleLine = true,
                colors = fieldColors,
                modifier = Modifier.fillMaxWidth()
            )

            OutlinedTextField(
                value = deviceKeyInput,
                onValueChange = onDeviceKeyChanged,
                label = { Text("Device Authorization Key") },
                placeholder = { Text("Enter X-Device-Key value") },
                singleLine = true,
                visualTransformation = if (showDeviceKey) {
                    VisualTransformation.None
                } else {
                    PasswordVisualTransformation()
                },
                trailingIcon = {
                    IconButton(onClick = onToggleDeviceKey) {
                        Icon(
                            imageVector = if (showDeviceKey) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                            contentDescription = if (showDeviceKey) "Hide device key" else "Show device key",
                            tint = AviatorColors.SlateText
                        )
                    }
                },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                colors = fieldColors,
                modifier = Modifier.fillMaxWidth()
            )

            if (connectionStatus is ConnectionStatus.Connected) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = null,
                        tint = AviatorColors.SuccessGreen,
                        modifier = Modifier.size(16.dp)
                    )
                    Text(
                        text = "Handshake verified: ${connectionStatus.serverMessage}",
                        color = AviatorColors.SuccessGreen,
                        fontSize = 12.sp
                    )
                }
            } else if (connectionStatus is ConnectionStatus.Error) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.ErrorOutline,
                        contentDescription = null,
                        tint = if (connectionStatus.isRetrying) AviatorColors.WarningAmber else AviatorColors.ErrorRed,
                        modifier = Modifier.size(16.dp)
                    )
                    Text(
                        text = connectionStatus.message,
                        color = if (connectionStatus.isRetrying) AviatorColors.WarningAmber else AviatorColors.ErrorRed,
                        fontSize = 12.sp
                    )
                }
            }

            if (savedMessage != null) {
                Text(
                    text = savedMessage,
                    color = AviatorColors.CyanAccent,
                    fontSize = 12.sp
                )
            }
            if (uiNotice != null && connectionStatus !is ConnectionStatus.Error && connectionStatus !is ConnectionStatus.Connected) {
                Text(
                    text = uiNotice,
                    color = AviatorColors.WhiteText,
                    fontSize = 12.sp
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedButton(
                    onClick = onSaveConfig,
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp),
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(1.dp, AviatorColors.NavyBorder),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = AviatorColors.WhiteText)
                ) {
                    Text("Save", fontWeight = FontWeight.SemiBold)
                }

                Button(
                    onClick = onTestConnection,
                    enabled = !isTesting,
                    modifier = Modifier
                        .weight(1.3f)
                        .height(48.dp),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = AviatorColors.NavySurfaceElevated,
                        contentColor = AviatorColors.CyanAccent
                    ),
                    border = BorderStroke(1.dp, AviatorColors.CyanAccent.copy(alpha = 0.6f))
                ) {
                    if (isTesting) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(16.dp),
                            strokeWidth = 2.dp,
                            color = AviatorColors.CyanAccent
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                    }
                    Text(
                        text = if (isTesting) "Testing..." else "Test Connection",
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1
                    )
                }
            }
        }
    }
}

@Composable
private fun DetectedResultsHeader(
    totalCount: Int,
    pendingCount: Int,
    hasSyncedItems: Boolean,
    onRetryPending: () -> Unit,
    onClearSynced: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Text(
                text = "Detected Rounds ($totalCount)",
                style = MaterialTheme.typography.titleMedium,
                color = AviatorColors.WhiteText
            )
            if (pendingCount > 0) {
                Text(
                    text = "$pendingCount pending auto-retry",
                    fontSize = 12.sp,
                    color = AviatorColors.WarningAmber
                )
            }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            if (pendingCount > 0) {
                TextButton(onClick = onRetryPending) {
                    Icon(
                        imageVector = Icons.Default.Refresh,
                        contentDescription = "Retry pending",
                        tint = AviatorColors.CyanAccent,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Retry", color = AviatorColors.CyanAccent)
                }
            }
            if (hasSyncedItems) {
                TextButton(onClick = onClearSynced) {
                    Icon(
                        imageVector = Icons.Default.DeleteSweep,
                        contentDescription = "Clear synced",
                        tint = AviatorColors.SlateText,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Clear Synced", color = AviatorColors.SlateText)
                }
            }
        }
    }
}

@Composable
private fun EmptyRoundsCard() {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = AviatorColors.NavySurface),
        border = BorderStroke(1.dp, AviatorColors.NavyBorder)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Text(
                text = "No Completed Rounds Detected",
                color = AviatorColors.WhiteText,
                fontWeight = FontWeight.SemiBold,
                fontSize = 15.sp
            )
            Text(
                text = "Tap Start Monitoring, grant Android screen capture permission, and open Aviator. Only finished rounds are recorded.",
                color = AviatorColors.SlateText,
                fontSize = 13.sp
            )
        }
    }
}

@Composable
private fun RoundRecordCard(record: RoundRecordEntity) {
    val statusColor = when (record.syncStatus) {
        SyncStatus.SYNCED -> AviatorColors.SuccessGreen
        SyncStatus.PENDING, SyncStatus.SYNCING -> AviatorColors.WarningAmber
        else -> AviatorColors.ErrorRed
    }
    val statusLabel = when (record.syncStatus) {
        SyncStatus.SYNCED -> "Synced (HTTP ${record.lastHttpCode ?: 200})"
        SyncStatus.SYNCING -> "Sending..."
        SyncStatus.PENDING -> "Pending retry (${record.retryCount})"
        else -> "Failed"
    }
    val confidencePercent = String.format(Locale.US, "%.0f%%", record.ocrConfidence * 100f)
    val actualStartDisplay = formatOptionalStartDateTime(
        iso = record.roundStartedAtIso,
        epochMs = record.roundStartedAtEpochMs
    )
    val crashTimeDisplay = formatLocalDateTimeFromIsoOrFallback(
        iso = record.detectedAtIso,
        fallbackDate = record.detectionDate,
        fallbackTime = record.detectionTime
    )
    val durationDisplay = formatSecondsOrMissing(record.roundDurationSeconds)

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = AviatorColors.NavySurface),
        border = BorderStroke(1.dp, AviatorColors.NavyBorder)
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Final multiplier",
                        fontSize = 10.sp,
                        color = AviatorColors.SlateText
                    )
                    Text(
                        text = record.formattedMultiplier,
                        fontSize = 24.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        color = AviatorColors.CyanAccent
                    )
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = statusLabel,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = statusColor
                    )
                    Text(
                        text = "OCR $confidencePercent",
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        color = AviatorColors.SlateText
                    )
                }
            }

            HorizontalDivider(color = AviatorColors.NavyBorder.copy(alpha = 0.7f))

            RoundDetailLine(
                label = "Round ID:",
                value = record.roundId,
                valueColor = AviatorColors.SlateText
            )
            RoundDetailLine(
                label = "Actual start time:",
                value = actualStartDisplay,
                valueColor = if (actualStartDisplay.startsWith("Missing")) AviatorColors.SlateText else AviatorColors.WhiteText
            )
            RoundDetailLine(
                label = "Crash time:",
                value = crashTimeDisplay,
                valueColor = AviatorColors.WhiteText
            )
            RoundDetailLine(
                label = "Round duration:",
                value = durationDisplay,
                valueColor = if (durationDisplay == "Missing") AviatorColors.SlateText else AviatorColors.CyanAccent
            )

            if (record.waitingTimeBeforeStartSeconds != null) {
                RoundDetailLine(
                    label = "Waiting time:",
                    value = formatSeconds(record.waitingTimeBeforeStartSeconds),
                    valueColor = AviatorColors.WarningAmber
                )
            }

            if (!record.lastErrorMessage.isNullOrBlank() && record.syncStatus != SyncStatus.SYNCED) {
                Text(
                    text = record.lastErrorMessage,
                    fontSize = 11.sp,
                    color = statusColor
                )
            }
        }
    }
}

@Composable
private fun RoundDetailLine(
    label: String,
    value: String,
    valueColor: Color
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            fontSize = 11.sp,
            color = AviatorColors.SlateText
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(
            text = value,
            fontSize = 11.sp,
            fontFamily = FontFamily.Monospace,
            color = valueColor,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}
