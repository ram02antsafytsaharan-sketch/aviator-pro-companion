package com.aviatorpro.companion.analytics

import com.aviatorpro.companion.data.local.RoundRecordEntity
import com.aviatorpro.companion.service.LiveRoundPhase
import com.aviatorpro.companion.service.RoundLiveTelemetry
import kotlin.math.floor

data class MultiplierTargetStat(
    val target: Double,
    val label: String,
    val hitCount: Int,
    val hitPercentage: Double,
    val longestSequenceBelow: Int,
    val currentSequenceBelow: Int
)

data class WindowSummary(
    val requestedSize: Int,
    val actualCount: Int,
    val averageMultiplier: Double?,
    val highestMultiplier: Double?,
    val lowestMultiplier: Double?,
    val aboveTwoXPercentage: Double?
)

data class TimingStatistics(
    val observedDurationCount: Int,
    val averageRoundDurationSeconds: Double?,
    val shortestRoundDurationSeconds: Double?,
    val longestRoundDurationSeconds: Double?,
    val durationRangeLowSeconds: Double?,
    val durationRangeHighSeconds: Double?,
    val observedWaitingCount: Int,
    val averageWaitingTimeSeconds: Double?,
    val shortestWaitingTimeSeconds: Double?,
    val longestWaitingTimeSeconds: Double?,
    val waitingWindowLowSeconds: Double?,
    val waitingWindowHighSeconds: Double?
)

enum class RiskLevel {
    INSUFFICIENT_DATA,
    ELEVATED,
    MODERATE,
    LOW_VARIANCE
}

enum class DataConfidenceLevel {
    NONE,
    LOW,
    MODERATE,
    GOOD,
    HIGH
}

data class NextRoundEstimate(
    val estimatedWaitTotalLowSec: Double?,
    val estimatedWaitTotalHighSec: Double?,
    val estimatedRemainingLowSec: Double?,
    val estimatedRemainingHighSec: Double?,
    val estimatedDurationLowSec: Double?,
    val estimatedDurationHighSec: Double?,
    val riskLevel: RiskLevel,
    val riskSummary: String,
    val dataConfidence: DataConfidenceLevel,
    val dataQualitySummary: String,
    val disclaimer: String
)

data class RoundAnalyticsSummary(
    val totalRounds: Int,
    val averageMultiplier: Double?,
    val highestMultiplier: Double?,
    val lowestMultiplier: Double?,
    val targetStats: List<MultiplierTargetStat>,
    val window20: WindowSummary,
    val window50: WindowSummary,
    val window100: WindowSummary,
    val timing: TimingStatistics,
    val estimate: NextRoundEstimate
)

object RoundAnalyticsEngine {

    val MULTIPLIER_TARGETS: List<Double> = listOf(1.20, 1.50, 2.00, 3.00, 5.00, 10.00)

    private const val DISCLAIMER_TEXT =
        "Historical frequencies and timing windows summarize past observed rounds only. " +
            "They do not predict the next crash multiplier or guarantee a safe betting moment; " +
            "each Aviator round outcome is independent and uncertain."

    fun analyze(
        rounds: List<RoundRecordEntity>,
        liveTelemetry: RoundLiveTelemetry = RoundLiveTelemetry(),
        nowEpochMs: Long = System.currentTimeMillis()
    ): RoundAnalyticsSummary {
        // Chronological order (oldest -> newest) for sequence & streak math
        val chronological = rounds.sortedBy { it.detectedAtEpochMs }
        val newestFirst = chronological.asReversed()
        val total = chronological.size

        val avgMultiplier = if (total > 0) {
            chronological.map { it.multiplier }.average()
        } else {
            null
        }
        val maxMultiplier = chronological.maxOfOrNull { it.multiplier }
        val minMultiplier = chronological.minOfOrNull { it.multiplier }

        val targetStats = MULTIPLIER_TARGETS.map { target ->
            computeTargetStat(target, chronological)
        }

        val window20 = computeWindow(20, newestFirst)
        val window50 = computeWindow(50, newestFirst)
        val window100 = computeWindow(100, newestFirst)

        val timing = computeTimingStatistics(chronological)
        val estimate = computeNextRoundEstimate(
            totalRounds = total,
            newestFirst = newestFirst,
            timing = timing,
            liveTelemetry = liveTelemetry,
            nowEpochMs = nowEpochMs
        )

        return RoundAnalyticsSummary(
            totalRounds = total,
            averageMultiplier = avgMultiplier,
            highestMultiplier = maxMultiplier,
            lowestMultiplier = minMultiplier,
            targetStats = targetStats,
            window20 = window20,
            window50 = window50,
            window100 = window100,
            timing = timing,
            estimate = estimate
        )
    }

    private fun computeTargetStat(
        target: Double,
        chronological: List<RoundRecordEntity>
    ): MultiplierTargetStat {
        val total = chronological.size
        var hits = 0
        var longestBelow = 0
        var runningBelow = 0

        for (round in chronological) {
            if (round.multiplier + 1e-6 >= target) {
                hits += 1
                runningBelow = 0
            } else {
                runningBelow += 1
                if (runningBelow > longestBelow) {
                    longestBelow = runningBelow
                }
            }
        }

        val percentage = if (total > 0) (hits * 100.0) / total else 0.0
        return MultiplierTargetStat(
            target = target,
            label = String.format(java.util.Locale.US, "%.2fx", target),
            hitCount = hits,
            hitPercentage = percentage,
            longestSequenceBelow = longestBelow,
            currentSequenceBelow = runningBelow
        )
    }

    private fun computeWindow(
        size: Int,
        newestFirst: List<RoundRecordEntity>
    ): WindowSummary {
        val slice = newestFirst.take(size)
        if (slice.isEmpty()) {
            return WindowSummary(
                requestedSize = size,
                actualCount = 0,
                averageMultiplier = null,
                highestMultiplier = null,
                lowestMultiplier = null,
                aboveTwoXPercentage = null
            )
        }
        val hits2x = slice.count { it.multiplier + 1e-6 >= 2.00 }
        return WindowSummary(
            requestedSize = size,
            actualCount = slice.size,
            averageMultiplier = slice.map { it.multiplier }.average(),
            highestMultiplier = slice.maxOf { it.multiplier },
            lowestMultiplier = slice.minOf { it.multiplier },
            aboveTwoXPercentage = (hits2x * 100.0) / slice.size
        )
    }

    private fun computeTimingStatistics(chronological: List<RoundRecordEntity>): TimingStatistics {
        val durations = chronological
            .mapNotNull { it.roundDurationSeconds }
            .filter { it >= 0.0 }
            .sorted()

        val waitings = chronological
            .mapNotNull { it.waitingTimeBeforeStartSeconds }
            .filter { it >= 0.0 }
            .sorted()

        val (durLow, durHigh) = interquartileOrBounds(durations)
        val (waitLow, waitHigh) = interquartileOrBounds(waitings)

        return TimingStatistics(
            observedDurationCount = durations.size,
            averageRoundDurationSeconds = if (durations.isNotEmpty()) durations.average() else null,
            shortestRoundDurationSeconds = durations.firstOrNull(),
            longestRoundDurationSeconds = durations.lastOrNull(),
            durationRangeLowSeconds = durLow,
            durationRangeHighSeconds = durHigh,
            observedWaitingCount = waitings.size,
            averageWaitingTimeSeconds = if (waitings.isNotEmpty()) waitings.average() else null,
            shortestWaitingTimeSeconds = waitings.firstOrNull(),
            longestWaitingTimeSeconds = waitings.lastOrNull(),
            waitingWindowLowSeconds = waitLow,
            waitingWindowHighSeconds = waitHigh
        )
    }

    private fun interquartileOrBounds(sorted: List<Double>): Pair<Double?, Double?> {
        if (sorted.isEmpty()) return null to null
        if (sorted.size < 4) return sorted.first() to sorted.last()
        val p25Index = floor((sorted.size - 1) * 0.25).toInt()
        val p75Index = floor((sorted.size - 1) * 0.75).toInt()
        return sorted[p25Index] to sorted[p75Index]
    }

    private fun computeNextRoundEstimate(
        totalRounds: Int,
        newestFirst: List<RoundRecordEntity>,
        timing: TimingStatistics,
        liveTelemetry: RoundLiveTelemetry,
        nowEpochMs: Long
    ): NextRoundEstimate {
        val waitLow = timing.waitingWindowLowSeconds
        val waitHigh = timing.waitingWindowHighSeconds

        val elapsedWaitSec = when {
            liveTelemetry.phase == LiveRoundPhase.WAITING && liveTelemetry.waitingStartedAtEpochMs != null ->
                ((nowEpochMs - liveTelemetry.waitingStartedAtEpochMs).coerceAtLeast(0L)) / 1000.0
            liveTelemetry.phase == LiveRoundPhase.CRASHED && liveTelemetry.lastCrashAtEpochMs != null ->
                ((nowEpochMs - liveTelemetry.lastCrashAtEpochMs).coerceAtLeast(0L)) / 1000.0
            else -> null
        }

        val (remLow, remHigh) = if (waitLow != null && waitHigh != null && elapsedWaitSec != null) {
            (waitLow - elapsedWaitSec).coerceAtLeast(0.0) to (waitHigh - elapsedWaitSec).coerceAtLeast(0.0)
        } else {
            null to null
        }

        val dataConfidence = when {
            totalRounds == 0 -> DataConfidenceLevel.NONE
            totalRounds < 20 -> DataConfidenceLevel.LOW
            totalRounds < 50 -> DataConfidenceLevel.MODERATE
            totalRounds < 100 -> DataConfidenceLevel.GOOD
            else -> DataConfidenceLevel.HIGH
        }

        val dataQualitySummary = buildString {
            append("$totalRounds genuine round(s)")
            append(" · ${timing.observedDurationCount} timed duration(s)")
            append(" · ${timing.observedWaitingCount} wait interval(s)")
        }

        val recent20 = newestFirst.take(20)
        val sub2xRate = if (recent20.isNotEmpty()) {
            recent20.count { it.multiplier < 2.00 }.toDouble() / recent20.size
        } else {
            0.0
        }

        val (riskLevel, riskSummary) = when {
            totalRounds < 10 ->
                RiskLevel.INSUFFICIENT_DATA to "Small sample ($totalRounds rounds). Observe at least 10-20 rounds for baseline variance."
            sub2xRate >= 0.65 ->
                RiskLevel.ELEVATED to "High short-round frequency in recent 20 (${(sub2xRate * 100).toInt()}% below 2.00x)."
            sub2xRate >= 0.45 ->
                RiskLevel.MODERATE to "Balanced variance in recent 20 (${(sub2xRate * 100).toInt()}% below 2.00x)."
            else ->
                RiskLevel.LOW_VARIANCE to "Lower recent sub-2.00x share (${(sub2xRate * 100).toInt()}%); outcomes remain unpredictable."
        }

        return NextRoundEstimate(
            estimatedWaitTotalLowSec = waitLow,
            estimatedWaitTotalHighSec = waitHigh,
            estimatedRemainingLowSec = remLow,
            estimatedRemainingHighSec = remHigh,
            estimatedDurationLowSec = timing.durationRangeLowSeconds,
            estimatedDurationHighSec = timing.durationRangeHighSeconds,
            riskLevel = riskLevel,
            riskSummary = riskSummary,
            dataConfidence = dataConfidence,
            dataQualitySummary = dataQualitySummary,
            disclaimer = DISCLAIMER_TEXT
        )
    }
}
