# AVIATOR PRO COMPANION — Native Android 15 (Kotlin) Build Guide

Target Device: **Moto G 5G 2024 (Android 15 / API 35)**

## 1. Prerequisites
- **Android Studio**: Ladybug (2024.2.1) or newer (Meerkat recommended)
- **JDK**: Java 17 (bundled with Android Studio)
- **Android SDK Platforms**: Android 15 (`API 35`)
- **Android SDK Build-Tools**: `35.0.0`

## 2. Opening & Building in Android Studio
1. Extract or copy the `android-project/` directory to your local workstation.
2. Open Android Studio -> **File -> Open...** and select the `android-project` folder.
3. Let Gradle sync automatically (uses `gradle/libs.versions.toml` with AGP `8.7.3`, Kotlin `2.0.21`, Jetpack Compose BOM `2024.11.00`, ML Kit Text Recognition `16.0.1`, Room `2.6.1`, OkHttp `4.12.0`, WorkManager `2.10.0`).
4. Run unit tests to verify OCR multiplier parsing and duplicate suppression:
   ```bash
   ./gradlew testDebugUnitTest
   ```
5. Build the installable APK:
   ```bash
   ./gradlew assembleDebug
   ```
   Output APK path:
   `app/build/outputs/apk/debug/app-debug.apk`

   For a minified release APK (sign with your release keystore):
   ```bash
   ./gradlew assembleRelease
   ```

## 3. Installing on Moto G 5G 2024 (Android 15)
1. On your Moto G 5G 2024, open **Settings -> About phone** and tap **Build number** 7 times to enable Developer options.
2. Open **Settings -> System -> Developer options** and enable **USB debugging**.
3. Connect the phone via USB and accept the RSA debugging prompt.
4. Install directly from Android Studio (**Run 'app'**) or via ADB:
   ```bash
   adb install -r app/build/outputs/apk/debug/app-debug.apk
   ```

## 4. Runtime Flow & Permissions on Android 15
1. Verify or edit the **Ingest Endpoint** (`https://sociable-aviator-stats-flow.base44.app/api/ingest`), **Handshake Endpoint** (`https://sociable-aviator-stats-flow.base44.app/api/handshake`), **Device Name**, and **Device Authorization Key** (`X-Device-Key`), then tap **Save** and **Test Connection**.
   - **Test Connection** sends a POST request exclusively to `/api/handshake` and only marks verified after a real HTTP `2xx` (`ok != false`) response.
2. Tap **Start Monitoring**:
   - Prompts for **Notifications** (`POST_NOTIFICATIONS`) on Android 13–15 if not yet granted.
   - Launches the Android 15 **MediaProjection** consent dialog (choose **Share entire screen** so Aviator stays captured when switching apps).
   - Starts `ScreenCaptureService` with `FOREGROUND_SERVICE_MEDIA_PROJECTION` and a persistent notification containing a quick **Stop** action.
3. Switch to Aviator:
   - On-device Google ML Kit OCR detects completed multipliers (`1.25x`, `2.00x`, `5.67x`, `10.50x`, `100.00x`), ignores countdowns and climbing ticks, suppresses duplicates, stores each round locally in Room, and POSTs JSON exclusively to `/api/ingest` with automatic exponential-backoff retry.

## 5. Base44 API Contract
Headers (both endpoints):
- `Content-Type: application/json`
- `Accept: application/json`
- `X-Device-Key: <your-device-key>`
- `Authorization: Bearer <your-device-key>`

### Handshake (`POST /api/handshake` — Test Connection)
```json
{
  "device_id": "3c1b2a10-...",
  "device_name": "Moto G 5G 2024",
  "timestamp_iso": "2026-11-26T20:57:20.000Z",
  "source": "aviator_pro_companion_android"
}
```

### Ingest (`POST /api/ingest` — Completed OCR Rounds Only)
```json
{
  "round_id": "APC-1764180002000-8f3a9c12",
  "multiplier": 10.5,
  "multiplier_text": "10.50x",
  "detection_date": "2026-11-26",
  "detection_time": "12:57:20",
  "detected_at": "2026-11-26T20:57:20.123Z",
  "round_started_at": "2026-11-26T20:57:12.400Z",
  "ocr_confidence": 0.94,
  "device_id": "3c1b2a10-...",
  "device_name": "Moto G 5G 2024",
  "source": "aviator_pro_companion_android"
}
```
(`round_started_at` is included only when OCR genuinely observes the round start and is omitted otherwise.)

## 6. Upgrading an Existing Installation Without Losing Data or Auth
1. **Do NOT uninstall** the existing app from your Moto G 5G 2024 before installing the new APK.
2. Build using the **same build variant and signing keystore** you used previously:
   - Debug installs (`com.aviatorpro.companion.debug`): build with the same machine/GitHub debug keystore (`./gradlew assembleDebug`).
   - Release installs (`com.aviatorpro.companion`): sign with the exact same `.jks` release keystore (`./gradlew assembleRelease`).
3. Install in place using ADB or Android Studio:
   ```bash
   adb install -r app/build/outputs/apk/debug/app-debug.apk
   ```
4. `AppDatabase` migrates automatically from schema version `1` to `2` via `MIGRATION_1_2` (preserving all existing recorded rounds in `aviator_pro_companion.db`), and `EncryptedSharedPreferences` (`aviator_companion_secure_prefs`) keeps your Base44 endpoints, device name, and `X-Device-Key` intact.

