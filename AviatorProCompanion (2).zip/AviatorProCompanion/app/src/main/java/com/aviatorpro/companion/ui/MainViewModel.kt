package com.aviatorpro.companion.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.aviatorpro.companion.AviatorCompanionApp
import com.aviatorpro.companion.data.local.ApiConfiguration
import com.aviatorpro.companion.data.local.RoundRecordEntity
import com.aviatorpro.companion.data.remote.ApiResult
import com.aviatorpro.companion.service.ConnectionStatus
import com.aviatorpro.companion.service.MonitoringStateHolder
import com.aviatorpro.companion.service.MonitoringStatus
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class CompanionUiState(
    val ingestEndpointInput: String = ApiConfiguration.DEFAULT_INGEST_ENDPOINT,
    val handshakeEndpointInput: String = ApiConfiguration.DEFAULT_HANDSHAKE_ENDPOINT,
    val deviceNameInput: String = "",
    val deviceKeyInput: String = "",
    val ingestValidationError: String? = null,
    val handshakeValidationError: String? = null,
    val configSavedMessage: String? = null,
    val isTestingConnection: Boolean = false,
    val monitoringStatus: MonitoringStatus = MonitoringStatus.Idle,
    val connectionStatus: ConnectionStatus = ConnectionStatus.Unverified,
    val rounds: List<RoundRecordEntity> = emptyList(),
    val totalRoundsCount: Int = 0,
    val pendingRoundsCount: Int = 0,
    val uiNotice: String? = null
)

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val app = application as AviatorCompanionApp
    private val repository = app.repository

    private val _formState = MutableStateFlow(loadInitialFormState())

    val uiState: StateFlow<CompanionUiState> = combine(
        _formState,
        MonitoringStateHolder.monitoringStatus,
        MonitoringStateHolder.connectionStatus,
        repository.recentRounds,
        repository.totalCount,
        repository.pendingCount
    ) { values ->
        @Suppress("UNCHECKED_CAST")
        val form = values[0] as FormState
        val monitoring = values[1] as MonitoringStatus
        val connection = values[2] as ConnectionStatus
        val rounds = values[3] as List<RoundRecordEntity>
        val total = values[4] as Int
        val pending = values[5] as Int

        CompanionUiState(
            ingestEndpointInput = form.ingestEndpointInput,
            handshakeEndpointInput = form.handshakeEndpointInput,
            deviceNameInput = form.deviceNameInput,
            deviceKeyInput = form.deviceKeyInput,
            ingestValidationError = form.ingestValidationError,
            handshakeValidationError = form.handshakeValidationError,
            configSavedMessage = form.configSavedMessage,
            isTestingConnection = form.isTestingConnection,
            monitoringStatus = monitoring,
            connectionStatus = connection,
            rounds = rounds,
            totalRoundsCount = total,
            pendingRoundsCount = pending,
            uiNotice = form.uiNotice
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000L),
        initialValue = CompanionUiState(
            ingestEndpointInput = _formState.value.ingestEndpointInput,
            handshakeEndpointInput = _formState.value.handshakeEndpointInput,
            deviceNameInput = _formState.value.deviceNameInput,
            deviceKeyInput = _formState.value.deviceKeyInput
        )
    )

    fun onIngestEndpointChanged(value: String) {
        _formState.update {
            val previousDerived = ApiConfiguration.deriveHandshakeUrl(it.ingestEndpointInput)
            val shouldUpdateHandshake =
                it.handshakeEndpointInput.isBlank() || it.handshakeEndpointInput == previousDerived
            it.copy(
                ingestEndpointInput = value,
                handshakeEndpointInput = if (shouldUpdateHandshake) {
                    ApiConfiguration.deriveHandshakeUrl(value)
                } else {
                    it.handshakeEndpointInput
                },
                ingestValidationError = null,
                handshakeValidationError = null,
                configSavedMessage = null,
                uiNotice = null
            )
        }
    }

    fun onHandshakeEndpointChanged(value: String) {
        _formState.update {
            it.copy(
                handshakeEndpointInput = value,
                handshakeValidationError = null,
                configSavedMessage = null,
                uiNotice = null
            )
        }
    }

    fun onDeviceNameChanged(value: String) {
        _formState.update {
            it.copy(
                deviceNameInput = value,
                configSavedMessage = null,
                uiNotice = null
            )
        }
    }

    fun onDeviceKeyChanged(value: String) {
        _formState.update {
            it.copy(
                deviceKeyInput = value,
                configSavedMessage = null,
                uiNotice = null
            )
        }
    }

    fun saveConfiguration(): Boolean {
        val current = _formState.value
        val ingestError = ApiConfiguration.validateEndpointUrl(current.ingestEndpointInput)
        val effectiveHandshake = current.handshakeEndpointInput.trim().ifEmpty {
            ApiConfiguration.deriveHandshakeUrl(current.ingestEndpointInput)
        }
        val handshakeError = ApiConfiguration.validateHandshakeUrl(effectiveHandshake)

        if (ingestError != null || handshakeError != null) {
            _formState.update {
                it.copy(
                    ingestValidationError = ingestError,
                    handshakeValidationError = handshakeError,
                    configSavedMessage = null
                )
            }
            return false
        }
        if (current.deviceNameInput.isBlank()) {
            _formState.update {
                it.copy(
                    ingestValidationError = null,
                    handshakeValidationError = null,
                    configSavedMessage = null,
                    uiNotice = "Enter a device name before saving."
                )
            }
            return false
        }
        if (current.deviceKeyInput.isBlank()) {
            _formState.update {
                it.copy(
                    ingestValidationError = null,
                    handshakeValidationError = null,
                    configSavedMessage = null,
                    uiNotice = "Enter your Base44 device authorization key before saving."
                )
            }
            return false
        }

        val saved = repository.saveConfig(
            ingestEndpointUrl = current.ingestEndpointInput,
            handshakeEndpointUrl = effectiveHandshake,
            deviceName = current.deviceNameInput,
            deviceKey = current.deviceKeyInput
        )
        _formState.update {
            it.copy(
                ingestEndpointInput = saved.ingestEndpointUrl,
                handshakeEndpointInput = saved.handshakeEndpointUrl,
                deviceNameInput = saved.deviceName,
                deviceKeyInput = saved.deviceKey,
                ingestValidationError = null,
                handshakeValidationError = null,
                configSavedMessage = "Configuration saved securely. Tap Test Connection to verify handshake.",
                uiNotice = null
            )
        }
        return true
    }

    fun testServerConnection() {
        if (!saveConfiguration()) return

        viewModelScope.launch {
            _formState.update {
                it.copy(
                    isTestingConnection = true,
                    configSavedMessage = null,
                    uiNotice = null
                )
            }
            val result = repository.verifyServerConnection()
            val notice = when (result) {
                is ApiResult.Success -> "Handshake succeeded (${result.serverMessage})."
                is ApiResult.Failure -> "Handshake failed (${result.errorMessage})."
            }
            _formState.update {
                it.copy(
                    isTestingConnection = false,
                    configSavedMessage = null,
                    uiNotice = notice
                )
            }
        }
    }

    fun retryPendingRounds() {
        viewModelScope.launch {
            _formState.update { it.copy(uiNotice = "Retrying queued rounds...") }
            repository.retryAllPendingNow()
            _formState.update { it.copy(uiNotice = null) }
        }
    }

    fun clearSyncedRounds() {
        viewModelScope.launch {
            repository.clearSyncedHistory()
        }
    }

    fun setUiNotice(message: String?) {
        _formState.update { it.copy(uiNotice = message) }
    }

    fun canStartMonitoring(): Boolean {
        val saved = repository.getConfig()
        val form = _formState.value
        if (form.ingestEndpointInput.trim() != saved.ingestEndpointUrl ||
            form.handshakeEndpointInput.trim() != saved.handshakeEndpointUrl ||
            form.deviceNameInput.trim() != saved.deviceName ||
            form.deviceKeyInput.trim() != saved.deviceKey
        ) {
            if (!saveConfiguration()) return false
        }
        val latest = repository.getConfig()
        if (!latest.isIngestConfigured) {
            _formState.update {
                it.copy(
                    ingestValidationError = ApiConfiguration.validateEndpointUrl(form.ingestEndpointInput),
                    uiNotice = "Configure a valid HTTPS Base44 ingest endpoint, device name, and device key first."
                )
            }
            return false
        }
        return true
    }

    private fun loadInitialFormState(): FormState {
        val config = repository.getConfig()
        return FormState(
            ingestEndpointInput = config.ingestEndpointUrl,
            handshakeEndpointInput = config.handshakeEndpointUrl,
            deviceNameInput = config.deviceName,
            deviceKeyInput = config.deviceKey
        )
    }

    private data class FormState(
        val ingestEndpointInput: String = ApiConfiguration.DEFAULT_INGEST_ENDPOINT,
        val handshakeEndpointInput: String = ApiConfiguration.DEFAULT_HANDSHAKE_ENDPOINT,
        val deviceNameInput: String = "",
        val deviceKeyInput: String = "",
        val ingestValidationError: String? = null,
        val handshakeValidationError: String? = null,
        val configSavedMessage: String? = null,
        val isTestingConnection: Boolean = false,
        val uiNotice: String? = null
    )
}
