package com.aviatorpro.companion.data.local

import android.content.Context
import android.content.SharedPreferences
import android.os.Build
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import java.net.URI
import java.util.UUID

data class ApiConfiguration(
    val ingestEndpointUrl: String = DEFAULT_INGEST_ENDPOINT,
    val handshakeEndpointUrl: String = DEFAULT_HANDSHAKE_ENDPOINT,
    val deviceName: String = defaultDeviceName(),
    val deviceKey: String = "",
    val deviceId: String = ""
) {
    val isIngestConfigured: Boolean
        get() = validateEndpointUrl(ingestEndpointUrl).isNullOrEmpty() &&
            deviceKey.isNotBlank() &&
            deviceName.isNotBlank()

    val isHandshakeConfigured: Boolean
        get() = validateHandshakeUrl(handshakeEndpointUrl).isNullOrEmpty() &&
            deviceKey.isNotBlank() &&
            deviceName.isNotBlank()

    companion object {
        const val DEFAULT_INGEST_ENDPOINT =
            "https://sociable-aviator-stats-flow.base44.app/api/ingest"
        const val DEFAULT_HANDSHAKE_ENDPOINT =
            "https://sociable-aviator-stats-flow.base44.app/api/handshake"

        fun defaultDeviceName(): String {
            val manufacturer = Build.MANUFACTURER.orEmpty().trim()
            val model = Build.MODEL.orEmpty().trim()
            return listOf(manufacturer, model)
                .filter { it.isNotEmpty() }
                .distinct()
                .joinToString(" ")
                .ifBlank { "Android Device" }
        }

        fun deriveHandshakeUrl(ingestUrl: String): String {
            val trimmed = ingestUrl.trim().trimEnd('/')
            return when {
                trimmed.endsWith("/ingest", ignoreCase = true) ->
                    trimmed.dropLast("/ingest".length) + "/handshake"
                trimmed.isEmpty() -> DEFAULT_HANDSHAKE_ENDPOINT
                else -> "$trimmed/handshake"
            }
        }

        fun validateEndpointUrl(rawUrl: String): String? {
            val trimmed = rawUrl.trim()
            if (trimmed.isEmpty()) {
                return "API endpoint URL is required."
            }
            val uri = try {
                URI(trimmed)
            } catch (_: Exception) {
                return "Invalid URL format."
            }
            if (!uri.scheme.equals("https", ignoreCase = true)) {
                return "Production endpoint must use HTTPS."
            }
            if (uri.host.isNullOrBlank()) {
                return "Endpoint URL must include a valid host."
            }
            return null
        }

        fun validateHandshakeUrl(rawUrl: String): String? {
            val baseError = validateEndpointUrl(rawUrl)
            if (baseError != null) return baseError
            val path = try {
                URI(rawUrl.trim()).path.orEmpty().trimEnd('/')
            } catch (_: Exception) {
                ""
            }
            if (path.endsWith("/ingest", ignoreCase = true)) {
                return "Handshake URL must point to /api/handshake, not /api/ingest."
            }
            return null
        }
    }
}

class SecureConfigStore(context: Context) {

    private val prefs: SharedPreferences = createPreferences(context.applicationContext)

    fun loadConfig(): ApiConfiguration {
        val deviceId = prefs.getString(KEY_DEVICE_ID, null) ?: UUID.randomUUID().toString().also {
            prefs.edit().putString(KEY_DEVICE_ID, it).apply()
        }
        val savedIngest = prefs.getString(KEY_INGEST_ENDPOINT_URL, null)?.trim()
            ?.takeIf { it.isNotEmpty() }
            ?: ApiConfiguration.DEFAULT_INGEST_ENDPOINT

        val savedHandshake = prefs.getString(KEY_HANDSHAKE_ENDPOINT_URL, null)?.trim()
            ?.takeIf { it.isNotEmpty() }
            ?: ApiConfiguration.deriveHandshakeUrl(savedIngest)

        val savedDeviceName = prefs.getString(KEY_DEVICE_NAME, null)?.trim()
            ?.takeIf { it.isNotEmpty() }
            ?: ApiConfiguration.defaultDeviceName()

        return ApiConfiguration(
            ingestEndpointUrl = savedIngest,
            handshakeEndpointUrl = savedHandshake,
            deviceName = savedDeviceName,
            deviceKey = prefs.getString(KEY_DEVICE_KEY, "")?.trim().orEmpty(),
            deviceId = deviceId
        )
    }

    fun saveConfig(
        ingestEndpointUrl: String,
        handshakeEndpointUrl: String,
        deviceName: String,
        deviceKey: String
    ): ApiConfiguration {
        val current = loadConfig()
        val cleanIngest = ingestEndpointUrl.trim()
        val cleanHandshake = handshakeEndpointUrl.trim().ifEmpty {
            ApiConfiguration.deriveHandshakeUrl(cleanIngest)
        }
        val cleanDeviceName = deviceName.trim().ifEmpty {
            ApiConfiguration.defaultDeviceName()
        }
        val cleanKey = deviceKey.trim()

        prefs.edit()
            .putString(KEY_INGEST_ENDPOINT_URL, cleanIngest)
            .putString(KEY_HANDSHAKE_ENDPOINT_URL, cleanHandshake)
            .putString(KEY_DEVICE_NAME, cleanDeviceName)
            .putString(KEY_DEVICE_KEY, cleanKey)
            .apply()

        return current.copy(
            ingestEndpointUrl = cleanIngest,
            handshakeEndpointUrl = cleanHandshake,
            deviceName = cleanDeviceName,
            deviceKey = cleanKey
        )
    }

    private fun createPreferences(context: Context): SharedPreferences {
        return try {
            val masterKey = MasterKey.Builder(context)
                .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
                .build()
            EncryptedSharedPreferences.create(
                context,
                PREFS_FILE_NAME,
                masterKey,
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            )
        } catch (_: Exception) {
            context.getSharedPreferences(FALLBACK_PREFS_NAME, Context.MODE_PRIVATE)
        }
    }

    companion object {
        private const val PREFS_FILE_NAME = "aviator_companion_secure_prefs"
        private const val FALLBACK_PREFS_NAME = "aviator_companion_private_prefs"
        private const val KEY_INGEST_ENDPOINT_URL = "api_endpoint_url"
        private const val KEY_HANDSHAKE_ENDPOINT_URL = "api_handshake_url"
        private const val KEY_DEVICE_NAME = "device_name"
        private const val KEY_DEVICE_KEY = "device_key"
        private const val KEY_DEVICE_ID = "device_install_id"
    }
}
