package com.aviatorpro.companion

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.runtime.getValue
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.aviatorpro.companion.service.ScreenCaptureService
import com.aviatorpro.companion.ui.CompanionScreen
import com.aviatorpro.companion.ui.MainViewModel
import com.aviatorpro.companion.ui.theme.AviatorProCompanionTheme

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()

    private val notificationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            launchMediaProjectionPrompt()
        } else {
            viewModel.setUiNotice(
                "Notification permission is required on Android 15 to run the foreground monitoring service."
            )
        }
    }

    private val mediaProjectionLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val resultData = result.data
        if (result.resultCode == Activity.RESULT_OK && resultData != null) {
            val serviceIntent = ScreenCaptureService.buildStartIntent(
                context = this,
                resultCode = result.resultCode,
                resultData = resultData
            )
            ContextCompat.startForegroundService(this, serviceIntent)
            viewModel.setUiNotice(null)
        } else {
            viewModel.setUiNotice("Screen capture permission was declined. Monitoring did not start.")
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )

        setContent {
            AviatorProCompanionTheme {
                val uiState by viewModel.uiState.collectAsStateWithLifecycle()
                CompanionScreen(
                    uiState = uiState,
                    onIngestEndpointChanged = viewModel::onIngestEndpointChanged,
                    onHandshakeEndpointChanged = viewModel::onHandshakeEndpointChanged,
                    onDeviceNameChanged = viewModel::onDeviceNameChanged,
                    onDeviceKeyChanged = viewModel::onDeviceKeyChanged,
                    onSaveConfig = { viewModel.saveConfiguration() },
                    onTestConnection = viewModel::testServerConnection,
                    onStartMonitoring = ::handleStartMonitoringClicked,
                    onStopMonitoring = ::handleStopMonitoringClicked,
                    onRetryPending = viewModel::retryPendingRounds,
                    onClearSynced = viewModel::clearSyncedRounds
                )
            }
        }
    }

    private fun handleStartMonitoringClicked() {
        if (!viewModel.canStartMonitoring()) {
            return
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val permissionState = ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.POST_NOTIFICATIONS
            )
            if (permissionState != PackageManager.PERMISSION_GRANTED) {
                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                return
            }
        }

        launchMediaProjectionPrompt()
    }

    private fun launchMediaProjectionPrompt() {
        val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        mediaProjectionLauncher.launch(manager.createScreenCaptureIntent())
    }

    private fun handleStopMonitoringClicked() {
        startService(ScreenCaptureService.buildStopIntent(this))
    }
}
