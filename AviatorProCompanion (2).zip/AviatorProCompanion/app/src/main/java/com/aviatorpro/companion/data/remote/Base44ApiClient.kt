package com.aviatorpro.companion.data.remote

import android.os.Build
import com.aviatorpro.companion.data.local.ApiConfiguration
import com.aviatorpro.companion.data.local.RoundRecordEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.booleanOrNull
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.jsonPrimitive
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.IOException
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import java.time.Instant
import java.util.concurrent.TimeUnit

@Serializable
data class Base44RoundPayload(
    @SerialName("round_id")
    val roundId: String,
    @SerialName("multiplier")
    val multiplier: Double,
    @SerialName("multiplier_text")
    val multiplierText: String,
    @SerialName("detection_date")
    val detectionDate: String,
    @SerialName("detection_time")
    val detectionTime: String,
    @SerialName("detected_at")
    val detectedAt: String,
    @SerialName("ocr_confidence")
    val ocrConfidence: Float,
    @SerialName("device_id")
    val deviceId: String,
    @SerialName("device_name")
    val deviceName: String,
    @SerialName("source")
    val source: String = "aviator_pro_companion_android"
)

@Serializable
data class Base44HandshakePayload(
    @SerialName("device_id")
    val deviceId: String,
    @SerialName("device_name")
    val deviceName: String,
    @SerialName("timestamp_iso")
    val timestampIso: String,
    @SerialName("source")
    val source: String = "aviator_pro_companion_android"
)

sealed interface ApiResult {
    data class Success(
        val httpCode: Int,
        val serverMessage: String
    ) : ApiResult

    data class Failure(
        val httpCode: Int?,
        val errorMessage: String,
        val isRetryable: Boolean
    ) : ApiResult
}

class Base44ApiClient {

    private val json = Json {
        ignoreUnknownKeys = true
        encodeDefaults = true
    }

    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(12, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .writeTimeout(15, TimeUnit.SECONDS)
        .retryOnConnectionFailure(false)
        .build()

    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()
    private val userAgent: String by lazy {
        val osRelease = Build.VERSION.RELEASE?.takeIf { it.isNotBlank() } ?: "15"
        val deviceModel = Build.MODEL?.takeIf { it.isNotBlank() } ?: "Android"
        "AviatorProCompanion/1.0 (Android $osRelease; $deviceModel)"
    }

    fun buildHandshakeBodyJson(config: ApiConfiguration, timestampIso: String): String {
        val payload = Base44HandshakePayload(
            deviceId = config.deviceId,
            deviceName = config.deviceName,
            timestampIso = timestampIso
        )
        return json.encodeToString(payload)
    }

    fun buildIngestBodyJson(config: ApiConfiguration, record: RoundRecordEntity): String {
        val validDetectedAt = normalizeIsoTimestamp(record.detectedAtIso)
        val payload = Base44RoundPayload(
            roundId = record.roundId,
            multiplier = record.multiplier,
            multiplierText = record.formattedMultiplier,
            detectionDate = record.detectionDate,
            detectionTime = record.detectionTime,
            detectedAt = validDetectedAt,
            ocrConfidence = record.ocrConfidence,
            deviceId = config.deviceId,
            deviceName = config.deviceName
        )
        return json.encodeToString(payload)
    }

    private fun normalizeIsoTimestamp(candidate: String): String {
        val trimmed = candidate.trim()
        if (trimmed.isNotEmpty()) {
            try {
                return Instant.parse(trimmed).toString()
            } catch (_: Exception) {
                // Fall back to current UTC ISO 8601 timestamp if stored value is invalid
            }
        }
        return Instant.now().toString()
    }

    suspend fun sendRound(
        config: ApiConfiguration,
        record: RoundRecordEntity
    ): ApiResult = withContext(Dispatchers.IO) {
        val urlError = ApiConfiguration.validateEndpointUrl(config.ingestEndpointUrl)
        if (urlError != null) {
            return@withContext ApiResult.Failure(
                httpCode = null,
                errorMessage = urlError,
                isRetryable = false
            )
        }
        if (config.deviceKey.isBlank()) {
            return@withContext ApiResult.Failure(
                httpCode = null,
                errorMessage = "Device key is not configured.",
                isRetryable = false
            )
        }

        executePost(
            url = config.ingestEndpointUrl,
            deviceKey = config.deviceKey,
            bodyJson = buildIngestBodyJson(config, record)
        )
    }

    suspend fun testConnection(config: ApiConfiguration): ApiResult = withContext(Dispatchers.IO) {
        val urlError = ApiConfiguration.validateHandshakeUrl(config.handshakeEndpointUrl)
        if (urlError != null) {
            return@withContext ApiResult.Failure(
                httpCode = null,
                errorMessage = urlError,
                isRetryable = false
            )
        }
        if (config.deviceKey.isBlank()) {
            return@withContext ApiResult.Failure(
                httpCode = null,
                errorMessage = "Device authorization key is required to run handshake.",
                isRetryable = false
            )
        }
        if (config.deviceName.isBlank()) {
            return@withContext ApiResult.Failure(
                httpCode = null,
                errorMessage = "Device name is required to run handshake.",
                isRetryable = false
            )
        }

        val bodyJson = buildHandshakeBodyJson(
            config = config,
            timestampIso = Instant.now().toString()
        )

        executePost(
            url = config.handshakeEndpointUrl,
            deviceKey = config.deviceKey,
            bodyJson = bodyJson
        )
    }

    private fun executePost(
        url: String,
        deviceKey: String,
        bodyJson: String
    ): ApiResult {
        val request = Request.Builder()
            .url(url)
            .post(bodyJson.toRequestBody(jsonMediaType))
            .header("Accept", "application/json")
            .header("Content-Type", "application/json")
            .header("User-Agent", userAgent)
            .header("X-Device-Key", deviceKey)
            .header("Authorization", "Bearer $deviceKey")
            .build()

        return try {
            client.newCall(request).execute().use { response ->
                val rawBody = response.body?.string().orEmpty().trim()
                parseHttpResponse(response.code, response.message, response.isSuccessful, rawBody)
            }
        } catch (_: UnknownHostException) {
            ApiResult.Failure(
                httpCode = null,
                errorMessage = "DNS lookup failed. Check internet connection or endpoint host.",
                isRetryable = true
            )
        } catch (_: SocketTimeoutException) {
            ApiResult.Failure(
                httpCode = null,
                errorMessage = "Request timed out waiting for Base44 server response.",
                isRetryable = true
            )
        } catch (e: IOException) {
            ApiResult.Failure(
                httpCode = null,
                errorMessage = "Network error: ${e.localizedMessage ?: e.javaClass.simpleName}",
                isRetryable = true
            )
        } catch (e: Exception) {
            ApiResult.Failure(
                httpCode = null,
                errorMessage = "Request error: ${e.localizedMessage ?: e.javaClass.simpleName}",
                isRetryable = false
            )
        }
    }

    internal fun parseHttpResponse(
        httpCode: Int,
        httpMessage: String,
        isSuccessful: Boolean,
        rawBody: String
    ): ApiResult {
        val parsedObj = try {
            if (rawBody.startsWith("{")) json.decodeFromString<JsonObject>(rawBody) else null
        } catch (_: Exception) {
            null
        }

        val okFlag = parsedObj?.get("ok")?.jsonPrimitive?.booleanOrNull
        val codeField = parsedObj?.get("code")?.jsonPrimitive?.contentOrNull
        val errorField = parsedObj?.get("error")?.jsonPrimitive?.contentOrNull
        val messageField = parsedObj?.get("message")?.jsonPrimitive?.contentOrNull
        val detailSnippet = listOfNotNull(codeField, errorField ?: messageField)
            .filter { it.isNotBlank() }
            .joinToString(" — ")
            .ifBlank { rawBody.take(180) }

        if (isSuccessful && okFlag != false) {
            return ApiResult.Success(
                httpCode = httpCode,
                serverMessage = if (detailSnippet.isNotEmpty()) {
                    "HTTP $httpCode: $detailSnippet"
                } else {
                    "HTTP $httpCode OK"
                }
            )
        }

        val retryable = httpCode == 408 || httpCode == 429 || httpCode >= 500
        val errorText = if (detailSnippet.isNotEmpty()) {
            "HTTP $httpCode: $detailSnippet"
        } else {
            "HTTP $httpCode: $httpMessage"
        }
        return ApiResult.Failure(
            httpCode = httpCode,
            errorMessage = errorText,
            isRetryable = retryable
        )
    }
}
