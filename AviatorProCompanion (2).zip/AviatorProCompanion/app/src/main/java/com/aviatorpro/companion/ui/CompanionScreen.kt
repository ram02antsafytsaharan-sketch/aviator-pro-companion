package com.aviatorpro.companion.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aviatorpro.companion.data.local.RoundRecordEntity
import com.aviatorpro.companion.data.local.SyncStatus
import com.aviatorpro.companion.service.ConnectionStatus
import com.aviatorpro.companion.service.MonitoringStatus
import com.aviatorpro.companion.ui.theme.AviatorColors
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CompanionScreen(
    uiState: CompanionUiState,
    onIngestEndpointChanged: (String) -> Unit,
    onHandshakeEndpointChanged: (String) -> Unit,
    onDeviceNameChanged: (String) -> Unit,
    onDeviceKeyChanged: (String) -> Unit,
    onSaveConfig: () -> Unit,
    onTestConnection: () -> Unit,
    onStartMonitoring: () -> Unit,
    onStopMonitoring: () -> Unit,
    onRetryPending: () -> Unit,
    onClearSynced: () -> Unit
) {
    var showDeviceKey by rememberSaveable { mutableStateOf(false) }
    val isMonitoringActive = uiState.monitoringStatus is MonitoringStatus.Active ||
        uiState.monitoringStatus is MonitoringStatus.Starting

    Scaffold(
        containerColor = AviatorColors.NavyBackground,
        topBar = {
            TopAppBar(
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = AviatorColors.NavyBackground,
                    titleContentColor = AviatorColors.WhiteText
                ),
                title = {
                    Column {
                        Text(
                            text = "AVIATOR PRO COMPANION",
                            style = MaterialTheme.typography.titleMedium,
                            color = AviatorColors.WhiteText,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = "Android 15 · ML Kit OCR Sync",
                            style = MaterialTheme.typography.bodySmall,
                            color = AviatorColors.CyanAccent
                        )
                    }
                },
                actions = {
                    ConnectionStatusBadge(
                        status = uiState.connectionStatus,
                        modifier = Modifier.padding(end = 12.dp)
                    )
                }
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .imePadding(),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                MonitoringControlCard(
                    monitoringStatus = uiState.monitoringStatus,
                    isMonitoringActive = isMonitoringActive,
                    onStartMonitoring = onStartMonitoring,
                    onStopMonitoring = onStopMonitoring
                )
            }

            item {
                ApiConfigurationCard(
                    ingestEndpointInput = uiState.ingestEndpointInput,
                    handshakeEndpointInput = uiState.handshakeEndpointInput,
                    deviceNameInput = uiState.deviceNameInput,
                    deviceKeyInput = uiState.deviceKeyInput,
                    ingestError = uiState.ingestValidationError,
                    handshakeError = uiState.handshakeValidationError,
                    savedMessage = uiState.configSavedMessage,
                    uiNotice = uiState.uiNotice,
                    connectionStatus = uiState.connectionStatus,
                    isTesting = uiState.isTestingConnection,
                    showDeviceKey = showDeviceKey,
                    onToggleDeviceKey = { showDeviceKey = !showDeviceKey },
                    onIngestEndpointChanged = onIngestEndpointChanged,
                    onHandshakeEndpointChanged = onHandshakeEndpointChanged,
                    onDeviceNameChanged = onDeviceNameChanged,
                    onDeviceKeyChanged = onDeviceKeyChanged,
                    onSaveConfig = onSaveConfig,
                    onTestConnection = onTestConnection
                )
            }

            item {
                DetectedResultsHeader(
                    totalCount = uiState.totalRoundsCount,
                    pendingCount = uiState.pendingRoundsCount,
                    hasSyncedItems = uiState.rounds.any { it.syncStatus == SyncStatus.SYNCED },
                    onRetryPending = onRetryPending,
                    onClearSynced = onClearSynced
                )
            }

            if (uiState.rounds.isEmpty()) {
                item {
                    EmptyRoundsCard()
                }
            } else {
                items(
                    items = uiState.rounds,
                    key = { it.roundId }
                ) { record ->
                    RoundRecordCard(record = record)
                }
            }

            item {
                Spacer(modifier = Modifier.height(16.dp))
            }
        }
    }
}

@Composable
private fun ConnectionStatusBadge(
    status: ConnectionStatus,
    modifier: Modifier = Modifier
) {
    val (label, dotColor, borderColor) = when (status) {
        is ConnectionStatus.Unverified -> Triple("Unverified", AviatorColors.SlateText, AviatorColors.NavyBorder)
        is ConnectionStatus.Checking -> Triple("Checking...", AviatorColors.CyanAccent, AviatorColors.CyanAccent)
        is ConnectionStatus.Connected -> Triple("HTTP ${status.httpCode}", AviatorColors.SuccessGreen, AviatorColors.SuccessGreen)
        is ConnectionStatus.Error -> Triple(
            if (status.isRetrying) "Retrying" else "Error",
            if (status.isRetrying) AviatorColors.WarningAmber else AviatorColors.ErrorRed,
            if (status.isRetrying) AviatorColors.WarningAmber else AviatorColors.ErrorRed
        )
    }

    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(8.dp),
        color = AviatorColors.NavySurface,
        border = BorderStroke(1.dp, borderColor.copy(alpha = 0.6f))
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(8.dp)
                    .clip(CircleShape)
                    .background(dotColor)
            )
            Text(
                text = label,
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold,
                color = AviatorColors.WhiteText
            )
        }
    }
}

@Composable
private fun MonitoringControlCard(
    monitoringStatus: MonitoringStatus,
    isMonitoringActive: Boolean,
    onStartMonitoring: () -> Unit,
    onStopMonitoring: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = AviatorColors.NavySurface),
        border = BorderStroke(
            width = 1.dp,
            color = if (isMonitoringActive) AviatorColors.CyanAccent.copy(alpha = 0.7f) else AviatorColors.NavyBorder
        )
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Screen Monitoring",
                    style = MaterialTheme.typography.titleMedium,
                    color = AviatorColors.WhiteText
                )
                Text(
                    text = when (monitoringStatus) {
                        is MonitoringStatus.Idle -> "Idle"
                        is MonitoringStatus.Starting -> "Starting..."
                        is MonitoringStatus.Active -> "Active"
                        is MonitoringStatus.Error -> "Stopped"
                    },
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = when (monitoringStatus) {
                        is MonitoringStatus.Active -> AviatorColors.CyanAccent
                        is MonitoringStatus.Error -> AviatorColors.ErrorRed
                        else -> AviatorColors.SlateText
                    }
                )
            }

            when (monitoringStatus) {
                is MonitoringStatus.Active -> {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        StatItem(
                            label = "Frames Scanned",
                            value = monitoringStatus.framesAnalyzed.toString()
                        )
                        StatItem(
                            label = "Session Rounds",
                            value = monitoringStatus.roundsDetectedThisSession.toString()
                        )
                        StatItem(
                            label = "Last OCR Read",
                            value = monitoringStatus.lastCandidateText ?: "--"
                        )
                    }
                }
                is MonitoringStatus.Error -> {
                    Text(
                        text = monitoringStatus.message,
                        color = AviatorColors.ErrorRed,
                        fontSize = 13.sp
                    )
                }
                else -> {
                    Text(
                        text = "Uses MediaProjection after your explicit approval to recognize completed multipliers via on-device ML Kit OCR.",
                        color = AviatorColors.SlateText,
                        fontSize = 13.sp
                    )
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = onStartMonitoring,
                    enabled = !isMonitoringActive,
                    modifier = Modifier
                        .weight(1f)
                        .height(52.dp),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = AviatorColors.CyanAccent,
                        contentColor = AviatorColors.NavyBackground,
                        disabledContainerColor = AviatorColors.CyanMuted.copy(alpha = 0.4f),
                        disabledContentColor = AviatorColors.SlateText
                    )
                ) {
                    Icon(
                        imageVector = Icons.Default.PlayArrow,
                        contentDescription = null,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Start Monitoring",
                        fontWeight = FontWeight.Bold,
                        maxLines = 1
                    )
                }

                OutlinedButton(
                    onClick = onStopMonitoring,
                    enabled = isMonitoringActive,
                    modifier = Modifier
                        .weight(1f)
                        .height(52.dp),
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(
                        1.dp,
                        if (isMonitoringActive) AviatorColors.ErrorRed else AviatorColors.NavyBorder
                    ),
                    colors = ButtonDefaults.outlinedButtonColors(
                        contentColor = AviatorColors.WhiteText,
                        disabledContentColor = AviatorColors.SlateText
                    )
                ) {
                    Icon(
                        imageVector = Icons.Default.Stop,
                        contentDescription = null,
                        modifier = Modifier.size(20.dp),
                        tint = if (isMonitoringActive) AviatorColors.ErrorRed else AviatorColors.SlateText
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Stop Monitoring",
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1
                    )
                }
            }
        }
    }
}

@Composable
private fun StatItem(label: String, value: String) {
    Column {
        Text(
            text = label,
            fontSize = 11.sp,
            color = AviatorColors.SlateText
        )
        Text(
            text = value,
            fontSize = 15.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.SemiBold,
            color = AviatorColors.WhiteText
        )
    }
}

@Composable
private fun ApiConfigurationCard(
    ingestEndpointInput: String,
    handshakeEndpointInput: String,
    deviceNameInput: String,
    deviceKeyInput: String,
    ingestError: String?,
    handshakeError: String?,
    savedMessage: String?,
    uiNotice: String?,
    connectionStatus: ConnectionStatus,
    isTesting: Boolean,
    showDeviceKey: Boolean,
    onToggleDeviceKey: () -> Unit,
    onIngestEndpointChanged: (String) -> Unit,
    onHandshakeEndpointChanged: (String) -> Unit,
    onDeviceNameChanged: (String) -> Unit,
    onDeviceKeyChanged: (String) -> Unit,
    onSaveConfig: () -> Unit,
    onTestConnection: () -> Unit
) {
    val fieldColors = OutlinedTextFieldDefaults.colors(
        focusedBorderColor = AviatorColors.CyanAccent,
        unfocusedBorderColor = AviatorColors.NavyBorder,
        focusedTextColor = AviatorColors.WhiteText,
        unfocusedTextColor = AviatorColors.WhiteText,
        focusedLabelColor = AviatorColors.CyanAccent,
        unfocusedLabelColor = AviatorColors.SlateText,
        cursorColor = AviatorColors.CyanAccent,
        errorBorderColor = AviatorColors.ErrorRed
    )

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = AviatorColors.NavySurface),
        border = BorderStroke(1.dp, AviatorColors.NavyBorder)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                text = "Base44 Production API",
                style = MaterialTheme.typography.titleMedium,
                color = AviatorColors.WhiteText
            )

            OutlinedTextField(
                value = ingestEndpointInput,
                onValueChange = onIngestEndpointChanged,
                label = { Text("Ingest Endpoint (Completed Rounds)") },
                placeholder = { Text("https://sociable-aviator-stats-flow.base44.app/api/ingest") },
                singleLine = true,
                isError = ingestError != null,
                supportingText = ingestError?.let { err -> { Text(err, color = AviatorColors.ErrorRed) } },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri),
                colors = fieldColors,
                modifier = Modifier.fillMaxWidth()
            )

            OutlinedTextField(
                value = handshakeEndpointInput,
                onValueChange = onHandshakeEndpointChanged,
                label = { Text("Handshake Endpoint (Test Connection)") },
                placeholder = { Text("https://sociable-aviator-stats-flow.base44.app/api/handshake") },
                singleLine = true,
                isError = handshakeError != null,
                supportingText = handshakeError?.let { err -> { Text(err, color = AviatorColors.ErrorRed) } },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri),
                colors = fieldColors,
                modifier = Modifier.fillMaxWidth()
            )

            OutlinedTextField(
                value = deviceNameInput,
                onValueChange = onDeviceNameChanged,
                label = { Text("Device Name") },
                placeholder = { Text("Moto G 5G 2024") },
                singleLine = true,
                colors = fieldColors,
                modifier = Modifier.fillMaxWidth()
            )

            OutlinedTextField(
                value = deviceKeyInput,
                onValueChange = onDeviceKeyChanged,
                label = { Text("Device Authorization Key") },
                placeholder = { Text("Enter X-Device-Key value") },
                singleLine = true,
                visualTransformation = if (showDeviceKey) {
                    VisualTransformation.None
                } else {
                    PasswordVisualTransformation()
                },
                trailingIcon = {
                    IconButton(onClick = onToggleDeviceKey) {
                        Icon(
                            imageVector = if (showDeviceKey) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                            contentDescription = if (showDeviceKey) "Hide device key" else "Show device key",
                            tint = AviatorColors.SlateText
                        )
                    }
                },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                colors = fieldColors,
                modifier = Modifier.fillMaxWidth()
            )

            if (connectionStatus is ConnectionStatus.Connected) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = null,
                        tint = AviatorColors.SuccessGreen,
                        modifier = Modifier.size(16.dp)
                    )
                    Text(
                        text = "Handshake verified: ${connectionStatus.serverMessage}",
                        color = AviatorColors.SuccessGreen,
                        fontSize = 12.sp
                    )
                }
            } else if (connectionStatus is ConnectionStatus.Error) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.ErrorOutline,
                        contentDescription = null,
                        tint = if (connectionStatus.isRetrying) AviatorColors.WarningAmber else AviatorColors.ErrorRed,
                        modifier = Modifier.size(16.dp)
                    )
                    Text(
                        text = connectionStatus.message,
                        color = if (connectionStatus.isRetrying) AviatorColors.WarningAmber else AviatorColors.ErrorRed,
                        fontSize = 12.sp
                    )
                }
            }

            if (savedMessage != null) {
                Text(
                    text = savedMessage,
                    color = AviatorColors.CyanAccent,
                    fontSize = 12.sp
                )
            }
            if (uiNotice != null && connectionStatus !is ConnectionStatus.Error && connectionStatus !is ConnectionStatus.Connected) {
                Text(
                    text = uiNotice,
                    color = AviatorColors.WhiteText,
                    fontSize = 12.sp
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedButton(
                    onClick = onSaveConfig,
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp),
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(1.dp, AviatorColors.NavyBorder),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = AviatorColors.WhiteText)
                ) {
                    Text("Save", fontWeight = FontWeight.SemiBold)
                }

                Button(
                    onClick = onTestConnection,
                    enabled = !isTesting,
                    modifier = Modifier
                        .weight(1.3f)
                        .height(48.dp),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = AviatorColors.NavySurfaceElevated,
                        contentColor = AviatorColors.CyanAccent
                    ),
                    border = BorderStroke(1.dp, AviatorColors.CyanAccent.copy(alpha = 0.6f))
                ) {
                    if (isTesting) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(16.dp),
                            strokeWidth = 2.dp,
                            color = AviatorColors.CyanAccent
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                    }
                    Text(
                        text = if (isTesting) "Testing..." else "Test Connection",
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1
                    )
                }
            }
        }
    }
}

@Composable
private fun DetectedResultsHeader(
    totalCount: Int,
    pendingCount: Int,
    hasSyncedItems: Boolean,
    onRetryPending: () -> Unit,
    onClearSynced: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Text(
                text = "Detected Rounds ($totalCount)",
                style = MaterialTheme.typography.titleMedium,
                color = AviatorColors.WhiteText
            )
            if (pendingCount > 0) {
                Text(
                    text = "$pendingCount pending auto-retry",
                    fontSize = 12.sp,
                    color = AviatorColors.WarningAmber
                )
            }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            if (pendingCount > 0) {
                TextButton(onClick = onRetryPending) {
                    Icon(
                        imageVector = Icons.Default.Refresh,
                        contentDescription = "Retry pending",
                        tint = AviatorColors.CyanAccent,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Retry", color = AviatorColors.CyanAccent)
                }
            }
            if (hasSyncedItems) {
                TextButton(onClick = onClearSynced) {
                    Icon(
                        imageVector = Icons.Default.DeleteSweep,
                        contentDescription = "Clear synced",
                        tint = AviatorColors.SlateText,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Clear Synced", color = AviatorColors.SlateText)
                }
            }
        }
    }
}

@Composable
private fun EmptyRoundsCard() {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = AviatorColors.NavySurface),
        border = BorderStroke(1.dp, AviatorColors.NavyBorder)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Text(
                text = "No Completed Rounds Detected",
                color = AviatorColors.WhiteText,
                fontWeight = FontWeight.SemiBold,
                fontSize = 15.sp
            )
            Text(
                text = "Tap Start Monitoring, grant Android screen capture permission, and open Aviator. Only finished rounds are recorded.",
                color = AviatorColors.SlateText,
                fontSize = 13.sp
            )
        }
    }
}

@Composable
private fun RoundRecordCard(record: RoundRecordEntity) {
    val statusColor = when (record.syncStatus) {
        SyncStatus.SYNCED -> AviatorColors.SuccessGreen
        SyncStatus.PENDING, SyncStatus.SYNCING -> AviatorColors.WarningAmber
        else -> AviatorColors.ErrorRed
    }
    val statusLabel = when (record.syncStatus) {
        SyncStatus.SYNCED -> "Synced (HTTP ${record.lastHttpCode ?: 200})"
        SyncStatus.SYNCING -> "Sending..."
        SyncStatus.PENDING -> "Pending retry (${record.retryCount})"
        else -> "Failed"
    }
    val confidencePercent = String.format(Locale.US, "%.0f%%", record.ocrConfidence * 100f)

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = AviatorColors.NavySurface),
        border = BorderStroke(1.dp, AviatorColors.NavyBorder)
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = record.formattedMultiplier,
                    fontSize = 24.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    color = AviatorColors.CyanAccent
                )
                Text(
                    text = statusLabel,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = statusColor
                )
            }

            HorizontalDivider(color = AviatorColors.NavyBorder.copy(alpha = 0.7f))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "${record.detectionDate} · ${record.detectionTime}",
                    fontSize = 12.sp,
                    fontFamily = FontFamily.Monospace,
                    color = AviatorColors.WhiteText
                )
                Text(
                    text = "OCR $confidencePercent",
                    fontSize = 12.sp,
                    fontFamily = FontFamily.Monospace,
                    color = AviatorColors.SlateText
                )
            }

            Text(
                text = "Round ID: ${record.roundId}",
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace,
                color = AviatorColors.SlateText,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )

            if (!record.lastErrorMessage.isNullOrBlank() && record.syncStatus != SyncStatus.SYNCED) {
                Text(
                    text = record.lastErrorMessage,
                    fontSize = 11.sp,
                    color = statusColor
                )
            }
        }
    }
}
