package com.aviatorpro.companion.data.remote

import com.aviatorpro.companion.data.local.ApiConfiguration
import com.aviatorpro.companion.data.local.RoundRecordEntity
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.jsonObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.Instant

class Base44EndpointContractTest {

    @Test
    fun handshakePayloadNeverIncludesFakeRoundOrMultiplier() {
        val client = Base44ApiClient()
        val config = ApiConfiguration(
            ingestEndpointUrl = ApiConfiguration.DEFAULT_INGEST_ENDPOINT,
            handshakeEndpointUrl = ApiConfiguration.DEFAULT_HANDSHAKE_ENDPOINT,
            deviceName = "Moto G 5G 2024",
            deviceKey = "test-key",
            deviceId = "device-uuid-123"
        )

        val jsonBody = client.buildHandshakeBodyJson(config, "2026-11-27T07:17:49Z")

        assertTrue(jsonBody.contains("\"device_id\":\"device-uuid-123\""))
        assertTrue(jsonBody.contains("\"device_name\":\"Moto G 5G 2024\""))
        assertTrue(jsonBody.contains("\"timestamp_iso\":\"2026-11-27T07:17:49Z\""))
        assertTrue(jsonBody.contains("\"source\":\"aviator_pro_companion_android\""))
        assertFalse(jsonBody.contains("round_id"))
        assertFalse(jsonBody.contains("multiplier"))
    }

    @Test
    fun handshakeValidatorRejectsIngestUrl() {
        val err = ApiConfiguration.validateHandshakeUrl(ApiConfiguration.DEFAULT_INGEST_ENDPOINT)
        assertNotNull(err)
        assertNull(ApiConfiguration.validateHandshakeUrl(ApiConfiguration.DEFAULT_HANDSHAKE_ENDPOINT))
        assertEquals(
            ApiConfiguration.DEFAULT_HANDSHAKE_ENDPOINT,
            ApiConfiguration.deriveHandshakeUrl(ApiConfiguration.DEFAULT_INGEST_ENDPOINT)
        )
    }

    @Test
    fun ingestPayloadIncludesValidIso8601DetectedAtString() {
        val client = Base44ApiClient()
        val config = ApiConfiguration(
            deviceName = "Moto G 5G 2024",
            deviceKey = "test-key",
            deviceId = "device-uuid-123"
        )
        val expectedIso = "2026-11-27T08:30:45.123Z"
        val record = RoundRecordEntity(
            roundId = "APC-1764180002000-8f3a9c12",
            multiplier = 10.50,
            formattedMultiplier = "10.50x",
            detectionDate = "2026-11-27",
            detectionTime = "00:30:45",
            detectedAtIso = expectedIso,
            ocrConfidence = 0.94f
        )

        val jsonBody = client.buildIngestBodyJson(config, record)
        val root = Json.parseToJsonElement(jsonBody).jsonObject
        val detectedAtElement = root["detected_at"] as? JsonPrimitive

        assertNotNull("detected_at must be present in JSON", detectedAtElement)
        assertTrue("detected_at must be a JSON string", detectedAtElement!!.isString)
        assertFalse("detected_at must not be empty", detectedAtElement.content.isBlank())
        assertEquals(expectedIso, detectedAtElement.content)
        assertEquals(Instant.parse(expectedIso), Instant.parse(detectedAtElement.content))
        assertFalse("detected_at_iso must not be used", root.containsKey("detected_at_iso"))

        assertTrue(jsonBody.contains("\"round_id\":\"APC-1764180002000-8f3a9c12\""))
        assertTrue(jsonBody.contains("\"multiplier\":10.5"))
        assertTrue(jsonBody.contains("\"multiplier_text\":\"10.50x\""))
        assertTrue(jsonBody.contains("\"device_name\":\"Moto G 5G 2024\""))
    }

    @Test
    fun ingestPayloadRecoversValidInstantWhenDetectedAtIsBlankOrNonIso() {
        val client = Base44ApiClient()
        val config = ApiConfiguration(
            deviceName = "Moto G 5G 2024",
            deviceKey = "test-key",
            deviceId = "device-uuid-123"
        )
        val record = RoundRecordEntity(
            roundId = "APC-1764180002000-8f3a9c12",
            multiplier = 2.00,
            formattedMultiplier = "2.00x",
            detectionDate = "2026-11-27",
            detectionTime = "00:30:45",
            detectedAtIso = "",
            ocrConfidence = 0.91f
        )

        val jsonBody = client.buildIngestBodyJson(config, record)
        val root = Json.parseToJsonElement(jsonBody).jsonObject
        val detectedAtElement = root["detected_at"] as? JsonPrimitive

        assertNotNull(detectedAtElement)
        assertTrue(detectedAtElement!!.isString)
        assertTrue(detectedAtElement.content.endsWith("Z"))
        // Must parse cleanly as java.time.Instant without throwing
        Instant.parse(detectedAtElement.content)
    }

    @Test
    fun parsesBase44JsonErrorAndOkFlag() {
        val client = Base44ApiClient()
        val fail = client.parseHttpResponse(
            httpCode = 401,
            httpMessage = "Unauthorized",
            isSuccessful = false,
            rawBody = """{"ok":false,"code":"missing_device_key","error":"Send the device key in the X-Device-Key header."}"""
        )
        assertTrue(fail is ApiResult.Failure)
        assertEquals(
            "HTTP 401: missing_device_key — Send the device key in the X-Device-Key header.",
            (fail as ApiResult.Failure).errorMessage
        )

        val okFalseWith200 = client.parseHttpResponse(
            httpCode = 200,
            httpMessage = "OK",
            isSuccessful = true,
            rawBody = """{"ok":false,"code":"invalid_key","error":"Device key rejected."}"""
        )
        assertTrue(okFalseWith200 is ApiResult.Failure)
    }
}
